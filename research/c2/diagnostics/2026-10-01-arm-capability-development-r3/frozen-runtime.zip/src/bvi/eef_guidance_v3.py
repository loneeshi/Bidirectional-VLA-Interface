"""Single-attempt history; no cross-attempt memory or event interruption."""
from .eef_guidance_v2 import PROMPT as BASE
VERSION = 'guidance-v3'
PROMPT = BASE.replace('guidance-v2', VERSION) + """
Each response also includes task_state: belief, uncertainty, expected_change, next_check, each at most 160 characters. These are brief evidence-linked self-reports, not hidden reasoning or measured truth. Cite observation IDs and camera names when relevant; say unknown when evidence is insufficient. First compare the previous expected change with the latest observation and measured result. Preserve unresolved uncertainty unless new evidence resolves it.
History rows identify control-step intervals; complete earlier RGB-D, calls and results remain in context. Current measurements override old estimates. Old pixels and base-frame points remain tied to their source observation; do not reuse them as current goals after motion without re-evaluation. No automatic scene-point update is provided.
Use both camera views where informative, but state when either cannot establish clearance. Target distance or a visible floor strip does not establish full-body clearance. Before a base move explain the relevant visual/depth evidence, remaining occlusion and why it supports the chosen distance.
A chunk executes continuously without intermediate Astra visual decisions. Use separate move_to calls when an intermediate pose needs visual confirmation; combine only when you judge that intermediate observation unnecessary. Balance additional calls and settling against the remaining budget. No force or stalled-progress event interrupts a command.
"""
