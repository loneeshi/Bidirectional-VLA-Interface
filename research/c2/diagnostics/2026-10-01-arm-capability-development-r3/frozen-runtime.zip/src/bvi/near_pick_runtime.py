"""Stepwise Pick executor with paired baseline, periodic, and event schedules.

Ports deliberately expose every environment step.  A movement port must return
all measurements, so a relocation cannot hide a clock tick, force violation,
or native completion from the official scorer.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Protocol

from .coordinator import APIBudgetExhausted
from .near_pick_protocol import InterventionMonitor, PickSample, parse_decision


@dataclass(frozen=True)
class MotionResult:
    candidate_id: str
    samples: tuple[PickSample, ...]
    arrived: bool
    reason: str


class PickPorts(Protocol):
    def current(self) -> PickSample: ...
    def sac_step(self) -> PickSample: ...
    def candidate_ids(self) -> tuple[str, ...]: ...
    def ask_gpt(self, reason: str, eligible_ids: tuple[str, ...]) -> object: ...
    def reposition(self, candidate_id: str) -> MotionResult: ...


def _terminal(row: PickSample) -> bool:
    return (row.official_success or row.official_fail or row.steps_left == 0 or
            row.robot_cumulative_force >= row.force_limit)


def _next(prior: PickSample, row: PickSample) -> PickSample:
    if row.pick_step != prior.pick_step + 1:
        raise RuntimeError("environment action was omitted or duplicated")
    if not row.official_success and row.steps_left != prior.steps_left - 1:
        raise RuntimeError("official Pick clock reset or diverged")
    if not row.official_success and row.robot_cumulative_force + 1e-5 < prior.robot_cumulative_force:
        raise RuntimeError("official cumulative force reset")
    return row


def run_pick(schedule: str, ports: PickPorts, emit: Callable[[str, dict], None]) -> dict:
    """Run a live Pick.  Each mode must be given an independent identical start.

    The provider call itself does not step simulation.  GPT failure is logged and
    deterministically interpreted as continue.  Motion failure ends the attempt:
    blindly resuming SAC after an incomplete move would change the start state.
    """
    monitor = InterventionMonitor(schedule)
    current = ports.current()
    if current.pick_step != 0:
        raise ValueError("fresh Pick start required")
    trace = []
    pending_reason = (monitor.observe(current) if schedule in
                      ("periodic_start", "event_start") else None)
    while not _terminal(current):
        if pending_reason is None:
            current = _next(current, ports.sac_step())
            trace.append(current)
            emit("pick_action", {"schedule": schedule, "step": current.pick_step,
                                 "official_success": current.official_success,
                                 "official_fail": current.official_fail,
                                 "steps_left": current.steps_left,
                                 "cumulative_force": current.robot_cumulative_force})
            pending_reason = monitor.observe(current)
            if pending_reason is None:
                continue
        reason, pending_reason = pending_reason, None
        eligible = ports.candidate_ids() if monitor.can_reposition(current) else ()
        emit("gpt_check_started", {"schedule": schedule, "step": current.pick_step,
                                   "reason": reason, "eligible_ids": eligible})
        try:
            raw = ports.ask_gpt(reason, eligible)
            decision = parse_decision(raw, eligible)
        except APIBudgetExhausted:
            emit("gpt_budget_exhausted", {"schedule": schedule,
                                          "step": current.pick_step})
            raise
        except Exception as exc:
            decision = {"action": "continue", "candidate_id": "",
                        "reason": "provider_failure"}
            emit("gpt_check_error", {"type": type(exc).__name__})
        emit("gpt_decision", {"step": current.pick_step, **decision})
        if decision["action"] != "reposition":
            continue
        if not monitor.can_reposition(current):
            raise RuntimeError("reposition admitted after eligibility expired")
        movement = ports.reposition(decision["candidate_id"])
        if movement.candidate_id != decision["candidate_id"]:
            raise RuntimeError("movement candidate changed")
        for row in movement.samples:
            current = _next(current, row)
            trace.append(row)
            if schedule not in ("periodic_start", "event_start"):
                monitor.history.append(row)
            emit("reposition_action", {"step": row.pick_step,
                                       "candidate_id": movement.candidate_id,
                                       "steps_left": row.steps_left,
                                       "cumulative_force": row.robot_cumulative_force})
            if _terminal(row):
                break
        monitor.repositions += 1
        if schedule in ("periodic_start", "event_start"):
            monitor.history = [current]
        emit("reposition_finished", {"candidate_id": movement.candidate_id,
                                     "arrived": movement.arrived,
                                     "reason": movement.reason,
                                     "step": current.pick_step})
        if not movement.arrived and not _terminal(current):
            return {"status": "reposition_not_arrived", "strict_pick_success": False,
                    "checks": monitor.checks, "repositions": monitor.repositions,
                    "last_step": current.pick_step, "trace": tuple(trace)}
    return {"status": "official_complete", "strict_pick_success": current.official_success and
            not current.official_fail and current.robot_cumulative_force < current.force_limit,
            "checks": monitor.checks, "repositions": monitor.repositions,
            "last_step": current.pick_step, "trace": tuple(trace)}
