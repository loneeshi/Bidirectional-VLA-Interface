"""v4: bounded, damped native position targets during gripper operations.

Motion planning/tracking and joint-space rest remain v3. During alignment we
anchor torso/head references at command entry, compensate the measured torso
with arm IK, and hold the achieved joint posture while closing. No A1 inverse
is used in these phases. This is not a globally locked-torso executor.
"""
from dataclasses import dataclass, asdict
import numpy as np
from .eef_tools import vector
from .eef_streaming import grip_band
from .eef_tools_v3 import FetchToolsV3, CONTINUOUS, periodic_delta, pose_error

VERSION = 'eef-tool-v4-damped-gripper-r1'
QI = np.array([5,7,8,9,10,11,12,4,6,3])
AI = np.array([0,1,2,3,4,5,6,8,9,10])


@dataclass(frozen=True)
class SettlingParameters:
    # Frozen engineering choice, not fitted to the three teachers or gate scores.
    position_gain: float = 1.0
    velocity_step_gain: float = .5
    action_cap: float = .25
    action_change_cap: float = .25
    official_delta_scale: float = .1

    def __post_init__(self):
        values=asdict(self)
        if not all(np.isfinite(v) and v>0 for v in values.values()):
            raise ValueError('settling parameters must be finite and positive')
        if self.action_cap>1 or self.action_change_cap>2 or self.official_delta_scale != .1:
            raise ValueError('normalized action or official delta-scale violation')


class FetchToolsV4(FetchToolsV3):
    def __init__(self,*args,read_qvel,control_dt,settling=SettlingParameters(),**kwargs):
        super().__init__(*args,**kwargs)
        if not np.isfinite(control_dt) or control_dt<=0:
            raise ValueError('positive measured control period required')
        self.read_qvel=read_qvel
        self.control_dt=float(control_dt)
        self.settling=settling

    def settling_action(self,reference,previous_action):
        """Native q-target offset with measured velocity damping, not dq inversion."""
        q=vector(self.read_qpos(),15)
        velocity=vector(self.read_qvel(),15)
        error=periodic_delta(vector(reference,15),q,CONTINUOUS)
        cfg=self.settling
        offset=cfg.position_gain*error-cfg.velocity_step_gain*self.control_dt*velocity
        desired=np.clip(offset[QI]/cfg.official_delta_scale,-cfg.action_cap,cfg.action_cap)
        last=vector(previous_action,13)[AI]
        action=np.zeros(13)
        action[AI]=np.clip(last+np.clip(desired-last,-cfg.action_change_cap,cfg.action_change_cap),
                           -cfg.action_cap,cfg.action_cap)
        action[7]=2*self.gripper-1
        return action

    def set_gripper(self,command):
        band=grip_band(command); before=self.steps
        self.deadline=min(self.max_steps,before+self.p.close_align_cap+self.p.close_wait_cap)
        entering=band==0 and grip_band(self.gripper)!=0
        anchor=vector(self.read_qpos(),15).copy()
        previous_action=np.zeros(13)
        alignment=None
        if entering:
            pe,re=pose_error(self.fk,self.read_qpos(),self.last_goal)
            while ((pe>self.p.position_tolerance or re>self.p.rotation_tolerance
                    or abs(self.previous_delta[3])>=self.p.torso_stable)
                   and self.steps-before<self.p.close_align_cap and self._available()):
                target,solved=self._compensate(self.last_goal)
                if solved.reason=='jump_rejected':
                    return {'accepted':False,'reason':'jump_rejected','steps_used':self.steps-before}
                # Keep these references fixed throughout this command. Arm IK
                # still uses actual measured torso height, never an ideal height.
                target[[3,4,6]]=anchor[[3,4,6]]
                action=self.settling_action(target,previous_action)
                self._step(action,'close_align',ik_reason=solved.reason,
                           control='damped_native_position',reference_qpos=target.tolist(),
                           torso_anchor_m=float(anchor[3]))
                previous_action=action
                pe,re=pose_error(self.fk,self.read_qpos(),self.last_goal)
            alignment={'position_error_m':pe,'rotation_error_rad':re,
                       'torso_delta_m':abs(float(self.previous_delta[3])),
                       'steps_used':self.steps-before,'torso_anchor_m':float(anchor[3])}
            if (pe>self.p.position_tolerance or re>self.p.rotation_tolerance
                    or abs(self.previous_delta[3])>=self.p.torso_stable or not self._available()):
                return {'accepted':False,'reason':'close_alignment_failed','alignment':alignment,
                        'steps_used':self.steps-before}
        self.gripper=float(command)
        # Hold a single achieved arm posture during finger motion. The torso
        # anchor persists from command entry; it is never reset at every step.
        hold=vector(self.read_qpos(),15).copy(); hold[[3,4,6]]=anchor[[3,4,6]]
        wait_start=self.steps; stable=0; previous=float(self.read_finger())
        cap=self.p.close_wait_cap if entering else 1
        while self.steps-wait_start<cap and self._available():
            action=self.settling_action(hold,previous_action)
            self._step(action,'gripper',control='damped_native_position',
                       reference_qpos=hold.tolist(),torso_anchor_m=float(anchor[3]))
            previous_action=action
            current=float(self.read_finger())
            stable=stable+1 if abs(current-previous)<self.p.finger_stable else 0
            previous=current
            if entering and stable>=2:
                break
        return {'accepted':self.steps>wait_start,
                'reason':'ok' if self.steps>wait_start else 'terminal_or_budget',
                'steps_used':self.steps-before,'alignment':alignment,'enter_closed':entering,
                'command':self.gripper,'finger_distance_m':previous,
                'stable':stable>=2 if entering else None,'control':'damped_native_position'}
