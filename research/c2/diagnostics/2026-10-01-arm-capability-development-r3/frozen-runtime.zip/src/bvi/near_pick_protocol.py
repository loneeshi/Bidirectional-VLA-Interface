"""Frozen, simulator-independent rules for the near-visible Pick study.

This module never resets an episode, calls a policy, or queries a provider.  A
runner supplies measured state and is responsible for logging every action.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Mapping


RADII_M = (0.8, 1.1, 1.4)
BEARINGS_RAD = (-math.pi / 6, math.pi / 6)
PERIOD_STEPS = 20
EARLY_PERIOD_STEPS = 10
STAGNATION_STEPS = 15
MIN_IMPROVEMENT_M = 0.03
FORCE_TRIGGER_FRACTION = 0.60
MAX_GPT_CHECKS = 3
MAX_REPOSITIONS = 1
MIN_VALID_STARTS = 12
MIN_SCENE_OBJECT_PAIRS = 2
MAX_STUDY_PAIRS = 4
RECOVERY_RADII_M = (1.4, 1.7, 2.0, 2.3)


@dataclass(frozen=True)
class StartPose:
    candidate_id: str
    radius_m: float
    bearing_rad: float
    x_m: float
    y_m: float
    yaw_rad: float


def start_lattice(object_xy: tuple[float, float]) -> tuple[StartPose, ...]:
    """Six deterministic poses, all looking toward the target centre."""
    if len(object_xy) != 2 or not all(math.isfinite(v) for v in object_xy):
        raise ValueError("finite object XY required")
    poses = []
    for radius in RADII_M:
        for bearing in BEARINGS_RAD:
            x = object_xy[0] + radius * math.cos(bearing)
            y = object_xy[1] + radius * math.sin(bearing)
            yaw = math.atan2(object_xy[1] - y, object_xy[0] - x)
            poses.append(StartPose(f"P{len(poses) + 1}", radius, bearing, x, y, yaw))
    return tuple(poses)


def recovery_start_lattice(object_xy: tuple[float, float]) -> tuple[StartPose, ...]:
    """Predeclared harder starts; IDs do not depend on SAC outcomes."""
    if len(object_xy) != 2 or not all(math.isfinite(v) for v in object_xy):
        raise ValueError("finite object XY required")
    poses = []
    for radius in RECOVERY_RADII_M:
        for bearing in BEARINGS_RAD:
            x = object_xy[0] + radius * math.cos(bearing)
            y = object_xy[1] + radius * math.sin(bearing)
            yaw = math.atan2(object_xy[1] - y, object_xy[0] - x)
            poses.append(StartPose(f"P{len(poses) + 1}", radius, bearing, x, y, yaw))
    return tuple(poses)


def select_pairs(rows: list[Mapping[str, object]], *, max_pairs: int = MAX_STUDY_PAIRS,
                 spread_scenes: bool = False) -> tuple[Mapping[str, object], ...]:
    """Outcome-blind selection from validation Pick catalog metadata."""
    eligible = [row for row in rows if row.get("split") == "val" and
                row.get("skill") == "pick" and isinstance(row.get("scene"), str) and
                isinstance(row.get("object_category"), str)]
    eligible.sort(key=lambda row: (str(row["scene"]), str(row["object_category"]),
                                   str(row.get("plan_uid", ""))))
    if max_pairs <= 0:
        raise ValueError("positive pair limit required")
    seen = set()
    selected = []
    if spread_scenes:
        seen_scenes = set()
        for row in eligible:
            scene = str(row["scene"])
            if scene not in seen_scenes:
                selected.append(row)
                seen.add((row["scene"], row["object_category"]))
                seen_scenes.add(scene)
            if len(selected) == max_pairs:
                return tuple(selected)
    for row in eligible:
        pair = (row["scene"], row["object_category"])
        if pair not in seen:
            selected.append(row)
            seen.add(pair)
        if len(selected) == max_pairs:
            break
    return tuple(selected)


def partition_starts(rows: list[Mapping[str, object]]) -> dict[str, object]:
    """First eligible pose per pair is a pilot; all others are paired tests."""
    accepted = [row for row in rows if row.get("status") == "accepted"]
    pairs = {(str(row["scene"]), str(row["object_category"])) for row in accepted}
    if len(accepted) < MIN_VALID_STARTS or len(pairs) < MIN_SCENE_OBJECT_PAIRS:
        return {"gate": "start_feasibility_only", "pilot": [], "comparison": []}
    by_pair: dict[tuple[str, str], list[Mapping[str, object]]] = {}
    for row in accepted:
        by_pair.setdefault((str(row["scene"]), str(row["object_category"])), []).append(row)
    pilot = []
    comparison = []
    for pair in sorted(by_pair):
        ordered = sorted(by_pair[pair], key=lambda row: str(row["candidate_id"]))
        pilot.append(ordered[0])
        comparison.extend(ordered[1:])
    return {"gate": "ready", "pilot": pilot, "comparison": comparison}


@dataclass(frozen=True)
class PickSample:
    pick_step: int
    tcp_target_distance_m: float
    robot_cumulative_force: float
    force_limit: float
    steps_left: int
    grasped: bool
    official_success: bool
    official_fail: bool

    def __post_init__(self) -> None:
        if self.pick_step < 0 or self.steps_left < 0:
            raise ValueError("invalid Pick clock")
        if not all(math.isfinite(x) for x in (self.tcp_target_distance_m,
                                               self.robot_cumulative_force,
                                               self.force_limit)):
            raise ValueError("nonfinite Pick measurement")
        if self.tcp_target_distance_m < 0 or self.robot_cumulative_force < 0 or self.force_limit <= 0:
            raise ValueError("invalid Pick measurement")


@dataclass
class InterventionMonitor:
    schedule: str
    history: list[PickSample] = field(default_factory=list)
    checks: int = 0
    repositions: int = 0
    _force_fired: bool = False
    _stagnation_fired_at: int = -1
    _sac_actions: int = 0

    def __post_init__(self) -> None:
        if self.schedule not in ("baseline", "periodic", "event",
                                 "periodic_start", "event_start"):
            raise ValueError("unknown schedule")

    def observe(self, sample: PickSample) -> str | None:
        if self.history and sample.pick_step <= self.history[-1].pick_step:
            raise ValueError("Pick clock did not advance")
        self.history.append(sample)
        if self.schedule in ("periodic_start", "event_start") and sample.pick_step > 0:
            self._sac_actions += 1
        if (self.schedule == "baseline" or self.checks >= MAX_GPT_CHECKS or
                sample.grasped or sample.official_success or sample.official_fail or
                sample.steps_left == 0 or sample.robot_cumulative_force >= sample.force_limit):
            return None
        reason = None
        if self.schedule in ("periodic_start", "event_start") and sample.pick_step == 0:
            reason = "subtask_start"
        elif self.schedule == "periodic" and sample.pick_step % PERIOD_STEPS == 0:
            reason = "periodic"
        elif (self.schedule == "periodic_start" and self._sac_actions > 0 and
              self._sac_actions % EARLY_PERIOD_STEPS == 0):
            reason = "periodic"
        elif self.schedule in ("event", "event_start"):
            if sample.robot_cumulative_force >= FORCE_TRIGGER_FRACTION * sample.force_limit:
                if not self._force_fired:
                    self._force_fired = True
                    reason = "force_risk"
            if reason is None and len(self.history) > STAGNATION_STEPS:
                earlier = self.history[-STAGNATION_STEPS - 1]
                improvement = earlier.tcp_target_distance_m - sample.tcp_target_distance_m
                if improvement < MIN_IMPROVEMENT_M and sample.pick_step - self._stagnation_fired_at >= STAGNATION_STEPS:
                    self._stagnation_fired_at = sample.pick_step
                    reason = "stagnation"
        if reason is not None:
            self.checks += 1
        return reason

    def can_reposition(self, sample: PickSample) -> bool:
        return (self.schedule != "baseline" and self.repositions < MAX_REPOSITIONS and
                not sample.grasped and not sample.official_success and
                not sample.official_fail and sample.steps_left > 0 and
                sample.robot_cumulative_force < sample.force_limit)


def parse_decision(value: object, eligible_ids: tuple[str, ...]) -> dict[str, str]:
    """Fail closed to continue, retaining a machine-readable protocol error."""
    if not isinstance(value, dict) or set(value) != {"action", "candidate_id", "reason"}:
        return {"action": "continue", "candidate_id": "", "reason": "model_protocol_failure"}
    action, candidate, reason = value["action"], value["candidate_id"], value["reason"]
    if not isinstance(reason, str) or len(reason) > 160:
        return {"action": "continue", "candidate_id": "", "reason": "model_protocol_failure"}
    if action == "continue" and candidate is None:
        return {"action": "continue", "candidate_id": "", "reason": reason}
    if action == "reposition" and isinstance(candidate, str) and candidate in eligible_ids:
        return {"action": "reposition", "candidate_id": candidate, "reason": reason}
    return {"action": "continue", "candidate_id": "", "reason": "model_protocol_failure"}
