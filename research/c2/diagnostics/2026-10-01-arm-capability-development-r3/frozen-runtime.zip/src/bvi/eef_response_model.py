"""CPU-only empirical joint/gripper dynamics; excludes contact and grasp physics."""
from dataclasses import dataclass
import numpy as np
from scipy.optimize import lsq_linear
from .eef_tools import ARM, FETCH_ORDER

NAMES = (*ARM, 'torso_lift_joint')
QIND = np.array([FETCH_ORDER.index(n) for n in NAMES])
AIND = np.array([0, 1, 2, 3, 4, 5, 6, 10])


def samples(frames):
    q = np.asarray([f['qpos'] for f in frames], dtype=float)
    actions = np.asarray([f['action'] for f in frames[1:]], dtype=float)
    # sample(action) occurs AFTER adapter.step(action); frame zero has no action.
    delta = np.diff(q[:, QIND], axis=0)
    lag = np.vstack([np.zeros(8), delta[:-1]])
    finger = np.asarray([f['finger_distance_m'] for f in frames])
    target = np.clip(.06 * (actions[:, 7]+1)-.02, 0, .1)
    return q, actions, delta, lag, finger, target


def fit_response(trajectories):
    rows = [samples(f) for f in trajectories]
    params = []
    for j, name in enumerate(NAMES):
        x = np.concatenate([np.column_stack([s[3][:, j], .1*s[1][:, AIND[j]]]) for s in rows])
        y = np.concatenate([s[2][:, j] for s in rows])
        fitted = lsq_linear(x, y, bounds=([0., .001], [.99, 2.]))
        params.append({'name': name, 'rho': float(fitted.x[0]), 'beta': float(fitted.x[1])})
    x = np.concatenate([np.column_stack([s[5]-s[4][:-1], np.ones(len(s[5]))]) for s in rows])
    y = np.concatenate([np.diff(s[4]) for s in rows])
    grip = lsq_linear(x, y, bounds=([.001, -.02], [1., .02])).x
    speeds = np.max(np.concatenate([np.abs(s[2]) for s in rows]), axis=0)
    return {'equation': 'dq[t] = rho*dq[t-1] + beta*0.1*action[t]',
            'joint_parameters': params, 'gripper': {'alpha': float(grip[0]), 'bias_m': float(grip[1]),
            'equation': 'd[t] = clip(d[t-1]+alpha*(clip(0.06*(a_grip+1)-0.02,0,0.1)-d[t-1])+bias,0,0.1)'},
            'reference_speed_limits': speeds.tolist(),
            'initial_delta': 'zero for first transition (unknown pre-snapshot velocity); no differences cross trajectories'}


def errors(model, frames):
    q, a, delta, lag, finger, target = samples(frames)
    rho = np.array([p['rho'] for p in model['joint_parameters']])
    beta = np.array([p['beta'] for p in model['joint_parameters']])
    predicted = rho*lag + beta*.1*a[:, AIND]
    residual = predicted-delta
    grip = model['gripper']
    finger_pred = np.clip(finger[:-1]+grip['alpha']*(target-finger[:-1])+grip['bias_m'],0,.1)
    # Also report free rollout, since a one-step fit need not remain accurate.
    plant = ResponsePlant(model,q[0],finger[0])
    free=[]; free_finger=[]
    for action in a:
        plant.step(action); free.append(plant.q[QIND].copy()); free_finger.append(plant.finger)
    ratios = [float(np.median(delta[:,j][np.abs(a[:,AIND[j]])>.1]/(.1*a[:,AIND[j]][np.abs(a[:,AIND[j]])>.1]))) for j in range(8)]
    return {'transitions':len(a),'joint_errors':[{'name':n,'one_step_rmse':float(np.sqrt(np.mean(residual[:,j]**2))),
        'one_step_mae':float(np.mean(abs(residual[:,j]))),'rollout_q_rmse':float(np.sqrt(np.mean((np.asarray(free)[:,j]-q[1:,QIND[j]])**2))),
        'observed_response_median':ratios[j]} for j,n in enumerate(NAMES)],
        'finger_one_step_rmse_m':float(np.sqrt(np.mean((finger_pred-finger[1:])**2))),
        'finger_rollout_rmse_m':float(np.sqrt(np.mean((np.asarray(free_finger)-finger[1:])**2)))}


@dataclass
class ResponsePlant:
    model: dict
    q: np.ndarray
    finger: float

    def __post_init__(self):
        self.q=np.asarray(self.q,dtype=float).copy()
        self.delta=np.zeros(8)
        self.steps=0

    def step(self, action):
        action=np.asarray(action,dtype=float)
        rho=np.array([p['rho'] for p in self.model['joint_parameters']])
        beta=np.array([p['beta'] for p in self.model['joint_parameters']])
        self.delta=rho*self.delta+beta*.1*action[AIND]
        self.q[QIND]+=self.delta
        self.q[3]=np.clip(self.q[3],0,.386)
        # Auxiliary head response is unidentifiable in stationary-head teachers.
        # Use median arm response, label it as extrapolated (not used to fit arm).
        for qi,ai in ((4,8),(6,9)):
            self.q[qi]+=float(np.median(beta[:7]))*.1*action[ai]
        g=self.model['gripper']; target=np.clip(.06*(action[7]+1)-.02,0,.1)
        self.finger=float(np.clip(self.finger+g['alpha']*(target-self.finger)+g['bias_m'],0,.1))
        self.q[-2:]=self.finger/2
        self.steps+=1
        return {'terminated':False,'truncated':False}
