"""Visual additions around immutable v13 motion. No scene or simulator imports."""
import math
import numpy as np
from .eef_tools import vector, locate_point
from .eef_tools_v13 import FetchToolsV13
from .eef_visual_config import *


class VisualTools(FetchToolsV13):
    def look(self, pan_rad, tilt_rad):
        values = (pan_rad, tilt_rad)
        for value, (lo, hi) in zip(values, HEAD_LIMITS):
            if type(value) not in (int, float) or not math.isfinite(value) or not lo <= value <= hi:
                raise ValueError('head angle outside frozen URDF limits')
        # Capture targets before settling, just as a v13 base instruction does.
        hold = vector(self.read_qpos(), 15).copy()
        target = hold.copy(); target[[4, 6]] = values
        def motion(left):
            previous = np.zeros(13); stable = 0
            while self._available():
                action = self.settling_action(target, previous)
                # Active head motion uses the official normalized range. Other
                # channels retain v13's conservative holding controller.
                q = vector(self.read_qpos(), 15)
                velocity = vector(self.read_qvel(), 15)
                desired = np.clip((np.asarray(values)-q[[4, 6]]
                    -.5*self.control_dt*velocity[[4, 6]])/.1, -1., 1.)
                action[[8, 9]] = previous[[8, 9]] + np.clip(
                    desired-previous[[8, 9]], -.25, .25)
                action[11:] = 0.
                self._step(action, 'look', reference_qpos=target.tolist())
                previous = action
                error = float(np.max(abs(vector(self.read_qpos(), 15)[[4, 6]] - values)))
                speed = float(np.max(abs(vector(self.read_qvel(), 15)[[4, 6]])))
                stable = stable + 1 if error <= HEAD_ERROR and speed < HEAD_SPEED else 0
                if self.stopped or stable >= HEAD_STABLE_READINGS: break
            error = float(np.max(abs(vector(self.read_qpos(), 15)[[4, 6]] - values)))
            arrived = stable >= HEAD_STABLE_READINGS and not self.stopped
            return {'accepted': True, 'arrived': arrived, 'head_error_rad': error,
                    'reason': 'official_terminated' if self.stopped else 'ok' if arrived else 'tool_step_limit'}
        return self._guarded('look', LOOK_CAP, motion)


class ObservationDepth:
    """Only the latest sensor frame; root changes also invalidate saved pixels."""
    def __init__(self):
        self.frame = None

    def set(self, observation_id, qpos, cameras):
        if not isinstance(observation_id, str) or not observation_id:
            raise ValueError('observation_id required')
        if set(cameras) != {'head', 'hand'}: raise ValueError('two robot cameras required')
        copied = {}
        for name, camera in cameras.items():
            depth = np.asarray(camera['depth_mm'])
            if depth.shape != (RESOLUTION, RESOLUTION) or not np.issubdtype(depth.dtype, np.integer):
                raise ValueError('raw millimeter depth resolution/type')
            copied[name] = {k: np.asarray(v).copy() for k, v in camera.items()}
        self.frame = (observation_id, vector(qpos, 15).copy(), copied)

    def locate(self, camera, pixel, observation_id, measured):
        if self.frame is None or observation_id != self.frame[0]: raise ValueError('use latest observation_id')
        if not np.array_equal(vector(measured, 15), self.frame[1]): raise ValueError('observation is stale after movement')
        if camera not in ('head', 'hand'): raise ValueError('camera must be head or hand')
        if (not isinstance(pixel, list) or len(pixel) != 2 or
                any(type(p) is not int or not 0 <= p < RESOLUTION for p in pixel)):
            raise ValueError('pixel must be integer [x,y] within 0..2047')
        frame = self.frame[2][camera]; x, y = pixel
        raw = frame['depth_mm']; depth = float(raw[y, x]) / 1000.
        result = locate_point(pixel, depth, frame['intrinsics'], frame['camera_in_base'], convention='sapien')
        area = raw[max(0, y-1):y+2, max(0, x-1):x+2]
        valid = area[area > 0].astype(float) / 1000.
        return {'accepted': True, 'readonly': True, 'reason': 'ok' if result['valid'] else 'invalid_depth',
                'valid': result['valid'], 'point_base_m': result['point_base'].tolist() if result['valid'] else None,
                'depth_m': depth if depth > 0 else None,
                'depth_spread_m': float(np.ptp(valid)) if len(valid) else None,
                'observation_id': observation_id}
