"""Current-state geometry and parameterized functions for the seed9 Pick."""
from __future__ import annotations

import math
import time

from .lightnav_skill import world_waypoint
from .mshab_adapter import scalar
from .near_pick_adapter import NearPickPorts

MOVE_MAX_M = .30
TURN_MAX_RAD = .52
MIN_NONZERO = .005


def target_relative(base_pose, target_xyz, base_z):
    x, y, yaw = (float(v) for v in base_pose)
    tx, ty, tz = (float(v) for v in target_xyz)
    if not all(math.isfinite(v) for v in (x, y, yaw, tx, ty, tz, base_z)):
        raise ValueError("nonfinite geometry")
    dx, dy = tx-x, ty-y
    forward = math.cos(yaw)*dx + math.sin(yaw)*dy
    left = -math.sin(yaw)*dx + math.cos(yaw)*dy
    return {"forward_m": forward, "left_m": left,
            "height_above_base_m": tz-base_z,
            "planar_distance_m": math.hypot(forward, left),
            "bearing_left_rad": math.atan2(left, forward)}


def parse_proposal(raw):
    if not isinstance(raw, dict) or set(raw) != {"action", "distance_m", "direction_rad", "angle_rad", "reason"}:
        raise ValueError("proposal_fields")
    action, distance, direction, angle, reason = (raw[k] for k in
                                          ("action", "distance_m", "direction_rad", "angle_rad", "reason"))
    if not isinstance(reason, str) or len(reason) > 160:
        raise ValueError("proposal_reason")
    if action == "continue" and distance is direction is angle is None:
        return {"action": action, "reason": reason}
    if action == "move" and angle is None and all(type(x) in (int, float) and math.isfinite(x)
                                                   for x in (distance, direction)):
        if MIN_NONZERO <= distance <= MOVE_MAX_M and -math.pi <= direction <= math.pi:
            return {"action": action, "distance_m": float(distance),
                    "direction_rad": float(direction), "reason": reason}
    if action == "turn" and distance is direction is None and type(angle) in (int, float) and math.isfinite(angle):
        if MIN_NONZERO <= abs(angle) <= TURN_MAX_RAD:
            return {"action": action, "angle_rad": float(angle), "reason": reason}
    raise ValueError("proposal_parameter_range")


def parse_commit(raw):
    if (not isinstance(raw, dict) or set(raw) != {"action", "reason"} or
            raw.get("action") not in ("execute", "continue") or
            not isinstance(raw.get("reason"), str) or len(raw["reason"]) > 160):
        raise ValueError("commit_protocol")
    return raw


class GeometryPickPorts(NearPickPorts):
    """Preview without stepping, then execute from the live state."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._sac_distances = [self.current().tcp_target_distance_m]
        self._previous_movement = None
        self._pending = None

    def sac_step(self):
        sample = super().sac_step()
        self._sac_distances.append(sample.tcp_target_distance_m)
        return sample

    def _context(self, reason):
        if self.deadline_monotonic is not None and time.monotonic() >= self.deadline_monotonic:
            raise TimeoutError("seed9 lab process wall limit")
        obs = self.adapter.observe()
        images = tuple(frame for frame in obs.images if frame.camera in ("fetch_head", "fetch_hand"))
        if len(images) != 2:
            raise RuntimeError("both Pick cameras are required")
        u = self.adapter.uenv
        target = tuple(float(v) for v in u.subtask_objs[self.target_index].pose.p[0].detach().cpu().tolist())
        base_z = float(scalar(u.agent.base_link.pose.p[:, 2]))
        origin = self.control.pose()
        current = self.current()
        payload = {"skill": "pick", "trigger": reason, "pick_step": current.pick_step,
                   "geometry_source": "privileged_current_simulator_target_pose",
                   "candidate_images_available": False,
                   "current_base_pose_xy_yaw": origin, "target_world_xyz_m": target,
                   "target_relative_to_current_base": target_relative(origin, target, base_z),
                   "tcp_target_distance_m": current.tcp_target_distance_m,
                   "recent_sac_distance_improvement_m":
                       self._sac_distances[-11]-self._sac_distances[-1]
                       if len(self._sac_distances) >= 11 else None,
                   "previous_movement": self._previous_movement,
                   "robot_cumulative_force": current.robot_cumulative_force,
                   "force_limit": current.force_limit, "steps_left": current.steps_left,
                   "grasped": current.grasped,
                   "function_bounds": {"move_distance_m": [MIN_NONZERO, MOVE_MAX_M],
                                       "move_direction_rad": [-math.pi, math.pi],
                                       "turn_abs_rad": [MIN_NONZERO, TURN_MAX_RAD]}}
        return payload, images, origin, target, base_z

    def propose(self, reason):
        self._pending = None
        payload, images, *_ = self._context(reason)
        payload["phase"] = "propose"
        return self.ask(payload, images)

    def preview(self, proposal):
        if proposal["action"] not in ("move", "turn"):
            raise ValueError("only move/turn can be previewed")
        _, _, origin, target, base_z = self._context("proposal_preview")
        delta = ((proposal["distance_m"]*math.cos(proposal["direction_rad"]),
                  proposal["distance_m"]*math.sin(proposal["direction_rad"]), 0.)
                 if proposal["action"] == "move" else (0., 0., proposal["angle_rad"]))
        endpoint = tuple(world_waypoint(origin, delta))
        current = target_relative(origin, target, base_z)
        after = target_relative(endpoint, target, base_z)
        try:
            route = self.validate_route(origin, endpoint, self.adapter)
        except Exception as exc:
            route = None
            rejection = type(exc).__name__
        else:
            rejection = "route_rejected" if route is None else None
        valid = route is not None and len(route) > 0 and tuple(route[-1]) == endpoint
        if not valid and rejection is None:
            rejection = "route_endpoint_mismatch"
        if valid:
            self._pending = {"proposal": proposal, "route": tuple(tuple(p) for p in route),
                             "at_step": self.current().pick_step}
        return {"proposal": proposal, "hypothetical_base_pose_xy_yaw": endpoint,
                "target_after_function": after,
                "change_vs_current": {key: after[key]-current[key] for key in current},
                "route_valid": bool(valid), "route_rejection": None if valid else rejection}

    def commit(self, reason, preview):
        payload, images, *_ = self._context(reason)
        payload["phase"] = "commit"
        payload["preview"] = preview
        return self.ask(payload, images)

    def execute_pending(self):
        pending, self._pending = self._pending, None
        if pending is None or pending["at_step"] != self.current().pick_step:
            raise RuntimeError("no valid preview for current real state")
        key = pending["proposal"]["action"]
        self._offered = {key: pending["route"]}
        result = super().reposition(key)
        self._previous_movement = {"function": pending["proposal"],
                                   "arrived": result.arrived, "reason": result.reason,
                                   "actions": len(result.samples),
                                   "actual_base_pose_xy_yaw": self.control.pose()}
        return result
