"""v6: keyframe-local torso trapezoids, shared with Cartesian release progress."""
import numpy as np
from scipy.spatial.transform import Rotation,Slerp
from .eef_streaming_v2 import torso_trapezoid
from .eef_tools_v5 import FetchToolsV5

VERSION='eef-tool-v6-segment-coupled-r1'


class FetchToolsV6(FetchToolsV5):
    def _plan(self,targets):
        targets=list(targets)
        plan=super()._plan(targets)
        if plan['accepted']:
            ends=[];start=0
            for goal in targets:
                end=next(i+1 for i in range(start,len(plan['points']))
                    if np.allclose(plan['points'][i],goal,atol=1e-10,rtol=0))
                ends.append(end);start=end
            plan['keyframe_ends']=ends
        return plan

    def coupled_schedule(self,plan):
        refs=plan['refs'];all_points=[self.fk.tcp(refs[0])];all_z=[float(refs[0,3])]
        start=0;initial=float(self.previous_delta[3])
        for end in plan.get('keyframe_ends',[len(refs)-1]):
            segment={'refs':refs[start:end+1],'points':plan['points'][start:end]}
            cart=super()._schedule(segment)
            profile=torso_trapezoid(float(refs[start,3]),float(refs[end,3]),
                self.rho[-1],self.beta[-1],initial_delta=initial)
            source_z=profile['q'];count=max(len(cart)-1,len(source_z)-1,1)
            # Only stretch this segment, not unrelated constant-height segments.
            while count<=200:
                z=np.interp(np.linspace(0,len(source_z)-1,count+1),np.arange(len(source_z)),source_z)
                dq=np.diff(z);u=(dq-self.rho[-1]*np.r_[initial,dq[:-1]])/(.1*self.beta[-1])
                if np.max(abs(u))<=1+1e-9:break
                count+=1
            if count>200:raise ValueError('segment reference exceeds 200-step horizon')
            ticks=np.linspace(0,len(cart)-1,count+1);poses=np.asarray(cart)
            rotations=Slerp(np.arange(len(cart)),Rotation.from_matrix(poses[:,:3,:3]))(ticks).as_matrix()
            for k,t in enumerate(ticks[1:],1):
                p=np.eye(4);p[:3,:3]=rotations[k]
                p[:3,3]=[np.interp(t,np.arange(len(cart)),poses[:,j,3]) for j in range(3)]
                all_points.append(p);all_z.append(float(z[k]))
            initial=float(z[-1]-z[-2]);start=end
        return all_points,np.asarray(all_z)
