"""Live floor-route gate plus native step feedback for short Pick adjustments.

The floor mesh proves base-plane containment only.  Whole-body and dynamic
contact outcomes are observed while moving and must be reported separately.
"""
from __future__ import annotations

import math
from pathlib import Path

from .mshab_adapter import jsonable, scalar
from .pose_goal import FloorMesh


class NearPickFloorRoute:
    def __init__(self, adapter, assets):
        u = adapter.uenv
        build = int(scalar(u.build_config_idxs))
        bc = u.scene_builder.build_configs[build]
        filename = Path(bc).stem + ".fetch.navigable_positions_simplified.obj"
        self.mesh = FloorMesh(Path(assets) / "scene_datasets/replica_cad_dataset/configs/scenes" / filename)
        self.adapter = adapter
        adapter.logger.emit("near_pick_floor_route", sha256=self.mesh.sha256,
                            scope="base_floor_only_dynamic_contacts_recorded_during_move")

    def _world_segment(self, start, end, adapter):
        base = jsonable(adapter.uenv.agent.base_link.pose.raw_pose)[0]
        w, x, y, z = base[3:]
        yaw_world = math.atan2(2*(w*z+x*y), 1-2*(y*y+z*z))
        rotation = yaw_world-start[2]
        dx, dy = end[0]-start[0], end[1]-start[1]
        world_end = (base[0]+math.cos(rotation)*dx-math.sin(rotation)*dy,
                     base[1]+math.sin(rotation)*dx+math.cos(rotation)*dy)
        return base[:2], world_end

    def _native_gate_open(self, adapter):
        if adapter is not self.adapter or adapter.ended:
            return False
        info = adapter.last_info
        return not (bool(scalar(info.get("fail", False))) or
                    not bool(scalar(info.get("cumulative_force_within_limit", False))) or
                    bool(scalar(info.get("is_grasped", False))))

    def validate_turn(self, start, end, adapter):
        """A yaw-only action has no floor segment to test.

        The live official task/force gate still applies.  The controller may
        drift in XY while turning; only permit the existing 0.10 m arrival
        tolerance around the original anchor.  Dynamic contact is measured
        during execution, not certified by this preview.
        """
        if not self._native_gate_open(adapter):
            return None
        if (not all(math.isfinite(v) for v in (*start, *end)) or
                math.hypot(end[0]-start[0], end[1]-start[1]) >= .10):
            return None
        return [tuple(end)]

    def diagnose_turn(self, start, end, adapter):
        if not self._native_gate_open(adapter):
            return {"code": "native_gate_changed", "scope": "turn_live_state"}
        return {"code": "turn_anchor_drift", "scope": "turn_live_state",
                "anchor_xy_error_m": math.hypot(end[0]-start[0], end[1]-start[1])}

    def __call__(self, start, end, adapter):
        if not self._native_gate_open(adapter):
            return None
        world_start, world_end = self._world_segment(start, end, adapter)
        if self.mesh.contains_segment(world_start, world_end):
            return [tuple(end)]
        return None

    def diagnose(self, start, end, adapter):
        """Explain the same official floor check without claiming body clearance."""
        if not self._native_gate_open(adapter):
            return {"code": "native_gate_changed", "scope": "base_floor_only"}
        start_xy, end_xy = self._world_segment(start, end, adapter)
        if self.mesh.contains_segment(start_xy, end_xy):
            return {"code": "route_changed_during_check", "scope": "base_floor_only"}
        if not self.mesh.contains_segment(start_xy, start_xy):
            return {"code": "start_outside_navmesh", "scope": "base_floor_only",
                    "first_invalid_world_xy_m": start_xy}
        lo, hi = 0., 1.
        for _ in range(16):
            mid = (lo+hi)/2
            point = (start_xy[0]+mid*(end_xy[0]-start_xy[0]),
                     start_xy[1]+mid*(end_xy[1]-start_xy[1]))
            if self.mesh.contains_segment(start_xy, point):
                lo = mid
            else:
                hi = mid
        point = (start_xy[0]+hi*(end_xy[0]-start_xy[0]),
                 start_xy[1]+hi*(end_xy[1]-start_xy[1]))
        return {"code": "segment_exits_navmesh", "scope": "base_floor_only",
                "first_invalid_fraction_approx": hi,
                "first_invalid_world_xy_m_approx": point,
                "checked_endpoint_world_xy_m": end_xy}
