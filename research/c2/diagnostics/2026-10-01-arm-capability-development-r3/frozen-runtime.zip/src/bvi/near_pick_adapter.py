"""MS-HAB ports for the bounded near-visible Pick protocol.

The caller supplies a floor-route gate and a budgeted GPT function.  Dynamic
contact and force remain live measurements, not a collision-free guarantee.
The official environment remains live through SAC and repositioning.
"""
from __future__ import annotations

import math
import time
from typing import Callable

from .lightnav_skill import FetchNavigationControl, world_waypoint, track_waypoint, wrap
from .mshab_adapter import scalar
from .near_pick_protocol import PickSample
from .near_pick_runtime import MotionResult


def official42_observation(adapter, target_index=0):
    """Recreate upstream SAC's four extra fields from the live Pick state.

    The AC-DiT environment fork appends nine fields to its native 51D state;
    the published SAC checkpoint was trained with agent24 plus extra18.
    Depth history and all simulator state remain unchanged.
    """
    import torch
    from mani_skill.utils.common import flatten_state_dict
    from mani_skill.utils.structs.pose import vectorize_pose

    u = adapter.uenv
    obj = u.subtask_objs[target_index]
    base_inverse = u.agent.base_link.pose.inv()
    extra = {
        "tcp_pose_wrt_base": vectorize_pose(base_inverse * u.agent.tcp.pose),
        "obj_pose_wrt_base": vectorize_pose(base_inverse * obj.pose),
        "goal_pos_wrt_base": torch.zeros((1, 3), device=u.device),
        "is_grasped": u.agent.is_grasping(obj, max_angle=30),
    }
    state = torch.cat((flatten_state_dict(u._get_obs_agent(), use_torch=True),
                       flatten_state_dict(extra, use_torch=True)), dim=1).float()
    if tuple(state.shape) != (1, 42) or not torch.isfinite(state).all():
        raise ValueError("official Pick SAC state42 construction failed")
    raw = adapter.observe().policy
    return {**raw, "state": state}


def load_near_pick_sac(config_path, checkpoint_path, adapter, *, target_index=0):
    """Load the official SAC actor with its original 42D state contract."""
    import torch
    from gymnasium import spaces
    from mshab.agents.sac import Agent as SACAgent
    from .mshab_adapter import load_checkpoint_config

    algo = load_checkpoint_config(config_path).algo
    if algo.name != "sac":
        raise ValueError("near Pick requires official SAC")
    sample = official42_observation(adapter, target_index)
    obs_space = adapter.uenv.single_observation_space
    pixel_spaces = {}
    for key, space in obs_space["pixels"].items():
        shape, low, high = space.shape, space.low, space.high
        if len(shape) == 4:
            shape = (shape[0] * shape[1], shape[-2], shape[-1])
            low = low.reshape((-1, *low.shape[-2:]))
            high = high.reshape((-1, *high.shape[-2:]))
        pixel_spaces[key] = spaces.Box(low, high, shape, space.dtype)
    policy = SACAgent(spaces.Dict(pixel_spaces), (42,),
        adapter.uenv.single_action_space.shape,
        actor_hidden_dims=list(algo.actor_hidden_dims),
        critic_hidden_dims=list(algo.critic_hidden_dims),
        critic_layer_norm=algo.critic_layer_norm,
        critic_dropout=algo.critic_dropout,
        encoder_pixels_feature_dim=algo.encoder_pixels_feature_dim,
        encoder_state_feature_dim=algo.encoder_state_feature_dim,
        cnn_features=list(algo.cnn_features),
        cnn_filters=list(algo.cnn_filters),
        cnn_strides=list(algo.cnn_strides),
        cnn_padding=algo.cnn_padding,
        log_std_min=algo.actor_log_std_min,
        log_std_max=algo.actor_log_std_max,
        device=adapter.uenv.device)
    policy.eval()
    policy.load_state_dict(torch.load(checkpoint_path, map_location=adapter.uenv.device)["agent"],
                           strict=True)
    policy.to(adapter.uenv.device)
    def action_fn(observation):
        return policy.actor(observation["pixels"], observation["state"],
                            compute_pi=False, compute_log_pi=False)[0]
    with torch.no_grad():
        action_fn(sample)
    adapter.logger.emit("near_pick_official_sac_loaded", state_shape=[1, 42],
                        config=str(config_path), checkpoint=str(checkpoint_path))
    return action_fn


DELTAS = (("C1", (.20, 0., 0.)), ("C2", (-.20, 0., 0.)),
          ("C3", (0., .20, 0.)), ("C4", (0., -.20, 0.)),
          ("C5", (0., 0., .35)), ("C6", (0., 0., -.35)))


class NearPickPorts:
    def __init__(self, adapter, policy: Callable, ask: Callable,
                 validate_route: Callable, *, target_index: int = 0,
                 deadline_monotonic: float | None = None):
        if validate_route is None:
            raise ValueError("a live route validator is required")
        self.adapter, self.policy, self.ask = adapter, policy, ask
        self.validate_route = validate_route
        self.target_index = target_index
        self.start_step = adapter.steps
        self.deadline_monotonic = deadline_monotonic
        self.control = FetchNavigationControl(adapter)
        self._offered = {}
        self._last_transition = None
        self._last_sample = None
        if adapter.ended or int(scalar(adapter.uenv.subtask_pointer)) != target_index:
            raise ValueError("a live Pick subtask is required")
        if adapter.uenv.task_plan[target_index].type != "pick":
            raise ValueError("target subtask is not Pick")

    def _measure(self):
        u = self.adapter.uenv
        obj = u.subtask_objs[self.target_index]
        info = self.adapter.last_info
        pointer = int(scalar(u.subtask_pointer))
        if pointer not in (self.target_index, self.target_index + 1):
            raise RuntimeError("native Pick pointer skipped or reversed")
        required = ("robot_cumulative_force", "subtasks_steps_left",
                    "cumulative_force_within_limit", "fail")
        if any(key not in info for key in required):
            raise RuntimeError("official Pick info is incomplete")
        # The native evaluator advances the task pointer in the success step.
        # At that point its info clock and cumulative force belong to the next
        # subtask, so the pointer transition is the strict Pick completion.
        success = pointer == self.target_index + 1
        grasped = bool(scalar(u.agent.is_grasping(obj, max_angle=30)))
        import torch
        distance = float(torch.linalg.vector_norm(u.agent.tcp.pose.p-obj.pose.p).item())
        force = float(scalar(info["robot_cumulative_force"]))
        force_ok = bool(scalar(info["cumulative_force_within_limit"]))
        failed = bool(scalar(info["fail"])) or not force_ok
        limit = float(u.pick_cfg.robot_cumulative_force_limit)
        return PickSample(self.adapter.steps-self.start_step, distance, force, limit,
                          int(scalar(info["subtasks_steps_left"])), grasped,
                          success, failed)

    def current(self):
        if self._last_sample is None:
            self._last_sample = self._measure()
        return self._last_sample

    def _step(self, action):
        if self.deadline_monotonic is not None and time.monotonic() >= self.deadline_monotonic:
            raise TimeoutError("near Pick lab process wall limit")
        if self.adapter.ended:
            raise RuntimeError("cannot act after native termination")
        self._last_transition = self.adapter.step(tuple(action))
        self._last_sample = self._measure()
        return self._last_sample

    def sac_step(self):
        import torch

        with torch.no_grad():
            raw = self.policy(official42_observation(self.adapter, self.target_index))
        if tuple(raw.shape) != (1, 13) or not torch.isfinite(raw).all():
            raise RuntimeError("official SAC action invalid")
        action = tuple(float(v) for v in raw[0].detach().cpu().tolist())
        bounded = tuple(max(lo, min(hi, x)) for x, lo, hi in zip(
            action, self.adapter.action_bounds.low, self.adapter.action_bounds.high))
        self.adapter.logger.emit("near_pick_sac_action", pick_step=self.current().pick_step,
                                 raw_action=action, bounded_action=bounded)
        return self._step(bounded)

    def candidate_ids(self):
        if self.current().grasped or self.adapter.ended:
            return ()
        origin = self.control.pose()
        offers = {}
        for candidate_id, delta in DELTAS:
            destination = tuple(world_waypoint(origin, delta))
            validator = (getattr(self.validate_route, "validate_turn", self.validate_route)
                         if candidate_id in ("C5", "C6") else self.validate_route)
            try:
                route = validator(origin, destination, self.adapter)
            except Exception as exc:
                self.adapter.logger.emit("near_pick_route_rejected", candidate_id=candidate_id,
                                         reason=type(exc).__name__)
                continue
            if route is not None and len(route) > 0 and tuple(route[-1]) == destination:
                offers[candidate_id] = tuple(tuple(point) for point in route)
        self._offered = offers
        return tuple(offers)

    def ask_gpt(self, reason, eligible_ids):
        if self.deadline_monotonic is not None and time.monotonic() >= self.deadline_monotonic:
            raise TimeoutError("near Pick lab process wall limit")
        obs = self.adapter.observe()
        images = tuple(frame for frame in obs.images if frame.camera in ("fetch_head", "fetch_hand"))
        if len(images) != 2:
            raise RuntimeError("both Pick cameras are required")
        current = self.current()
        payload = {"skill": "pick", "trigger": reason, "pick_step": current.pick_step,
                   "tcp_target_distance_m": current.tcp_target_distance_m,
                   "robot_cumulative_force": current.robot_cumulative_force,
                   "force_limit": current.force_limit, "steps_left": current.steps_left,
                   "grasped": current.grasped, "eligible_candidates": [
                       {"candidate_id": key, "route": self._offered[key]} for key in eligible_ids]}
        return self.ask(payload, images)

    def reposition(self, candidate_id):
        if candidate_id not in self._offered:
            raise ValueError("candidate was not offered in the current state")
        route = self._offered[candidate_id]
        self._offered = {}
        self.control.capture_hold()
        samples = []
        waypoint = 0
        settled = 0
        for _ in range(80):
            current = self.current()
            if (current.grasped or current.official_success or current.official_fail or
                    current.steps_left <= 0 or current.robot_cumulative_force >= current.force_limit):
                return MotionResult(candidate_id, tuple(samples), False, "native_gate_changed")
            # The route validator must recheck the live state before every action.
            validator = (getattr(self.validate_route, "validate_turn", self.validate_route)
                         if candidate_id in ("C5", "C6", "turn") else self.validate_route)
            if validator(self.control.pose(), route[-1], self.adapter) is None:
                return MotionResult(candidate_id, tuple(samples), False, "route_no_longer_valid")
            pose = self.control.pose()
            if candidate_id in ("C5", "C6", "turn"):
                # The C0 settle can leave lateral momentum. A yaw candidate
                # controls heading directly; chasing centimetres of XY drift
                # made the original tracker rotate away from its heading goal.
                yaw_error = wrap(route[-1][2] - pose[2])
                xy_error = math.hypot(route[-1][0] - pose[0], route[-1][1] - pose[1])
                linear = 0.
                angular = max(-.6, min(.6, 2*yaw_error))
                reached = abs(yaw_error) < .06 and xy_error < .10
            else:
                linear, angular, reached = track_waypoint(pose, route[waypoint])
            if reached and waypoint + 1 < len(route):
                waypoint += 1
                linear, angular, reached = track_waypoint(self.control.pose(), route[waypoint])
            settled = settled + 1 if reached else 0
            sample = self._step(self.control.action(0., 0.) if reached else
                                self.control.action(linear, angular))
            samples.append(sample)
            if sample.official_success or sample.official_fail or sample.steps_left == 0:
                return MotionResult(candidate_id, tuple(samples), False, "native_terminal_during_move")
            if settled >= 3 and waypoint == len(route)-1:
                return MotionResult(candidate_id, tuple(samples), True, "measured_arrival")
        return MotionResult(candidate_id, tuple(samples), False, "movement_action_limit")
