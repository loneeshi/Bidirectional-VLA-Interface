"""Separate live grasp progress from geometry used to plan a base correction."""
from __future__ import annotations

import math
import struct
import time

from .lightnav_skill import world_waypoint, wrap
from .mshab_adapter import jsonable, scalar
from .seed9_geometry import (GeometryPickPorts, MIN_NONZERO, MOVE_MAX_M,
                             TURN_MAX_RAD, target_relative)


class InputContractError(RuntimeError):
    """Required same-frame Pick observation is absent or malformed."""


def _yaw(quaternion):
    w, x, y, z = (float(v) for v in quaternion)
    return math.atan2(2*(w*z+x*y), 1-2*(y*y+z*z))


def projected_base_link(control_now, control_end, base_now):
    """Transfer the controller's world XY and yaw deltas to base_link.

    The controller qpos XY differs from base_link XY by about a metre in this
    Fetch runtime, but an in-place yaw command does not orbit base_link around
    that offset.  Rotating the offset here invented a base translation.
    """
    delta = wrap(control_end[2] - control_now[2])
    return (base_now[0] + control_end[0] - control_now[0],
            base_now[1] + control_end[1] - control_now[1],
            wrap(base_now[2]+delta))


class FeedbackPickPorts(GeometryPickPorts):
    def __init__(self, *args, target_id, **kwargs):
        super().__init__(*args, **kwargs)
        self.target_id = str(target_id)
        self._sac_forces = [self.current().robot_cumulative_force]

    def sac_step(self):
        sample = super().sac_step()
        self._sac_forces.append(sample.robot_cumulative_force)
        return sample

    def force_snapshot(self):
        info = self.adapter.last_info
        required = ("robot_force", "robot_target_pairwise_force")
        if any(key not in info for key in required):
            raise InputContractError("current robot and target contact force required")
        robot_force, target_force = (float(scalar(info[key])) for key in required)
        if not all(math.isfinite(v) and v >= 0 for v in (robot_force, target_force)):
            raise InputContractError("current contact force invalid")
        return {"robot_force_n": robot_force,
                "robot_target_pairwise_force_n": target_force}

    def _scene(self, trigger):
        if self.deadline_monotonic is not None and time.monotonic() >= self.deadline_monotonic:
            raise TimeoutError("seed8 lab process wall limit")
        obs = self.adapter.observe()
        images = tuple(frame for frame in obs.images if frame.camera in ("fetch_head", "fetch_hand"))
        if len(images) != 2:
            raise InputContractError("both Pick cameras are required")
        for frame in images:
            if (len(frame.data) < 24 or
                    not frame.data.startswith(b"\x89PNG\r\n\x1a\n") or
                    struct.unpack(">II", frame.data[16:24]) != (128, 128)):
                raise InputContractError("Pick camera must be current 128x128 PNG")
        u = self.adapter.uenv
        obj = u.subtask_objs[self.target_index]
        target = tuple(float(v) for v in obj.pose.p[0].detach().cpu().tolist())
        tcp = tuple(float(v) for v in u.agent.tcp.pose.p[0].detach().cpu().tolist())
        raw_base = jsonable(u.agent.base_link.pose.raw_pose)[0]
        base = (float(raw_base[0]), float(raw_base[1]), _yaw(raw_base[3:]))
        base_z = float(raw_base[2])
        current = self.current()
        contact = self.force_snapshot()
        dx, dy, dz = (target[i]-tcp[i] for i in range(3))
        forward = math.cos(base[2])*dx+math.sin(base[2])*dy
        left = -math.sin(base[2])*dx+math.cos(base[2])*dy
        info = self.adapter.last_info
        last_motion = (None if self._previous_movement is None else {
            key: self._previous_movement[key] for key in
            ("function", "arrived", "reason", "actions",
             "actual_base_link_pose_xy_yaw") if key in self._previous_movement})
        base_geometry = target_relative(base, target, base_z)
        progress = {
            "skill": "pick", "phase": "assess", "trigger": trigger,
            "frame_id": obs.frame_id, "pick_step": current.pick_step,
            "target_id": self.target_id, "target_pose_source": "privileged_simulator",
            "tcp_and_base_pose_source": "privileged_simulator_current_frame",
            "force_source": "official_native_info_current_frame",
            "cameras": [frame.camera for frame in images],
            "tcp_target_reference": "object_pose_origin_not_guaranteed_grasp_point",
            "tcp_role": "gripper_progress_not_base_reposition_target",
            "base_geometry_role": "reposition_decision",
            "current_base_link_pose_xy_yaw": base,
            "target_relative_to_base_link": base_geometry,
            "target_minus_tcp_xyz_in_base_link_m": [forward, left, dz],
            "tcp_target_distance_m": current.tcp_target_distance_m,
            "recent_sac_distance_improvement_m":
                self._sac_distances[-11]-self._sac_distances[-1]
                if len(self._sac_distances) >= 11 else None,
            "grasped": current.grasped,
            "robot_force_n": contact["robot_force_n"],
            "robot_target_pairwise_force_n": contact["robot_target_pairwise_force_n"],
            "force_interpretation": (
                "positive_robot_force_with_zero_target_pairwise_force_means_"
                "no_measured_target_contact_not_collision_identity"),
            "last_sac_force_increment_n": (
                self._sac_forces[-1]-self._sac_forces[-2]
                if len(self._sac_forces) >= 2 else None),
            "last_5_sac_force_increment_n": (
                self._sac_forces[-1]-self._sac_forces[max(0, len(self._sac_forces)-6)]
                if len(self._sac_forces) >= 2 else None),
            "robot_cumulative_force": current.robot_cumulative_force,
            "force_limit": current.force_limit, "steps_left": current.steps_left,
            "previous_movement": last_motion,
        }
        return progress, images, self.control.pose(), base, base_z, target

    def _required_scene(self, trigger):
        try:
            return self._scene(trigger)
        except (InputContractError, TimeoutError):
            raise
        except Exception as exc:
            raise InputContractError(
                "current Pick observation invalid: " + type(exc).__name__) from exc

    def assess(self, trigger):
        progress, images, *_ = self._required_scene(trigger)
        return self.ask(progress, images)

    def plan(self, trigger, route_error):
        progress, images, control, base, base_z, target = self._required_scene(trigger)
        progress["phase"] = "plan"
        progress["current_base_link_pose_xy_yaw"] = base
        progress["target_relative_to_base_link"] = target_relative(base, target, base_z)
        progress["previous_movement"] = self._previous_movement
        progress["function_bounds"] = {
            "move_distance_m": [MIN_NONZERO, MOVE_MAX_M],
            "move_direction_rad": [-math.pi, math.pi],
            "turn_abs_rad": [MIN_NONZERO, TURN_MAX_RAD],
        }
        progress["coordinate_convention"] = "+x forward, +y left, +z up; angles in radians"
        progress["route_error_from_previous_proposal"] = route_error
        return self.ask(progress, images)

    def preview(self, proposal):
        if proposal["action"] not in ("move", "turn"):
            raise ValueError("only move/turn can be previewed")
        _, _, origin, base, base_z, target = self._required_scene("proposal_preview")
        delta = ((proposal["distance_m"]*math.cos(proposal["direction_rad"]),
                  proposal["distance_m"]*math.sin(proposal["direction_rad"]), 0.)
                 if proposal["action"] == "move" else (0., 0., proposal["angle_rad"]))
        endpoint = tuple(world_waypoint(origin, delta))
        projected_base = projected_base_link(origin, endpoint, base)
        before = target_relative(base, target, base_z)
        after = target_relative(projected_base, target, base_z)
        validator = (getattr(self.validate_route, "validate_turn", self.validate_route)
                     if proposal["action"] == "turn" else self.validate_route)
        try:
            route = validator(origin, endpoint, self.adapter)
        except Exception as exc:
            route = None
            rejection = {"code": "route_check_exception", "type": type(exc).__name__}
        else:
            rejection = None
            if route is None:
                diagnose = getattr(self.validate_route,
                                   "diagnose_turn" if proposal["action"] == "turn"
                                   else "diagnose", None)
                rejection = diagnose(origin, endpoint, self.adapter) if diagnose else {
                    "code": "route_rejected", "scope": "base_floor_only"}
        valid = route is not None and len(route) > 0 and tuple(route[-1]) == endpoint
        if not valid and rejection is None:
            rejection = {"code": "route_endpoint_mismatch", "scope": "base_floor_only"}
        self._pending = ({"proposal": proposal, "route": tuple(tuple(p) for p in route),
                          "at_step": self.current().pick_step} if valid else None)
        return {"proposal": proposal,
                "projected_base_link_pose_xy_yaw": projected_base,
                "target_before_function": before, "target_after_function": after,
                "change_vs_current": {key: after[key]-before[key] for key in before},
                "route_valid": bool(valid), "route_rejection": rejection,
                "prediction_scope": (
                    "in_place_turn_no_floor_segment_dynamic_contact_unverified"
                    if proposal["action"] == "turn" else
                    "base_link_geometry_and_base_floor_route_only")}

    def commit(self, trigger, preview):
        progress, images, *_ = self._required_scene(trigger)
        progress["phase"] = "commit"
        progress["preview"] = preview
        return self.ask(progress, images)

    def execute_pending(self):
        result = super().execute_pending()
        # Movement changes TCP distance without any SAC action.  Start a new
        # SAC-only trend window so the next ten-step delta excludes motion.
        self._sac_distances = [self.current().tcp_target_distance_m]
        self._sac_forces = [self.current().robot_cumulative_force]
        raw_base = jsonable(self.adapter.uenv.agent.base_link.pose.raw_pose)[0]
        self._previous_movement["actual_base_link_pose_xy_yaw"] = (
            float(raw_base[0]), float(raw_base[1]), _yaw(raw_base[3:]))
        self._previous_movement.pop("actual_base_pose_xy_yaw", None)
        return result
