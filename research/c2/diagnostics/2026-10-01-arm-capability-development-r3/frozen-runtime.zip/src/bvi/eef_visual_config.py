"""Frozen first visual pilot. Changing any constant requires a new version."""
VERSION = 'eef-visual-pilot-v3-active-head'
RESOLUTION = 2048
POSITIONS = (5, 55, 58)
MODEL = 'gpt-6-astra'
OUTPUT_CAP = 4000
TOOL_CAP = 25
STEP_CAP = 200
LOOK_CAP = 40
HEAD_LIMITS = ((-1.57, 1.57), (-.76, 1.45))
HEAD_ERROR = .02
HEAD_SPEED = .03
HEAD_STABLE_READINGS = 2
INPUT_BYTE_CAP = 14336
CONTEXT_LIMIT = 1050000
GPU_UUID = 'GPU-b7ebba23-7824-7601-df32-be55628936c3'
