"""Batch read of robot-to-scene contact impulses for the Pick census.

The GPU API reports the last physics-step contact impulse for each body pair.
Summing these sampled impulses over control steps is a diagnostic proxy, not a
complete integration over every physics substep. All robot-to-external pairs
are queried together so attribution does not depend on a hand-picked obstacle.
"""

from __future__ import annotations

import torch


class CensusContactMeter:
    def __init__(self, uenv, target_entity, max_pairs=10000):
        if uenv.num_envs != 1 or not uenv.scene.gpu_sim_enabled:
            raise ValueError("Census contact meter requires one GPU environment")
        scene = uenv.scene
        robot = uenv.agent.robot
        robot_links = list(robot.links)
        external = list(scene.actors.values())
        external += [link for articulation in scene.articulations.values()
                     if articulation is not robot and articulation.name != robot.name
                     for link in articulation.links]
        if not robot_links or not external:
            raise ValueError("Incomplete robot/scene contact inventory")
        unique = set()
        body_pairs = []
        labels = []
        for link in robot_links:
            for other in external:
                if len(link._bodies) != 1 or len(other._bodies) != 1:
                    raise ValueError("Contact body inventory is not single-scene")
                left, right = link._bodies[0], other._bodies[0]
                identity = (id(left), id(right))
                if identity in unique:
                    continue
                unique.add(identity)
                body_pairs.append((left, right))
                owner = getattr(right, "entity", None)
                labels.append((link.name, other.name,
                               owner is target_entity or (owner is not None
                                                          and owner.name == target_entity.name)))
        if not 0 < len(body_pairs) <= max_pairs:
            raise ValueError(f"Census contact pair limit: {len(body_pairs)}")
        self.scene = scene
        self.query = scene.px.gpu_create_contact_pair_impulse_query(body_pairs)
        self.labels = labels
        self.pair_count = len(labels)
        self.target_name = target_entity.name
        if not any(is_target for _, _, is_target in labels):
            sample = [(other.name, getattr(getattr(other._bodies[0], "entity", None), "name", None))
                      for other in external[:12]]
            raise ValueError(f"Target entity {target_entity.name!r} missing from complete contact inventory; sample={sample}")
        self.physics_timestep_seconds = float(scene.px.timestep)
        if not 0 < self.physics_timestep_seconds < 1:
            raise ValueError("Invalid physics timestep for contact force")

    def read(self):
        self.scene.px.gpu_query_contact_pair_impulses(self.query)
        impulses = self.query.cuda_impulses.torch().clone()
        if tuple(impulses.shape) != (self.pair_count, 3):
            raise ValueError("Contact query output shape differs from pair inventory")
        magnitudes = torch.linalg.vector_norm(impulses, dim=-1)
        if not torch.isfinite(magnitudes).all():
            raise ValueError("Non-finite pairwise contact impulse")
        active = (magnitudes > 0).nonzero().flatten().detach().cpu().tolist()
        values = magnitudes[active].detach().cpu().tolist()
        target_impulse = 0.0
        external_impulse = 0.0
        non_target = []
        for index, magnitude in zip(active, values):
            link, other, is_target = self.labels[index]
            external_impulse += magnitude
            if is_target:
                target_impulse += magnitude
            else:
                non_target.append({"robot_link": link, "other": other,
                                   "impulse_ns": float(magnitude)})
        return {"pair_count": self.pair_count,
                "robot_total_contact_impulse_ns": float(external_impulse),
                "target_contact_impulse_ns": float(target_impulse),
                "target_contact_force_n": float(target_impulse / self.physics_timestep_seconds),
                "physics_timestep_seconds": self.physics_timestep_seconds,
                "non_target_contacts": non_target,
                "measurement_scope": "sampled_last_physics_step_pairwise_impulses"}
