"""v9 parks torso at its robot-model stopping position during close alignment."""
import numpy as np
from .eef_tools import vector
from .eef_streaming import grip_band
from .eef_tools_v3 import pose_error
from .eef_tools_v8 import FetchToolsV8,TORSO_STIFFNESS,TORSO_MOVING_MASS,TORSO_VELOCITY_SECONDS,moving_torso_mass,TORSO_DAMPING
VERSION='eef-tool-v9-torso-stopping-anchor-r1'
class FetchToolsV9(FetchToolsV8):
    def set_gripper(self,command):
        band=grip_band(command); before=self.steps
        self.deadline=min(self.max_steps,before+self.p.close_align_cap+self.p.close_wait_cap)
        entering=band==0 and grip_band(self.gripper)!=0
        anchor=vector(self.read_qpos(),15).copy()
        if entering:
            # Park at the nominal critically damped stopping position, avoiding
            # the reverse excursion caused by returning to the entry position.
            omega=np.sqrt(TORSO_STIFFNESS/TORSO_MOVING_MASS)
            lo,hi,_=self.fk.limits['torso_lift_joint']
            anchor[3]=np.clip(anchor[3]+vector(self.read_qvel(),15)[3]/omega,lo,hi)
        previous_action=np.zeros(13)
        alignment=None
        if entering:
            pe,re=pose_error(self.fk,self.read_qpos(),self.last_goal)
            while ((pe>self.p.position_tolerance or re>self.p.rotation_tolerance
                    or abs(self.previous_delta[3])>=self.p.torso_stable)
                   and self.steps-before<self.p.close_align_cap and self._available()):
                target,solved=self._compensate(self.last_goal)
                if solved.reason=='jump_rejected':
                    return {'accepted':False,'reason':'jump_rejected','steps_used':self.steps-before}
                # Keep these references fixed throughout this command. Arm IK
                # still uses actual measured torso height, never an ideal height.
                target[[3,4,6]]=anchor[[3,4,6]]
                action=self.settling_action(target,previous_action)
                self._step(action,'close_align',ik_reason=solved.reason,
                           control='damped_native_position',reference_qpos=target.tolist(),
                           torso_anchor_m=float(anchor[3]))
                previous_action=action
                pe,re=pose_error(self.fk,self.read_qpos(),self.last_goal)
            alignment={'position_error_m':pe,'rotation_error_rad':re,
                       'torso_delta_m':abs(float(self.previous_delta[3])),
                       'steps_used':self.steps-before,'torso_anchor_m':float(anchor[3])}
            if (pe>self.p.position_tolerance or re>self.p.rotation_tolerance
                    or abs(self.previous_delta[3])>=self.p.torso_stable or not self._available()):
                return {'accepted':False,'reason':'close_alignment_failed','alignment':alignment,
                        'steps_used':self.steps-before}
        self.gripper=float(command)
        # Hold a single achieved arm posture during finger motion. The torso
        # anchor persists from command entry; it is never reset at every step.
        hold=vector(self.read_qpos(),15).copy(); hold[[3,4,6]]=anchor[[3,4,6]]
        wait_start=self.steps; stable=0; previous=float(self.read_finger())
        cap=self.p.close_wait_cap if entering else 1
        while self.steps-wait_start<cap and self._available():
            action=self.settling_action(hold,previous_action)
            self._step(action,'gripper',control='damped_native_position',
                       reference_qpos=hold.tolist(),torso_anchor_m=float(anchor[3]))
            previous_action=action
            current=float(self.read_finger())
            stable=stable+1 if abs(current-previous)<self.p.finger_stable else 0
            previous=current
            if entering and stable>=2:
                break
        return {'accepted':self.steps>wait_start,
                'reason':'ok' if self.steps>wait_start else 'terminal_or_budget',
                'steps_used':self.steps-before,'alignment':alignment,'enter_closed':entering,
                'command':self.gripper,'finger_distance_m':previous,
                'stable':stable>=2 if entering else None,'control':'damped_native_position'}
