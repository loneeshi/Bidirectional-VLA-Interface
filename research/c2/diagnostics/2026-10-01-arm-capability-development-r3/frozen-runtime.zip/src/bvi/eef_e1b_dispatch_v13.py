"""One E1-B call, with readable invalid parameters and no hidden retries."""
from .eef_e1b_contract import validate_call, public_result
from .eef_tools import pose


def dispatch(executor, call):
    try:
        validate_call(call)
    except (ValueError, TypeError, KeyError) as error:
        return None, {'accepted': False, 'reason': 'invalid_tool_call',
                      'parameter_error': str(error)[:150], 'steps_used': 0}
    tool=call['tool'];before=executor.steps
    goals=[pose(p['position'],p['quaternion_xyzw']) for p in call['poses']]
    if tool in ('done','give_up','check_path'):
        entry=executor._snapshot()
        ready=executor.prepare_tool(80)
        executor.call_records.append({'tool':tool,'entry':entry,'exit':executor._snapshot(),'settle_steps':executor.steps-before})
        if not ready:
            return call, public_result({'accepted':False,'reason':'official_terminated' if executor.stopped else 'base_not_settled','steps_used':executor.steps-before})
    if tool in ('done','give_up'):
        result={'accepted':True,'reason':tool}
    elif tool=='check_path':result=executor.check_path(goals)
    elif tool=='move_base':result=executor.move_base(call['turn_rad'],call['forward_m'])
    elif tool=='move_to':result=executor.move_to(goals[0],max_steps=60)
    elif tool=='move_eef_chunk':result=executor.move_eef_chunk(goals,max_steps=60)
    elif tool=='set_gripper':result=executor.set_gripper(call['gripper'])
    else:result=executor.return_to_rest()
    return call, public_result({**result,'steps_used':executor.steps-before})
