"""v7 skips actions for already-reached references, retaining every IK check."""
import numpy as np
from .eef_tools import transform,vector
from .eef_tools_v3 import ARM_IDX,periodic_delta,pose_error
from .eef_tools_v6 import FetchToolsV6
VERSION='eef-tool-v7-segment-coupled-release-r1'

class FetchToolsV7(FetchToolsV6):
    def move_eef_chunk(self,targets,*,max_steps):
        before=self.steps;self.deadline=min(self.max_steps,before+max_steps)
        plan=self._plan(targets)
        if not plan['accepted']:
            return {'arrived':False,'reason':plan['reason'],'steps_used':0,
                    'plan':{k:v for k,v in plan.items() if k not in ('refs','points')}}
        try:points,heights=self.coupled_schedule(plan)
        except ValueError as exc:
            return {'arrived':False,'reason':'reference_timing_infeasible','detail':str(exc),'steps_used':0}
        cursor=0;waits=0;reason='tool_step_limit'
        previous=vector(self.read_qpos(),15).copy()
        while cursor<len(points)-1 and self._available():
            target,solved=self._compensate(points[cursor+1])
            if solved.reason=='jump_rejected':reason='jump_rejected';break
            if not solved.accepted:waits+=1
            target[3]=heights[cursor+1]
            # A reference already inside the frozen release tolerances needs
            # no extra environment action. Still solve/check every reference.
            at_reference=periodic_delta(target,vector(self.read_qpos(),15))
            if solved.accepted and np.max(abs(at_reference[ARM_IDX]))<=self.p.release_rotation and abs(at_reference[3])<=self.p.release_torso:
                cursor+=1
                continue
            delta=np.zeros(15)
            if solved.accepted:delta[ARM_IDX]=periodic_delta(target,previous)[ARM_IDX]
            delta[3]=target[3]-previous[3]
            self._step(self.inverse_action(delta,previous),'move',reference_index=cursor+1,
                torso_reference_m=float(target[3]),ik_reason=solved.reason,
                reference_clock='shared_release_cursor')
            error=periodic_delta(target,vector(self.read_qpos(),15))
            released=np.max(abs(error[ARM_IDX]))<=self.p.release_rotation and abs(error[3])<=self.p.release_torso
            if solved.accepted and released:cursor+=1
            previous=target.copy()
        goal=transform(targets[-1]);self.last_goal=goal
        pe,re=pose_error(self.fk,self.read_qpos(),goal)
        while cursor==len(points)-1 and (pe>self.p.endpoint_position or re>self.p.endpoint_rotation) and self._available():
            target,solved=self._compensate(goal)
            if solved.reason=='jump_rejected':reason='jump_rejected';break
            if not solved.accepted:waits+=1
            self._step(self.inverse_action(np.zeros(15),target),'endpoint',ik_reason=solved.reason)
            pe,re=pose_error(self.fk,self.read_qpos(),goal)
        arrived=cursor==len(points)-1 and pe<=self.p.endpoint_position and re<=self.p.endpoint_rotation and reason!='jump_rejected'
        if arrived:self.last_plan_endpoint=plan['refs'][-1].copy()
        return {'arrived':bool(arrived),'reason':'ok' if arrived else reason,'steps_used':self.steps-before,
            'position_error_m':pe,'rotation_error_rad':re,'arm_ik_wait_steps':waits,
            'torso_target_m':float(plan['refs'][-1,3]),'reference_count':len(points),
            'reference_completed':cursor==len(points)-1,'reference_clock':'shared_release_cursor'}
