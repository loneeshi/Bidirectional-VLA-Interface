"""CPU request/lineage/budget gates and provider response parser; no networking."""
import json
import math
from decimal import Decimal
from .eef_visual_config import *
from .eef_visual_contract import (validate_call, validate_reflection, reasoning_summaries,
    build_wire, audit_wire, reflection_wire, canonical)

IMAGE_TOKENS = 4 * math.ceil(math.ceil(RESOLUTION/32)**2 * 1.2)


def input_reserve(turn):
    if type(turn) is not int or not 0 <= turn <= TOOL_CAP: raise ValueError('request index')
    # Includes every prior high-resolution image, text, maximum output and framing.
    return (turn+1)*(INPUT_BYTE_CAP+1024+IMAGE_TOKENS)+turn*OUTPUT_CAP


def cost(inp, out, *, reserve_write=False):
    rate = Decimal('12.5') if reserve_write else Decimal('10')
    output_rate = Decimal('50')
    if inp > 272000: rate *= 2; output_rate *= Decimal('1.5')
    return (Decimal(inp)*rate+Decimal(out)*output_rate)/1000000


def reserve(turn):
    count = input_reserve(turn)
    if count+OUTPUT_CAP > CONTEXT_LIMIT: raise ValueError('context exhausted; no truncation')
    return cost(count, OUTPUT_CAP, reserve_write=True)


def build_request(bundle, entries, positions, usd_cap, authorization_sha256):
    kind = bundle.get('kind'); turn = bundle.get('turn'); position = bundle.get('position')
    expected = {'position', 'turn', 'kind', 'authorization_sha256'} | (
        {'observation', 'sensor_manifest'} if kind == 'tool' else {'outcome', 'termination_category'})
    if kind not in ('tool', 'reflection') or set(bundle) != expected or bundle['authorization_sha256'] != authorization_sha256:
        raise ValueError('request bundle whitelist or authorization')
    if tuple(positions) != POSITIONS or position not in positions: raise ValueError('frozen visual roster')
    # Any unknown transport outcome closes the whole batch, including other cases.
    if any(e['status'] not in ('valid', 'invalid_call') for e in entries): raise ValueError('batch has unknown request; no retry')
    local = [e for e in entries if e['position'] == position]
    if any(e['kind'] == 'reflection' for e in local): raise ValueError('attempt already reflected')
    tools = [e for e in local if e['kind'] == 'tool']
    if turn != len(tools) or (kind == 'tool' and turn >= TOOL_CAP) or (kind == 'reflection' and not tools): raise ValueError('request sequence')
    if local and (not isinstance(local[-1].get('provider_id'), str) or not local[-1]['provider_id'].startswith('resp_')):
        raise ValueError('missing response chain')
    previous = local[-1]['provider_id'] if local else None
    amount = reserve(turn)
    committed = sum((max(Decimal(e['reserve_usd']), Decimal(e.get('estimated_usd') or 0)) for e in entries), Decimal(0))
    if len(entries) >= 78 or committed+amount > Decimal(usd_cap): raise ValueError('authorized request/USD cap')
    if kind == 'tool':
        wire = build_wire(bundle['observation'], bundle['sensor_manifest'], turn, previous)
        audit_wire(wire, bundle['observation'], bundle['sensor_manifest'], turn, previous)
    else: wire = reflection_wire(bundle['outcome'], bundle['termination_category'], previous)
    return wire, amount


def parse_response(raw, turn, *, reflection=False):
    body = json.loads(raw); usage = body.get('usage') or {}
    inp, out = usage.get('input_tokens'), usage.get('output_tokens')
    result = {'status': 'censored', 'reason': 'provider_contract', 'call': None, 'reflection': None,
              'provider_id': body.get('id'), 'returned_model': body.get('model'), 'usage': usage,
              'input_tokens': inp, 'output_tokens': out, 'estimated_usd': None,
              'reasoning_summaries': reasoning_summaries(body)}
    if type(inp) is int and inp >= 0 and type(out) is int and out >= 0:
        result['estimated_usd'] = str(cost(inp, out, reserve_write=True))
    if (body.get('status') != 'completed' or body.get('model') != MODEL or body.get('service_tier') not in ('default', None)
        or not isinstance(body.get('id'), str) or not body['id'].startswith('resp_') or result['estimated_usd'] is None
        or inp > input_reserve(turn) or out > OUTPUT_CAP): return result
    texts = [p['text'] for item in body.get('output', []) if item.get('type') == 'message'
             for p in item.get('content', []) if p.get('type') == 'output_text']
    try:
        if len(texts) != 1: return result
        value = json.loads(texts[0])
        (validate_reflection if reflection else validate_call)(value)
    except (TypeError, ValueError, KeyError):
        return {**result, 'status': 'censored' if reflection else 'invalid_call', 'reason': 'invalid_tool_call'}
    return {**result, 'status': 'valid', 'reason': None, 'call': None if reflection else value,
            'reflection': value if reflection else None}
