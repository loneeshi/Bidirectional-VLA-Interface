"""Zero-step queries; v13 actions; only measured feedback crosses the boundary."""
from .eef_compact_contract import validate_call, public_result
from .eef_tools import pose
from .eef_e1b2_dispatch import AttemptAccounting


def dispatch(executor, call, depth, observation_ids=()):
    before = executor.steps
    try:
        validate_call(call)
        tool = call['tool']
        goals = [pose(p['position'], p['quaternion_xyzw']) for p in call['poses']]
        if tool in ('done', 'give_up'): result = {'accepted': True, 'reason': tool}
        elif tool == 'recall_observation':
            if call['observation_id'] not in observation_ids: raise ValueError('recall requires an archived ID from this attempt')
            result = {'accepted':True,'readonly':True,'observation_id':call['observation_id'],'reason':'archived_images_next_request'}
        elif tool == 'check_path':
            result = {**executor.check_path(goals), 'readonly': True, 'minimum_steps_is_lower_bound': True}
        elif tool == 'locate_point':
            result = depth.locate(call['camera'], call['pixel'], call['observation_id'], executor.read_qpos())
        elif tool == 'look': result = executor.look(call['pan_rad'], call['tilt_rad'])
        elif tool == 'move_base': result = executor.move_base(call['turn_rad'], call['forward_m'])
        elif tool == 'move_to': result = executor.move_to(goals[0], max_steps=60)
        elif tool == 'move_eef_chunk': result = executor.move_eef_chunk(goals, max_steps=60)
        elif tool == 'set_gripper': result = executor.set_gripper(call['gripper'])
        else: result = executor.return_to_rest()
    except (ValueError, TypeError, KeyError) as error:
        # Validation and stale pixels can fail without action. An execution
        # exception after stepping is infrastructure failure, not invalid input.
        if executor.steps != before: raise
        return None, {'accepted': False, 'reason': 'invalid_tool_call',
                      'parameter_error': str(error)[:150], 'steps_used': 0, 'settle_steps': 0,
                      'motion_steps': 0, 'steps_remaining': executor.max_steps-executor.steps}
    used = executor.steps-before
    settling = sum(t['kind'] == 'base_settle' for t in executor.trace if t['step'] > before)
    return call, public_result({**result, 'steps_used': used, 'settle_steps': settling,
                               'motion_steps': used-settling, 'steps_remaining': executor.max_steps-executor.steps})
