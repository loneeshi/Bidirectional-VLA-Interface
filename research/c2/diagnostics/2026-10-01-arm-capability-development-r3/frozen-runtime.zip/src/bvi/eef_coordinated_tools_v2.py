"""Joint-path time parameterization; base/look control remains inherited v13.
No scene geometry. FK references share the very same arm/torso joint curve.
"""
import numpy as np
from .eef_visual_tools import VisualTools as PreviousVisualTools
from .eef_tools_v3 import ARM_IDX, periodic_delta
VERSION = 'eef-coordinated-arm-v2'

class CoordinatedVisualToolsV2(PreviousVisualTools):
    def coupled_schedule(self, plan):
        refs=np.asarray(plan['refs'],dtype=float).copy()
        for i in range(1,len(refs)):
            refs[i]=refs[i-1]+periodic_delta(refs[i],refs[i-1])
        speeds=np.asarray(self.model['reference_speed_limits'])[:7]
        lengths=np.maximum(np.max(abs(np.diff(refs[:,ARM_IDX],axis=0))/speeds,axis=1),1e-8)
        times=np.r_[0,np.cumsum(lengths)]
        initial=float(self.previous_delta[3])
        for count in range(max(1,int(np.ceil(times[-1]))),201):
            t=np.linspace(0.,1.,count+1)
            # Shared linear path clock; A1 inverse limits below determine duration.
            ticks=t*times[-1]
            q=np.column_stack([np.interp(ticks,times,refs[:,j]) for j in range(15)])
            dq=np.diff(q[:,3]);u=(dq-self.rho[-1]*np.r_[initial,dq[:-1]])/(.1*self.beta[-1])
            arm_speed=np.max(abs(np.diff(q[:,ARM_IDX],axis=0))/speeds)
            if np.max(abs(u))<=1+1e-9 and arm_speed<=1+1e-9:break
        else:raise ValueError('joint reference exceeds frozen 200-step horizon')
        self.schedule_joint_references=q.copy()  # Diagnostic; check_path never calls this.
        return [self.fk.tcp(x) for x in q],q[:,3].copy()
