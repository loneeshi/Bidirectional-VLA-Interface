"""Audited E1-B odometry and privileged initial-point contract; no simulator or provider access."""
import base64,hashlib,json,math
import numpy as np
from .eef_tools import FETCH_ORDER,pose,vector
from .offline_spatial_audit import _audit_sensor,SENSOR_FIELDS,DEPTH_ENCODING

MODEL='gpt-6-astra'
OUTPUT_CAP=4000
TOOLS=('move_base','check_path','move_to','move_eef_chunk','set_gripper','return_to_rest','done','give_up')
PROMPT="""You control a Fetch robot to pick the specified object and carry it to the robot's rest posture. This is E1-B, a privileged-position pilot. At the first turn only, one target collision-shape bounding-box center is provided in attempt-start base_link; it is never refreshed after base motion. Use odometry to transform it yourself. It is not a grasp point. Infer orientation, dimensions, grasp surface and obstacles yourself from the robot RGB-D. There are no demonstrations or earlier attempts.
Each turn return exactly one tool call using the JSON schema. End-effector coordinates are in CURRENT base_link: x forward, y left, z up, meters. A pose is the gripper_link origin and orientation quaternion [x,y,z,w], unit norm. Local gripper +x points through the fingers; fingers separate along local y. Use the measured TCP pose and images to reason about the desired approach. move_base(turn_rad, forward_m) turns in place then drives straight; negative forward_m reverses, no sideways motion. Bounds: |turn_rad|<=pi, |forward_m|<=1.5m, at most 80 steps. Speeds capped at 1rad/s and 0.5m/s; arrival tolerances 0.03rad and 0.02m. Odometry dx_m,dy_m,dyaw_rad is ideal noiseless robot odometry relative to attempt-start base_link. The arm and gripper retain their targets during base motion. After moving the base, end-effector poses are in the new CURRENT base_link. Every non-set_gripper call MUST have gripper=null. Only move_base has non-null turn_rad and forward_m; all other calls MUST set both to null. move_base must use poses=[]. Torso and arm are controlled by robot-only IK. check_path checks only robot IK, joint limits and timing; acceptance does not establish freedom from collision. move_to and move_eef_chunk interpolate and track your poses; no scene collision filter is used. set_gripper: 1=open, 0=closed, intermediate values partially open. Close only when positioned for grasp; closing performs precise alignment to the last movement goal. return_to_rest moves joints to the official rest posture while retaining the gripper command. You must return to rest with the object for strict Pick success; lifting alone is insufficient. done/give_up end the attempt and require hindsight. A tool refusal consumes one of your 25 calls. The environment has at most 200 remaining control steps, with an unchanged official cumulative-force limit. Tool steps share that budget. Move calls are capped at 60 steps, rest at 60, closing alignment at 10 plus up to 5 finger steps. Do not claim success from the tool's arrived flag alone. Choose the next command using current sensor feedback and your own earlier commands. Only robot head/hand RGB-D and joint measurements are available. Depth grayscale uses the stated encoding. No locate_point tool is available."""
POSE_SCHEMA={'type':'object','properties':{'position':{'type':'array','items':{'type':'number'},'minItems':3,'maxItems':3},'quaternion_xyzw':{'type':'array','items':{'type':'number'},'minItems':4,'maxItems':4}},'required':['position','quaternion_xyzw'],'additionalProperties':False}
SCHEMA={'type':'object','properties':{'tool':{'type':'string','enum':list(TOOLS)},'poses':{'type':'array','items':POSE_SCHEMA,'maxItems':8},'gripper':{'type':['number','null']},'turn_rad':{'type':['number','null']},'forward_m':{'type':['number','null']},'hindsight':{'type':'string'}},'required':['tool','poses','gripper','hindsight','turn_rad','forward_m'],'additionalProperties':False}
PROPRIO_KEYS=FETCH_ORDER[3:]
RESULT_FIELDS={'accepted','arrived','reason','steps_used','position_error_m','rotation_error_rad','arm_ik_wait_steps','finger_distance_m','command','stable','enter_closed','readonly','minimum_steps','requested_turn_rad','requested_forward_m','actual_turn_rad','actual_forward_m','official_terminated','parameter_error'}

def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')
def validate_call(call):
    if not isinstance(call,dict) or set(call)!={'tool','poses','gripper','hindsight','turn_rad','forward_m'}:raise ValueError('tool call schema')
    tool=call['tool']
    if tool not in TOOLS or not isinstance(call['hindsight'],str) or len(call['hindsight'])>3000:raise ValueError('tool or hindsight')
    if not isinstance(call['poses'],list) or len(call['poses'])>8:raise ValueError('pose list')
    for p in call['poses']:
        if not isinstance(p,dict) or set(p)!={'position','quaternion_xyzw'}:raise ValueError('pose schema')
        pose(p['position'],p['quaternion_xyzw'])
    n=len(call['poses'])
    if (tool=='move_to' and n!=1) or (tool in ('check_path','move_eef_chunk') and n<1) or (tool not in ('move_to','check_path','move_eef_chunk') and n):raise ValueError('pose/tool mismatch')
    g=call['gripper']
    if tool=='set_gripper':
        if type(g) not in (int,float) or not math.isfinite(g) or not 0<=g<=1:raise ValueError('gripper bound')
    elif g is not None:raise ValueError('gripper must be null for every tool except set_gripper; set gripper=null')
    for key,limit in (('turn_rad',math.pi),('forward_m',1.5)):
        value=call[key]
        if tool=='move_base':
            if type(value) not in (int,float) or not math.isfinite(value) or abs(value)>limit:raise ValueError(key+' must be a finite number within +/-'+str(limit))
        elif value is not None:raise ValueError(key+' must be null unless tool=move_base')
    if tool in ('done','give_up') and not call['hindsight'].strip():raise ValueError('hindsight required')
    return call

def public_result(result):
    # Explicit allowlist: no official flags, contacts, object or world poses.
    out={k:v for k,v in result.items() if k in RESULT_FIELDS and type(v) in (str,int,float,bool,type(None))}
    if any(isinstance(v,str) and len(v)>150 for v in out.values()):raise ValueError('unexpected tool text')
    canonical(out)
    return out

def audit_observation(obs,manifest,turn):
    fields={'target_semantics','joint_positions','joint_velocities','tcp_pose','sensors','steps_remaining','calls_remaining','history','odometry'}
    if turn==0:fields.add('privileged_initial_target_center_start_base_m')
    if set(obs)!=fields:raise ValueError('observation field violation or repeated privileged point')
    if type(turn)!=int or not 0<=turn<25:raise ValueError('turn')
    if not isinstance(obs['target_semantics'],str) or not obs['target_semantics'].startswith('target object: ') or len(obs['target_semantics'])>150:raise ValueError('target semantics')
    for key in ('joint_positions','joint_velocities'):
        if set(obs[key])!=set(PROPRIO_KEYS):raise ValueError('joint fields; root world coordinates forbidden')
        vector(list(obs[key].values()),len(PROPRIO_KEYS))
    odom=obs['odometry']
    if not isinstance(odom,dict) or set(odom)!={'dx_m','dy_m','dyaw_rad'}:raise ValueError('only attempt-relative odometry fields are allowed')
    vector(list(odom.values()),3)
    if abs(odom['dyaw_rad'])>math.pi+1e-12:raise ValueError('odometry yaw must be wrapped')
    p=obs['tcp_pose']
    if set(p)!={'position','quaternion_xyzw'}:raise ValueError('TCP fields')
    pose(p['position'],p['quaternion_xyzw'])
    if set(obs['sensors'])!=set(SENSOR_FIELDS) or set(manifest)!=set(SENSOR_FIELDS):raise ValueError('sensor set')
    for field in SENSOR_FIELDS:_audit_sensor(field,obs['sensors'][field],manifest[field],128)
    if type(obs['steps_remaining'])!=int or not 0<=obs['steps_remaining']<=200 or obs['calls_remaining']!=25-turn:raise ValueError('budgets')
    if turn==0:vector(obs['privileged_initial_target_center_start_base_m'],3)
    if len(obs['history'])!=turn:raise ValueError('history length')
    for entry in obs['history']:
        if set(entry)!={'call','result'}:raise ValueError('history entry')
        # Invalid model calls may be recorded as a fixed error without replaying
        # untrusted arbitrary fields. The model's actual raw reply is archived separately.
        if entry['call'] is not None:validate_call(entry['call'])
        if public_result(entry['result'])!=entry['result']:raise ValueError('unapproved result')
    return canonical(obs)

def build_wire(obs,manifest,turn,previous_response_id=None):
    audit_observation(obs,manifest,turn)
    if (turn==0 and previous_response_id is not None) or (turn>0 and (not isinstance(previous_response_id,str) or not previous_response_id.startswith('resp_'))):raise ValueError('case-local response lineage required')
    metadata={k:v for k,v in obs.items() if k not in ('sensors','history')}
    metadata['depth_encoding']=DEPTH_ENCODING
    if turn:metadata['previous_tool_result']=obs['history'][-1]['result']
    content=[{'type':'input_text','text':canonical(metadata).decode()}]
    for field in SENSOR_FIELDS:
        content.extend([{'type':'input_text','text':field},{'type':'input_image','detail':'original','image_url':'data:image/png;base64,'+obs['sensors'][field]['data_base64']}])
    body={'model':MODEL,'instructions':PROMPT,'reasoning':{'effort':'medium'},'service_tier':'default','store':True,'max_output_tokens':OUTPUT_CAP,'input':[{'role':'user','content':content}],'text':{'format':{'type':'json_schema','name':'eef_tool_call','strict':True,'schema':SCHEMA}}}
    if turn:body['previous_response_id']=previous_response_id
    return canonical(body)
