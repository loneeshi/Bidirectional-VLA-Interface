"""Build and audit the exact Responses JSON bytes for offline spatial questions.

This module has no network client. A later authorized sender must transmit the
returned wire bytes unchanged, without SDK-side image or prompt conversion.
"""
from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path

from bvi import offline_spatial_audit
from bvi.offline_spatial_audit import DEPTH_ENCODING, SENSOR_FIELDS, audit_request
from bvi.offline_spatial_contract import SCENE_ANSWER_SCHEMA, MOTIONS, motion_answer_schema

MODELS = frozenset({"gpt-5.6-sol", "gpt-6-astra"})
SENSOR_ORDER = ("head_rgb", "head_depth", "hand_rgb", "hand_depth")
OBJECT_NAMES = {
    "002_master_chef_can": "Master Chef can",
    "003_cracker_box": "cracker box",
    "004_sugar_box": "sugar box",
    "005_tomato_soup_can": "tomato soup can",
    "007_tuna_fish_can": "tuna fish can",
    "008_pudding_box": "pudding box",
    "009_gelatin_box": "gelatin box",
    "010_potted_meat_can": "potted meat can",
    "024_bowl": "bowl",
}


def canonical_bytes(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_privileged_map(map_png: Path, *, rendered_path: Path,
                            rendered: dict, freeze: dict) -> None:
    """Bind ablation B's truth image to this exact frozen handoff export."""
    if map_png.name != "map.png":
        raise ValueError("privileged map filename differs from trusted renderer")
    folder = map_png.parent
    manifest = json.loads((folder / "trusted-privileged-map-manifest.json").read_text(
        encoding="utf-8"))
    expected_keys = {"schema", "position", "plan_uid", "snapshot_sha256",
                     "rendered_result_sha256", "collision_bundle_sha256",
                     "official_floor_sha256", "map_json_sha256",
                     "height_npy_sha256", "map_png_sha256",
                     "renderer_source_sha256", "binding_source_sha256",
                     "source_label"}
    if (set(manifest) != expected_keys or
            manifest["schema"] != "bvi.real-handoff-spatial-privileged-map/1" or
            manifest["source_label"] !=
            "simulator_ground_truth_privileged_ablation_only" or
            manifest["position"] != rendered["position"] or
            manifest["plan_uid"] != rendered["plan_uid"] or
            manifest["snapshot_sha256"] != rendered["snapshot_sha256"] or
            manifest["rendered_result_sha256"] != sha256(rendered_path) or
            manifest["collision_bundle_sha256"] != rendered["geometry"]["bundle_sha256"] or
            manifest["official_floor_sha256"] != rendered["floor_triangles"]["copy_sha256"] or
            manifest["renderer_source_sha256"] != frozen_source_hash(
                freeze, "scripts/build_c2_metric_topdown.py") or
            manifest["binding_source_sha256"] != frozen_source_hash(
                freeze, "scripts/build_real_handoff_spatial_topdown.py")):
        raise ValueError("privileged map manifest differs from frozen handoff")
    for name, key in (("map.json", "map_json_sha256"),
                      ("height.npy", "height_npy_sha256"),
                      ("map.png", "map_png_sha256")):
        if sha256(folder / name) != manifest[key]:
            raise ValueError(f"privileged map artifact changed: {name}")
    case_dir = rendered_path.parent
    if (sha256(case_dir / "geometry/collision-bundle/bundle.json") !=
            manifest["collision_bundle_sha256"] or
            sha256(case_dir / "geometry/floor-triangles.obj") !=
            manifest["official_floor_sha256"]):
        raise ValueError("privileged geometry changed after map generation")
    map_data = json.loads((folder / "map.json").read_text(encoding="utf-8"))
    if (map_data["source"]["bundle_sha256"] != manifest["collision_bundle_sha256"] or
            map_data["source"]["floor_sha256"] != manifest["official_floor_sha256"] or
            map_data["source"]["handoff_snapshot_sha256"] !=
            manifest["snapshot_sha256"] or
            map_data["source"]["source_state_role"] !=
            "real_handoff_snapshot_without_policy_action" or
            map_data["height_channels"]["sha256"] != manifest["height_npy_sha256"] or
            not map_data["coverage"]["passed"]):
        raise ValueError("privileged map content differs from manifest")


def frozen_source_hash(freeze: dict, suffix: str) -> str:
    matches = [value for key, value in freeze["sources_sha256"].items()
               if key.replace("\\", "/").endswith(suffix)]
    if len(matches) != 1:
        raise ValueError(f"source missing or ambiguous in freeze: {suffix}")
    return matches[0]


def target_semantics(object_id: str) -> str:
    parts = object_id.rsplit("-", 1)
    if len(parts) != 2 or not parts[1].isdigit() or parts[0] not in OBJECT_NAMES:
        raise ValueError("unrecognized target object class")
    return "target object: " + OBJECT_NAMES[parts[0]]


def load_sensor_parts(view_dir: Path, condition: str) -> tuple[dict, dict]:
    """Read only four named robot sensors, never a renderer result or truth file."""
    manifest = json.loads((view_dir / "trusted-sensor-manifest.json").read_text(
        encoding="utf-8"))
    required = {"head_rgb", "hand_rgb"}
    if condition != "rgb_p1":
        required |= {"head_depth", "hand_depth"}
    if set(manifest) != set(SENSOR_ORDER):
        raise ValueError("render manifest has unexpected sensor fields")
    parts, trusted = {}, {}
    for field in SENSOR_ORDER:
        if field not in required:
            continue
        camera, modality = SENSOR_FIELDS[field]
        file = view_dir / f"{camera}-{modality}.png"
        raw = file.read_bytes()
        expected = manifest[field]
        if (set(expected) != {"sha256", "camera", "modality", "width", "height"} or
                expected["camera"] != camera or expected["modality"] != modality or
                hashlib.sha256(raw).hexdigest() != expected["sha256"]):
            raise ValueError(f"untrusted rendered sensor: {field}")
        parts[field] = {"camera": camera, "modality": modality,
                        "sha256": expected["sha256"],
                        "data_base64": base64.b64encode(raw).decode("ascii")}
        trusted[field] = expected
    return parts, trusted


def _wire_body(internal: dict, model: str, max_output_tokens: int) -> dict:
    if model not in MODELS or type(max_output_tokens) is not int or not 1 <= max_output_tokens <= 4000:
        raise ValueError("unfrozen model or output-token cap")
    metadata = {"question_kind": internal["question_kind"],
                "target_semantics": internal["target_semantics"]}
    if "motion_actions" in internal:
        metadata["motion_actions"] = internal["motion_actions"]
    if "depth_encoding" in internal:
        metadata["depth_encoding"] = internal["depth_encoding"]
    content = [{"type": "input_text", "text": canonical_bytes(metadata).decode("utf-8")}]
    for field in SENSOR_ORDER:
        if field in internal:
            part = internal[field]
            content.append({"type": "input_text", "text": field})
            content.append({"type": "input_image", "detail": "original",
                            "image_url": "data:image/png;base64," + part["data_base64"]})
    if "simulator_ground_truth_topdown" in internal:
        part = internal["simulator_ground_truth_topdown"]
        content.append({"type": "input_text",
                        "text": "PRIVILEGED ABLATION: simulator ground-truth top-down map"})
        content.append({"type": "input_image", "detail": "original",
                        "image_url": "data:image/png;base64," + part["data_base64"]})
    return {"model": model, "store": False, "instructions": internal["prompt"],
            "reasoning": {"effort": "medium"},
            "max_output_tokens": max_output_tokens,
            "input": [{"role": "user", "content": content}],
            "text": {"format": {"type": "json_schema",
                                "name": "offline_spatial_scene" if internal["question_kind"] ==
                                "scene_questions" else "offline_spatial_motion",
                                "strict": True, "schema": internal["answer_schema"]}}}


def audit_wire_bytes(wire: bytes, audited_internal: bytes, *, model: str,
                     max_output_tokens: int) -> bytes:
    """The exact bytes accepted here are the only bytes the sender may POST."""
    internal = json.loads(audited_internal)
    expected = canonical_bytes(_wire_body(internal, model, max_output_tokens))
    if wire != expected:
        raise ValueError("provider wire body differs from audited sensor request")
    return wire


def build_wire_request(*, view_dir: Path, condition: str, question_kind: str,
                       prompt: str, expected_prompt_sha256: str,
                       target_semantics: str, model: str,
                       max_output_tokens: int, action_ids: list[str] | None = None,
                       privileged_map_png: Path | None = None) -> tuple[bytes, bytes]:
    if condition not in {"rgbd_p0", "rgbd_p1", "rgb_p1",
                         "privileged_topdown_p1", "highres_rgbd_p1"}:
        raise ValueError("condition outside frozen matrix")
    expected_size = 256 if condition == "highres_rgbd_p1" else 128
    if view_dir.name != str(expected_size):
        raise ValueError("renderer directory differs from condition resolution")
    sensors, trusted = load_sensor_parts(view_dir, condition)
    if question_kind == "scene_questions":
        if action_ids:
            raise ValueError("scene question must not carry motion actions")
        schema = SCENE_ANSWER_SCHEMA
    elif question_kind == "motion_questions":
        allowed = {row[0] for row in MOTIONS}
        if not action_ids or len(set(action_ids)) != len(action_ids) or not set(action_ids) <= allowed:
            raise ValueError("Q2 actions must be executed frozen action IDs")
        schema = motion_answer_schema(action_ids)
    else:
        raise ValueError("unknown question kind")
    internal = {"question_kind": question_kind, "condition": condition,
                "prompt": prompt, "answer_schema": schema,
                "target_semantics": target_semantics, **sensors}
    if condition != "rgb_p1":
        internal["depth_encoding"] = DEPTH_ENCODING
    if question_kind == "motion_questions":
        known = {row[0]: row for row in MOTIONS}
        internal["motion_actions"] = [{"action_id": ident,
                                       "kind": known[ident][1],
                                       "amount": known[ident][2]}
                                      for ident in action_ids]
    if condition == "privileged_topdown_p1":
        if privileged_map_png is None:
            raise ValueError("privileged map required only in ablation B")
        raw = privileged_map_png.read_bytes()
        internal["simulator_ground_truth_topdown"] = {
            "source": "simulator_ground_truth",
            "sha256": hashlib.sha256(raw).hexdigest(),
            "data_base64": base64.b64encode(raw).decode("ascii")}
    elif privileged_map_png is not None:
        raise ValueError("ground-truth map forbidden in main and RGB ablation")
    audited = audit_request(internal, sensor_manifest=trusted,
                            expected_prompt_sha256=expected_prompt_sha256,
                            expected_target_semantics=target_semantics,
                            privileged=condition == "privileged_topdown_p1")
    wire = canonical_bytes(_wire_body(internal, model, max_output_tokens))
    return audited, audit_wire_bytes(wire, audited, model=model,
                                     max_output_tokens=max_output_tokens)


def build_frozen_wire_request(*, freeze_path: Path, summary_path: Path,
                              prompt_path: Path, view_dir: Path,
                              position: int, condition: str,
                              question_kind: str, model: str,
                              max_output_tokens: int,
                              privileged_map_png: Path | None = None) -> tuple[bytes, bytes]:
    """Bind every model-visible field to the frozen case and trusted renderer."""
    freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
    if freeze.get("schema") != "bvi.offline-spatial-stage1-freeze/1":
        raise ValueError("unexpected freeze schema")
    if (sha256(Path(__file__)) != frozen_source_hash(
            freeze, "src/bvi/offline_spatial_wire.py") or
            sha256(Path(offline_spatial_audit.__file__)) != frozen_source_hash(
                freeze, "src/bvi/offline_spatial_audit.py")):
        raise ValueError("request builder or auditor differs from freeze")
    if sha256(summary_path) != frozen_source_hash(
            freeze, "real-handoff-pick-census-20260924/full-batch-summary.json"):
        raise ValueError("census summary differs from freeze")
    expected_prompt = "offline-spatial-p0.txt" if condition == "rgbd_p0" else "offline-spatial-p1.txt"
    if prompt_path.name != expected_prompt:
        raise ValueError("prompt condition mismatch")
    prompt_hash = frozen_source_hash(freeze, "/" + expected_prompt)
    if sha256(prompt_path) != prompt_hash:
        raise ValueError("prompt differs from freeze")
    rows = [row for row in freeze["roster"] if row["plan_position"] == position]
    if len(rows) != 1:
        raise ValueError("position absent or duplicated in freeze")
    frozen = rows[0]
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    outcomes = [row for row in summary["outcomes"] if row["plan_position"] == position]
    if len(outcomes) != 1 or outcomes[0]["result"]["status"] != "completed":
        raise ValueError("missing completed census outcome")
    outcome = outcomes[0]
    result = outcome["result"]
    if (outcome["plan_uid"] != frozen["plan_uid"] or
            result["row"]["plan_uid"] != frozen["plan_uid"] or
            result["handoff"]["snapshot_sha256"] != frozen["snapshot_sha256"]):
        raise ValueError("census case differs from freeze")
    rendered_path = view_dir.parent / "result.json"
    rendered = json.loads(rendered_path.read_text(encoding="utf-8"))
    if (rendered.get("status") != "completed" or
            rendered.get("position") != position or
            rendered.get("snapshot_sha256") != frozen["snapshot_sha256"]):
        raise ValueError("rendered case differs from frozen snapshot")
    resolution = 256 if condition == "highres_rgbd_p1" else 128
    views = [row for row in rendered["views"] if row["resolution"] == resolution]
    if (len(views) != 1 or view_dir.name != str(resolution) or
            sha256(view_dir / "trusted-sensor-manifest.json") !=
            views[0]["trusted_sensor_manifest_sha256"]):
        raise ValueError("rendered sensor manifest differs from result")
    action_ids = frozen["q2_action_ids"] if question_kind == "motion_questions" else None
    if condition == "privileged_topdown_p1":
        if privileged_map_png is None:
            raise ValueError("privileged map missing")
        validate_privileged_map(privileged_map_png, rendered_path=rendered_path,
                                rendered=rendered, freeze=freeze)
    return build_wire_request(
        view_dir=view_dir, condition=condition, question_kind=question_kind,
        prompt=prompt_path.read_text(encoding="utf-8"),
        expected_prompt_sha256=prompt_hash,
        target_semantics=target_semantics(result["row"]["first_pick_obj_id"]),
        model=model, max_output_tokens=max_output_tokens,
        action_ids=action_ids, privileged_map_png=privileged_map_png)
