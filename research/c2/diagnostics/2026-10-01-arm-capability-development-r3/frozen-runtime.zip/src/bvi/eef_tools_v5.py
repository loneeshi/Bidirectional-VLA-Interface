"""v5 synchronizes Cartesian and IK8 torso references with one release cursor."""
import numpy as np
from scipy.spatial.transform import Rotation,Slerp
from .eef_tools import transform,vector
from .eef_tools_v3 import ARM_IDX,periodic_delta,pose_error
from .eef_tools_v4 import FetchToolsV4

VERSION='eef-tool-v5-coupled-reference-r1'


class FetchToolsV5(FetchToolsV4):
    def coupled_schedule(self,plan):
        refs=plan['refs'];poses=np.asarray([self.fk.tcp(refs[0]),*plan['points']])
        speed=np.asarray(self.model['reference_speed_limits'])[:7]
        cost=np.max(abs(np.diff(refs[:,ARM_IDX],axis=0))/speed,axis=1)
        times=np.r_[0,np.cumsum(np.maximum(cost,1e-8))]
        start=max(1,int(np.ceil(times[-1])))
        # Stretch one shared path clock until its unpaused torso reference
        # satisfies the frozen A1 action bound. No separate end-goal clock.
        for count in range(start,201):
            ticks=np.linspace(0,times[-1],count+1)
            heights=np.interp(ticks,times,refs[:,3])
            delta=np.diff(heights)
            previous=np.r_[self.previous_delta[3],delta[:-1]]
            action=(delta-self.rho[-1]*previous)/(.1*self.beta[-1])
            if np.max(abs(action))<=1+1e-9:break
        else:raise ValueError('coupled torso reference exceeds 200-step model horizon')
        rotations=Slerp(times,Rotation.from_matrix(poses[:,:3,:3]))(ticks).as_matrix()
        points=[]
        for i,t in enumerate(ticks):
            point=np.eye(4);point[:3,:3]=rotations[i]
            point[:3,3]=[np.interp(t,times,poses[:,j,3]) for j in range(3)]
            points.append(point)
        return points,heights

    def move_eef_chunk(self,targets,*,max_steps):
        before=self.steps;self.deadline=min(self.max_steps,before+max_steps)
        plan=self._plan(targets)
        if not plan['accepted']:
            return {'arrived':False,'reason':plan['reason'],'steps_used':0,
                    'plan':{k:v for k,v in plan.items() if k not in ('refs','points')}}
        try:points,heights=self.coupled_schedule(plan)
        except ValueError as exc:
            return {'arrived':False,'reason':'reference_timing_infeasible','detail':str(exc),'steps_used':0}
        cursor=0;waits=0;reason='tool_step_limit'
        previous=vector(self.read_qpos(),15).copy()
        while cursor<len(points)-1 and self._available():
            target,solved=self._compensate(points[cursor+1])
            if solved.reason=='jump_rejected':reason='jump_rejected';break
            if not solved.accepted:waits+=1
            target[3]=heights[cursor+1]
            delta=np.zeros(15)
            if solved.accepted:delta[ARM_IDX]=periodic_delta(target,previous)[ARM_IDX]
            delta[3]=target[3]-previous[3]
            self._step(self.inverse_action(delta,previous),'move',reference_index=cursor+1,
                torso_reference_m=float(target[3]),ik_reason=solved.reason,
                reference_clock='shared_release_cursor')
            error=periodic_delta(target,vector(self.read_qpos(),15))
            released=np.max(abs(error[ARM_IDX]))<=self.p.release_rotation and abs(error[3])<=self.p.release_torso
            if solved.accepted and released:cursor+=1
            previous=target.copy()
        goal=transform(targets[-1]);self.last_goal=goal
        pe,re=pose_error(self.fk,self.read_qpos(),goal)
        while cursor==len(points)-1 and (pe>self.p.endpoint_position or re>self.p.endpoint_rotation) and self._available():
            target,solved=self._compensate(goal)
            if solved.reason=='jump_rejected':reason='jump_rejected';break
            if not solved.accepted:waits+=1
            self._step(self.inverse_action(np.zeros(15),target),'endpoint',ik_reason=solved.reason)
            pe,re=pose_error(self.fk,self.read_qpos(),goal)
        arrived=cursor==len(points)-1 and pe<=self.p.endpoint_position and re<=self.p.endpoint_rotation and reason!='jump_rejected'
        if arrived:self.last_plan_endpoint=plan['refs'][-1].copy()
        return {'arrived':bool(arrived),'reason':'ok' if arrived else reason,'steps_used':self.steps-before,
            'position_error_m':pe,'rotation_error_rad':re,'arm_ik_wait_steps':waits,
            'torso_target_m':float(plan['refs'][-1,3]),'reference_count':len(points),
            'reference_completed':cursor==len(points)-1,'reference_clock':'shared_release_cursor'}
