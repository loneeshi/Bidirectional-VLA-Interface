"""B2 note and reflection contracts. No scene or provider access."""
import copy,hashlib,json,re
from . import eef_e1b_contract as old
from .eef_guidance_v1 import PROMPT,VERSION
from .eef_e1b_contract_v13 import non_image_bytes

MODEL=old.MODEL
OUTPUT_CAP=old.OUTPUT_CAP
SCHEMA=copy.deepcopy(old.SCHEMA)
SCHEMA['properties']['note']={'type':'string','minLength':1,'maxLength':900}
SCHEMA['required'].append('note')
REFLECTION_SCHEMA={'type':'object','properties':{'hindsight':{'type':'string','minLength':1,'maxLength':3000}},'required':['hindsight'],'additionalProperties':False}
REFLECTION_PROMPT='The attempt is over. No actions can be executed. Given the official outcome and termination category, briefly write hindsight grounded in your earlier observations and command notes. Distinguish evidence from uncertainty; do not claim access to unobserved simulator state. Return only hindsight using the schema.'
GUIDANCE_SHA256='02319d5abff754b0a29cec2a4e401a26111076299acb1721171ed9a6c96d13de'
NEW_INPUT_BYTE_CAP=12288

def validate_note(note):
    if not isinstance(note,str) or not note.strip() or len(note)>900:
        raise ValueError('note is required: 1-3 short sentences of evidence and intent, at most 900 characters')
    sentences=[s.strip() for s in re.split(r'(?<=[.!?])\s+|(?<=[\u3002\uff01\uff1f])',note.strip()) if s.strip()]
    if not 1<=len(sentences)<=3:
        raise ValueError('note must contain 1-3 sentences of evidence and intent')
    return note

def validate_call(call):
    if not isinstance(call,dict) or set(call)!=set(old.SCHEMA['required'])|{'note'}:
        raise ValueError('tool call requires the frozen fields including note')
    validate_note(call['note'])
    old.validate_call({k:v for k,v in call.items() if k!='note'})
    return call

def audited_legacy_observation(obs,manifest,turn):
    clean=copy.deepcopy(obs)
    clean['history']=[copy.deepcopy(entry) for entry in obs['history']]
    for entry in clean['history']:
        if entry['call'] is not None:
            validate_call(entry['call']);entry['call']={k:v for k,v in entry['call'].items() if k!='note'}
    old.audit_observation(clean,manifest,turn)
    return clean

def build_wire(obs,manifest,turn,previous_response_id=None):
    if hashlib.sha256(PROMPT.encode()).hexdigest()!=GUIDANCE_SHA256:raise ValueError("guidance-v1 text changed; new version required")
    clean=audited_legacy_observation(obs,manifest,turn)
    body=json.loads(old.build_wire(clean,manifest,turn,previous_response_id))
    body['instructions']=PROMPT
    body['reasoning']={'effort':'medium','summary':'auto'}
    body['text']['format']['schema']=SCHEMA
    wire=old.canonical(body)
    if non_image_bytes(wire)>NEW_INPUT_BYTE_CAP:raise ValueError('B2 request byte envelope exceeded')
    return wire

def reflection_wire(outcome,termination_category,previous_response_id):
    if outcome not in ('success','failure') or termination_category not in ('cumulative_force_limit','time_limit'):
        raise ValueError('reflection only for official force/time termination')
    if not isinstance(previous_response_id,str) or not previous_response_id.startswith('resp_'):
        raise ValueError('reflection must continue the same attempt response chain')
    return old.canonical({'model':MODEL,'instructions':REFLECTION_PROMPT,'reasoning':{'effort':'medium','summary':'auto'},
        'service_tier':'default','store':True,'previous_response_id':previous_response_id,'max_output_tokens':OUTPUT_CAP,
        'input':[{'role':'user','content':[{'type':'input_text','text':old.canonical({'outcome':outcome,'termination_category':termination_category}).decode()}]}],
        'text':{'format':{'type':'json_schema','name':'attempt_hindsight','strict':True,'schema':REFLECTION_SCHEMA}}})

def reasoning_summaries(body):
    return [p['text'] for item in body.get('output',[]) if item.get('type')=='reasoning'
            for p in item.get('summary',[]) if p.get('type')=='summary_text' and isinstance(p.get('text'),str)]

def validate_reflection(value):
    if (not isinstance(value,dict) or set(value)!={'hindsight'} or not isinstance(value['hindsight'],str)
            or not value['hindsight'].strip() or len(value['hindsight'])>3000):
        raise ValueError('reflection requires only nonempty hindsight, at most 3000 characters')
    return value
