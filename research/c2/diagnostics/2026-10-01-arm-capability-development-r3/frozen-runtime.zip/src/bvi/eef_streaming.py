"""Independent streaming executor; robot-only planning, no scene or simulator API."""
from dataclasses import dataclass, asdict
import numpy as np
from scipy.spatial.transform import Rotation, Slerp
from .eef_tools import ARM, BODY, REST, FETCH_ORDER, densify, vector
from .eef_response_model import ResponsePlant, QIND


def grip_band(command):
    if not np.isfinite(command) or not 0<=command<=1:raise ValueError('invalid gripper command')
    return 0 if command<=.1 else 2 if command>=.9 else 1


def compress_pose_indices(frames, start, end, position_tol=.01, rotation_tol=.05):
    keep={start,end}
    def visit(a,b):
        if b-a<2:return
        poses=[np.asarray(frames[i]['tcp_base']) for i in (a,b)]
        slerp=Slerp([a,b],Rotation.from_matrix(np.stack([p[:3,:3] for p in poses])))
        errors=[]
        for i in range(a+1,b):
            t=(i-a)/(b-a); actual=np.asarray(frames[i]['tcp_base'])
            pe=np.linalg.norm(actual[:3,3]-((1-t)*poses[0][:3,3]+t*poses[1][:3,3]))/position_tol
            re=(Rotation.from_matrix(actual[:3,:3])*slerp(i).inv()).magnitude()/rotation_tol
            errors.append(max(pe,re))
        if max(errors)>1:
            i=a+1+int(np.argmax(errors));keep.add(i);visit(a,i);visit(i,b)
    visit(start,end)
    return sorted(keep)


def teacher_segments(frames):
    if len(frames)<2:raise ValueError('teacher needs a transition')
    events=[i for i in range(1,len(frames)) if grip_band(frames[i]['gripper_command'])!=grip_band(frames[i-1]['gripper_command'])]
    # Commands belong to the transition ending at frame i; segments partition
    # actions 1..N, not the pre-action initial sensor frame.
    starts=sorted({1,*events}); out=[]
    for index,start in enumerate(starts):
        end=starts[index+1]-1 if index+1<len(starts) else len(frames)-1
        out.append({'start_action':start,'end_action':end,
                    'gripper':float(np.median([f['gripper_command'] for f in frames[start:end+1]])),
                    'indices':compress_pose_indices(frames,start-1,end)})
    return {'event_indices':events,'segments':out,
            'keyframe_indices':sorted({i for s in out for i in s['indices']})}


@dataclass(frozen=True)
class StreamingParameters:
    gain: float
    lookahead: int=1
    release_tolerance: float=.05
    joint_tolerance: float=.002
    endpoint_steps_cap: int=10
    gripper_steps_cap: int=5
    gripper_stable_steps: int=2
    gripper_change_m: float=.001

    def __post_init__(self):
        if not np.isfinite(self.gain) or self.gain<=0 or self.lookahead<0:raise ValueError('invalid gain/lookahead')
        if self.endpoint_steps_cap<0 or self.gripper_steps_cap<1 or self.gripper_stable_steps<1:raise ValueError('invalid settling caps')


class FetchStreamingExecutor:
    def __init__(self,ik,read_qpos,step,read_finger,model,parameters,*,max_steps=200,gripper=1.):
        if ik.fk.order!=FETCH_ORDER or not isinstance(max_steps,int) or max_steps<0:raise ValueError('unsupported robot/budget')
        grip_band(gripper)
        self.ik,self.read_qpos,self.step,self.read_finger=ik,read_qpos,step,read_finger
        self.model,self.parameters=model,parameters
        self.max_steps,self.steps,self.stopped=max_steps,0,False
        self.gripper=gripper; self.events=[]
        self.controlled=np.array([ik.fk.index[n] for n in (*ARM,*BODY)])
        self.action_q=np.array([ik.fk.index[n] for n in (*ARM,*BODY)])

    def _step(self,action):
        if self.stopped or self.steps>=self.max_steps:return False
        status=self.step(action); self.steps+=1
        self.stopped=bool(status.get('terminated') or status.get('truncated'))
        return not self.stopped

    def action(self,target):
        q=vector(self.read_qpos(),15)
        a=np.zeros(13); delta=target-q
        a[:7]=np.clip(self.parameters.gain*delta[self.action_q[:7]]/.1,-1,1)
        a[8:11]=np.clip(self.parameters.gain*delta[self.action_q[7:]]/.1,-1,1)
        a[7]=2*self.gripper-1
        return a

    def _parameterize(self,refs):
        refs=np.asarray(refs,dtype=float)
        # Coordinate units: arm/head radians, torso metres. Limits are measured
        # independently for each controlled arm/torso channel, not scene truth.
        speed=np.maximum(np.asarray(self.model['reference_speed_limits']),1e-5)
        if len(refs)==1:return refs
        lengths=np.max(np.abs(np.diff(refs[:,QIND],axis=0))/speed,axis=1)
        head=np.max(abs(np.diff(refs[:,[4,6]],axis=0)),axis=1)/float(np.median(speed[:7]))
        lengths=np.maximum(lengths,head)
        times=np.r_[0,np.cumsum(lengths)]
        valid=np.r_[True,np.diff(times)>1e-10]; refs=refs[valid]; times=times[valid]
        if len(refs)==1:return refs
        ticks=np.linspace(0,times[-1],max(1,int(np.ceil(times[-1])))+1)
        return np.column_stack([np.interp(ticks,times,refs[:,j]) for j in range(15)])

    def _plan(self,targets,seed=None):
        q=vector(self.read_qpos() if seed is None else seed,15).copy(); refs=[q.copy()]
        points=densify(self.ik.fk.tcp(q),targets)
        if not points:raise ValueError('empty path')
        for point in points:
            result=self.ik.solve(point,q)
            if not result.accepted:return {'accepted':False,'reason':'ik_not_found','refs':None}
            q=result.qpos;refs.append(q.copy())
        return {'accepted':True,'reason':'ok','refs':self._parameterize(refs),'goal':points[-1]}

    def _arrived(self,target,goal=None):
        q=vector(self.read_qpos(),15)
        if np.max(abs(q[self.controlled]-target[self.controlled]))<=self.parameters.joint_tolerance:return True
        if goal is None:return False
        measured=self.ik.fk.tcp(q)
        pe=np.linalg.norm(measured[:3,3]-goal[:3,3])
        re=Rotation.from_matrix(goal[:3,:3]@measured[:3,:3].T).magnitude()
        return bool(pe<=self.ik.position_tol and re<=self.ik.rotation_tol)

    def _track(self,refs,goal=None):
        before=self.steps;cursor=0;last=len(refs)-1;p=self.parameters
        # Intermediate references never use the endpoint convergence loop.
        while cursor<last and not self.stopped and self.steps<self.max_steps:
            error=float(np.max(abs(vector(self.read_qpos(),15)[self.controlled]-refs[cursor,self.controlled])))
            if error<=p.release_tolerance:cursor+=1
            target=refs[min(cursor+p.lookahead,last)]
            self._step(self.action(target))
        converged=self._arrived(refs[-1],goal) if cursor==last else False
        settling=0
        while not converged and cursor==last and settling<p.endpoint_steps_cap and not self.stopped and self.steps<self.max_steps:
            self._step(self.action(refs[-1]));settling+=1
            converged=self._arrived(refs[-1],goal)
        record={'arrived':converged,'steps_used':self.steps-before,'endpoint_settle_steps':settling,
                'reference_points':len(refs),'stopped':self.stopped,'cursor':cursor,
                'max_controlled_joint_error':float(np.max(abs(vector(self.read_qpos(),15)[self.controlled]-refs[-1,self.controlled])))}
        if goal is not None:
            measured=self.ik.fk.tcp(self.read_qpos())
            record['endpoint_position_error_m']=float(np.linalg.norm(measured[:3,3]-goal[:3,3]))
            record['endpoint_rotation_error_rad']=float(Rotation.from_matrix(goal[:3,:3]@measured[:3,:3].T).magnitude())
        self.events.append(record)
        return record

    def move_eef_chunk(self,targets):
        plan=self._plan(targets)
        if not plan['accepted']:return {'arrived':False,'reason':plan['reason'],'steps_used':0}
        return self._track(plan['refs'],plan['goal'])

    def move_to(self,target):return self.move_eef_chunk([target])

    def set_gripper(self,openness):
        grip_band(openness);self.gripper=float(openness);before=self.steps
        stable=0;prior=float(self.read_finger());hold=vector(self.read_qpos(),15).copy()
        while stable<self.parameters.gripper_stable_steps and self.steps-before<self.parameters.gripper_steps_cap and not self.stopped and self.steps<self.max_steps:
            self._step(self.action(hold));current=float(self.read_finger())
            stable=stable+1 if abs(current-prior)<self.parameters.gripper_change_m else 0
            prior=current
        return {'steps_used':self.steps-before,'stable':stable>=self.parameters.gripper_stable_steps,'finger_distance_m':prior}

    def return_to_rest(self):
        seed=vector(self.read_qpos(),15).copy();target=seed.copy();target[3:-2]=REST[3:-2]
        return self._track(self._parameterize([seed,target]))

    def check_path(self,targets,*,gripper_commands=(),include_rest=False):
        # A separate response plant predicts without touching live state/callbacks.
        plan=self._plan(targets)
        if not plan['accepted']:return {**plan,'estimated_steps':None,'is_estimate':True}
        plant=ResponsePlant(self.model,self.read_qpos(),self.read_finger())
        copy=FetchStreamingExecutor(self.ik,lambda:plant.q,plant.step,lambda:plant.finger,
             self.model,self.parameters,max_steps=2000,gripper=self.gripper)
        for command in gripper_commands:copy.set_gripper(command)
        outcome=copy._track(plan['refs'],plan['goal'])
        rest=copy.return_to_rest() if include_rest else None
        accepted=outcome['arrived'] and (rest is None or rest['arrived']) and copy.steps<=self.max_steps-self.steps
        return {'accepted':accepted,'reason':'ok' if accepted else 'predicted_tracking_or_budget',
                'estimated_steps':copy.steps,'is_estimate':True,'contact_physics':False,
                'parameters':asdict(self.parameters)}
