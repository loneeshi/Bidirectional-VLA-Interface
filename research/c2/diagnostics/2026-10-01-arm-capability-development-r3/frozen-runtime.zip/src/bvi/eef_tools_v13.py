"""v13: proprioceptive settling and braking-curve base motion. No scene inputs."""
import math
import numpy as np
from .eef_tools import vector
from .eef_tools_v12 import FetchToolsV12, odometry, wrap, validate_base_runtime

VERSION = 'eef-tool-v13-settle-braking-r1'
# Derived by scripts/prepare_eef_base_v13_cpu.py from contact-free cases 5/8.
LINEAR_DECEL = 0.84
ANGULAR_DECEL = 4.81
LINEAR_LIMIT = .5
ANGULAR_LIMIT = 1.
STILL_LINEAR = .02
STILL_ANGULAR = .03
STILL_READINGS = 2
TAIL_GAIN = 2.


def braking_speed(error, deceleration, limit, tolerance):
    magnitude = abs(float(error))
    if magnitude <= tolerance:
        return 0.
    tail = max(2*tolerance, (.05/(1-.6618654969317679)+.05)*limit)
    speed = TAIL_GAIN*magnitude if magnitude <= tail else math.sqrt(2*deceleration*magnitude)
    return math.copysign(min(limit, speed), error)


class FetchToolsV13(FetchToolsV12):
    def __init__(self, *args, settle_enabled=True, braking_enabled=True, **kwargs):
        super().__init__(*args, **kwargs)
        self.settle_enabled = settle_enabled
        self.braking_enabled = braking_enabled
        self.call_records = []
        self._guard_deadline = self.max_steps

    def _available(self):
        return super()._available() and self.steps < self._guard_deadline

    def _step(self, action, kind, **info):
        before=self.steps
        result=super()._step(action,kind,**info)
        if self.steps>before:
            velocity=vector(self.read_qvel(),15)
            self.trace[-1]['qvel']=velocity.tolist()
            self.trace[-1]['command_base_velocity']=[float(action[11]),float(action[12]*3.14)]
            self.trace[-1]['measured_root_velocity']=velocity[:3].tolist()
        return result

    def _snapshot(self):
        return {'qpos':vector(self.read_qpos(),15).tolist(),
                'qvel':vector(self.read_qvel(),15).tolist(), 'step':self.steps}

    def settle_base(self, hold, phase):
        start = self.steps
        consecutive = 0
        if not self.settle_enabled:
            return True
        previous = np.zeros(13)
        while self._available():
            action = self.settling_action(hold, previous)
            action[11:] = 0.
            self._step(action, 'base_settle', phase=phase, reference_qpos=hold.tolist())
            previous = action
            velocity = vector(self.read_qvel(),15)
            below = np.linalg.norm(velocity[:2]) < STILL_LINEAR and abs(velocity[2]) < STILL_ANGULAR
            consecutive = consecutive+1 if below else 0
            if self.stopped:
                return False
            if consecutive >= STILL_READINGS:
                self.trace[-1]['settle_passed'] = True
                self.trace[-1]['settle_steps'] = self.steps-start
                return True
        return False

    def prepare_tool(self, max_steps):
        """Common call prelude, including first call of an attempt. Not check_path."""
        self.deadline = self._guard_deadline = min(self.max_steps,self.steps+max_steps)
        return self.settle_base(vector(self.read_qpos(),15).copy(), 'tool_entry')

    def _guarded(self, name, budget, callback):
        before = self.steps;entry=self._snapshot()
        try:
            if not self.prepare_tool(budget):
                result={'accepted':False,'arrived':False,'reason':'official_terminated' if self.stopped else 'base_not_settled'}
            else:
                result=callback(max(0,budget-(self.steps-before)))
            result['steps_used']=self.steps-before
            return result
        finally:
            self.call_records.append({'tool':name,'entry':entry,'exit':self._snapshot(),
                'settle_steps':sum(t['kind']=='base_settle' for t in self.trace if t['step']>before)})
            self._guard_deadline=self.max_steps
            self._sync_boundary()

    def move_eef_chunk(self, targets, *, max_steps):
        return self._guarded('move_eef_chunk',max_steps,
            lambda left:super(FetchToolsV13,self).move_eef_chunk(targets,max_steps=left))

    def set_gripper(self, command):
        if type(command) not in (int,float) or not math.isfinite(command) or not 0<=command<=1:
            raise ValueError('gripper must be finite in [0,1]')
        return self._guarded('set_gripper',15,lambda left:super(FetchToolsV13,self).set_gripper(command))

    def return_to_rest(self):
        return self._guarded('return_to_rest',self.p.rest_cap,lambda left:super(FetchToolsV13,self).return_to_rest())

    def _speed(self,error,linear):
        limit=LINEAR_LIMIT if linear else ANGULAR_LIMIT
        if not self.braking_enabled:
            return float(np.clip(2*error,-limit,limit))
        return braking_speed(error,LINEAR_DECEL if linear else ANGULAR_DECEL,limit,.02 if linear else .03)

    def move_base(self, turn_rad, forward_m, *, max_steps=80):
        if (type(turn_rad) not in (int,float) or type(forward_m) not in (int,float)
                or not math.isfinite(turn_rad) or not math.isfinite(forward_m)
                or abs(turn_rad)>math.pi or abs(forward_m)>1.5):
            raise ValueError('move_base requires finite |turn_rad|<=pi and |forward_m|<=1.5')
        if type(max_steps) is not int or not 0<=max_steps<=80:
            raise ValueError('max_steps must be integer in [0,80]')
        before=self.steps;entry=self._snapshot();start=self.odometry()
        self.deadline=self._guard_deadline=min(self.max_steps,before+max_steps)
        hold=vector(self.read_qpos(),15).copy();previous=np.zeros(13)
        heading=wrap(start[2]+turn_rad);direction=np.array([math.cos(heading),math.sin(heading)])
        target=start[:2]+forward_m*direction
        self._base_active=True;arrived=False;reason='tool_step_limit'
        try:
            if not self.settle_base(hold,'tool_entry'):
                reason='base_not_settled'
            else:
                # Keep the original entry-relative metric goal through settling.
                progress=wrap(self.odometry()[2]-start[2]);last=self.odometry()[2]
                while self._available():
                    current=self.odometry();progress+=wrap(current[2]-last);last=current[2]
                    error=turn_rad-progress
                    if abs(error)<=.03:break
                    action=self.settling_action(hold,previous);action[11:]=[0.,self._speed(error,False)/3.14]
                    self._step(action,'base_turn',reference_qpos=hold.tolist());previous=action
                turn_ok=abs(wrap(heading-self.odometry()[2]))<=.03
                if turn_ok and not self.stopped:
                    settled=self.settle_base(hold,'before_drive' if forward_m else 'turn_exit')
                    if settled and forward_m:
                        previous=np.zeros(13)
                        while self._available():
                            current=self.odometry();error=target-current[:2];distance=float(np.linalg.norm(error))
                            yaw=wrap(heading-current[2])
                            if distance<=.02 and abs(yaw)<=.03:break
                            linear=0.;angular=self._speed(yaw,False)
                            if distance>.02:
                                sign=1. if error@direction>=0 else -1.
                                steer=wrap(math.atan2(error[1],error[0])+(math.pi if sign<0 else 0.)-current[2])
                                angular=self._speed(steer,False)
                                if abs(steer)<=math.pi/4:
                                    linear=self._speed(sign*distance,True)*max(0.,math.cos(steer))
                            action=self.settling_action(hold,previous);action[11:]=[linear,angular/3.14]
                            self._step(action,'base_drive',reference_qpos=hold.tolist());previous=action
                        if not self.stopped:
                            settled=self.settle_base(hold,'drive_exit')
                    current=self.odometry()
                    arrived=bool(settled and np.linalg.norm(target-current[:2])<=.02 and abs(wrap(heading-current[2]))<=.03)
            current=self.odometry();delta=odometry(start,current)
            if self.stopped:reason='official_terminated';arrived=False
            elif arrived:reason='ok'
            elif self.steps<self.deadline:reason='residual_after_settle'
            result={'accepted':True,'arrived':arrived,'reason':reason,'steps_used':self.steps-before,
                'requested_turn_rad':float(turn_rad),'requested_forward_m':float(forward_m),
                'actual_turn_rad':float(delta[2]),'actual_forward_m':float((current[:2]-start[:2])@direction),
                'position_error_m':float(np.linalg.norm(target-current[:2])),
                'rotation_error_rad':abs(wrap(heading-current[2])),'official_terminated':self.stopped}
            return result
        finally:
            self._base_active=False;self._guard_deadline=self.max_steps;self._sync_boundary()
            self.last_goal=self.fk.tcp(self.read_qpos())
            self.call_records.append({'tool':'move_base','entry':entry,'exit':self._snapshot(),
                'settle_steps':sum(t['kind']=='base_settle' for t in self.trace if t['step']>before),
                'phase_steps':{k:sum(t['kind']==k for t in self.trace if t['step']>before) for k in ['base_settle','base_turn','base_drive']}})
