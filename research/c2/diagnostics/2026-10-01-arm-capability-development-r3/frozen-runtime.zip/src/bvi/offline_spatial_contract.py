"""Stage-1 offline spatial question and answer contract; no simulator inputs."""
from __future__ import annotations

import math
from decimal import Decimal

DIRECTIONS = ("front", "front_left", "left", "back_left", "back",
              "back_right", "right", "front_right")
GAP_CLASSES = ("near", "middle", "far")
MOTIONS = (
    ("turn_left_10", "turn", .10), ("turn_right_10", "turn", -.10),
    ("turn_left_20", "turn", .20), ("turn_right_20", "turn", -.20),
    ("turn_left_35", "turn", .35), ("turn_right_35", "turn", -.35),
    ("forward_10", "drive", .10), ("forward_20", "drive", .20),
    ("forward_30", "drive", .30), ("backward_10", "drive", -.10),
    ("backward_20", "drive", -.20),
)


def probability_distribution(labels):
    return {"type": "object", "additionalProperties": False,
            "required": list(labels),
            "properties": {key: {"type": "number", "minimum": 0,
                                 "maximum": 1} for key in labels}}


SCENE_ANSWER_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["q1_reach_probability", "q3_direction_probabilities",
                 "q3_distance_m", "q4_gap_probabilities", "q5_action",
                 "q5_success_probability"],
    "properties": {
        "q1_reach_probability": {"type": "number", "minimum": 0, "maximum": 1},
        "q3_direction_probabilities": probability_distribution(DIRECTIONS),
        "q3_distance_m": {"type": "number", "minimum": 0, "maximum": 10},
        "q4_gap_probabilities": {
            "type": "object", "additionalProperties": False,
            "required": ["front", "front_left", "front_right"],
            "properties": {key: probability_distribution(GAP_CLASSES)
                           for key in ("front", "front_left", "front_right")},
        },
        "q5_action": {
            "type": "object", "additionalProperties": False,
            "required": ["kind", "turn_rad", "drive_m", "final_turn_rad"],
            "properties": {
                "kind": {"type": "string", "enum": ["pick_here", "move", "unreachable"]},
                "turn_rad": {"type": "number", "minimum": -3.142, "maximum": 3.142},
                "drive_m": {"type": "number", "minimum": -3, "maximum": 3},
                "final_turn_rad": {"type": "number", "minimum": -3.142,
                                   "maximum": 3.142},
            },
        },
        "q5_success_probability": {"type": "number", "minimum": 0,
                                   "maximum": 1},
    },
}

def motion_answer_schema(action_ids):
    """Per-case Q2 schema: route-rejected actions have no observed label."""
    valid = {row[0] for row in MOTIONS}
    if not action_ids or len(set(action_ids)) != len(action_ids) or not set(action_ids) <= valid:
        raise ValueError("invalid motion action set")
    return {"type": "object", "additionalProperties": False,
            "required": ["q2_collision_probabilities"],
            "properties": {"q2_collision_probabilities":
                probability_distribution(tuple(action_ids))}}


def _validate_distribution(row, labels):
    if not isinstance(row, dict) or set(row) != set(labels):
        raise ValueError("probability distribution keys differ from contract")
    if any(type(row[key]) not in (int, float) or not math.isfinite(row[key])
           or not 0 <= row[key] <= 1 for key in labels):
        raise ValueError("nonfinite or out-of-range probability")
    # Preserve the frozen inclusive +/-0.01 tolerance. Binary floats make
    # 1.01 - 1 slightly greater than .01, falsely rejecting the boundary.
    if abs(sum((Decimal(str(v)) for v in row.values()), Decimal(0)) - Decimal(1)) > Decimal("0.01"):
        raise ValueError("distribution does not sum to one")


def validate_answer(kind, answer, action_ids=None):
    if kind == "motion_questions":
        if not isinstance(answer, dict) or set(answer) != {"q2_collision_probabilities"}:
            raise ValueError("motion answer fields")
        values = answer["q2_collision_probabilities"]
        if not isinstance(values, dict) or set(values) != set(action_ids or ()):
            raise ValueError("motion action set")
        if any(type(value) not in (int, float) or not math.isfinite(value)
               or not 0 <= value <= 1 for value in values.values()):
            raise ValueError("motion probabilities")
        return answer
    if kind != "scene_questions" or not isinstance(answer, dict) or set(answer) != set(
            SCENE_ANSWER_SCHEMA["required"]):
        raise ValueError("scene answer fields")
    _validate_distribution(answer["q3_direction_probabilities"], DIRECTIONS)
    gaps = answer["q4_gap_probabilities"]
    if not isinstance(gaps, dict) or set(gaps) != {"front", "front_left", "front_right"}:
        raise ValueError("gap directions")
    for row in gaps.values():
        _validate_distribution(row, GAP_CLASSES)
    for key in ("q1_reach_probability", "q5_success_probability"):
        value = answer[key]
        if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 1:
            raise ValueError(key)
    distance = answer["q3_distance_m"]
    if type(distance) not in (int, float) or not math.isfinite(distance) or not 0 <= distance <= 10:
        raise ValueError("q3_distance_m")
    action = answer["q5_action"]
    if not isinstance(action, dict) or set(action) != {
            "kind", "turn_rad", "drive_m", "final_turn_rad"} or action["kind"] not in (
            "pick_here", "move", "unreachable"):
        raise ValueError("q5_action")
    for key, limit in (("turn_rad", 3.142), ("drive_m", 3.), ("final_turn_rad", 3.142)):
        value = action[key]
        if type(value) not in (int, float) or not math.isfinite(value) or abs(value) > limit:
            raise ValueError(key)
    if action["kind"] != "move" and any(action[key] != 0 for key in (
            "turn_rad", "drive_m", "final_turn_rad")):
        raise ValueError("nonmovement action has motion fields")
    return answer
