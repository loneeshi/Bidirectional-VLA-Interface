"""v10 removes regularization bias only for precision close alignment."""
from .eef_tools import vector
from .eef_streaming import grip_band
from .eef_tools_v3 import SolutionV3,nearest_continuous,pose_error
from .eef_tools_v9 import FetchToolsV9,TORSO_MOVING_MASS,TORSO_VELOCITY_SECONDS,moving_torso_mass
VERSION='eef-tool-v10-unbiased-close-ik-r1'
class FetchToolsV10(FetchToolsV9):
    def set_gripper(self,command):
        self._precision_close=grip_band(command)==0 and grip_band(self.gripper)!=0
        try:return super().set_gripper(command)
        finally:self._precision_close=False

    def _compensate(self,point):
        if not getattr(self,'_precision_close',False):return super()._compensate(point)
        measured=vector(self.read_qpos(),15)
        seed=self.last_arm_target.copy();seed[[0,1,2,3,4,6]]=measured[[0,1,2,3,4,6]]
        raw=self.ik7.raw.solve(point,seed)
        q=nearest_continuous(raw.qpos,seed)
        pe,re=pose_error(self.fk,q,point)
        jumped,dr,dz=self.ik7.jump(q,seed)
        reason='jump_rejected' if jumped else 'ok' if raw.accepted else 'ik_not_found'
        solved=SolutionV3(reason=='ok',q,pe,re,reason,True,dr,dz,int(raw.accepted),int(jumped),('precision_alignment_unregularized',))
        self.ik_records.append(solved.summary())
        if solved.accepted:self.last_arm_target=q.copy()
        target=self.last_arm_target.copy();target[[0,1,2,3,4,6]]=measured[[0,1,2,3,4,6]]
        return target,solved
