"""Single-attempt history; no cross-attempt memory or event interruption."""
from .eef_guidance_v2 import PROMPT as BASE
VERSION = 'guidance-v4-compact'
PROMPT = BASE.replace('guidance-v2', VERSION).replace('2048x2048','640x640').replace('0..2047','0..639') + """
Each response also includes task_state: belief, uncertainty, expected_change, next_check, each at most 160 characters. These are brief evidence-linked self-reports, not hidden reasoning or measured truth. Cite observation IDs and camera names when relevant; say unknown when evidence is insufficient. First compare the previous expected change with the latest observation and measured result. Preserve unresolved uncertainty unless new evidence resolves it.
History rows identify control-step intervals; all earlier observation text, valid decisions and measured tool feedback are replayed as historical data, never pending commands. Only the previous and current image groups are included; older images are absent unless explicitly recalled. Current measurements override old estimates. Old pixels and base-frame points remain tied to their source observation; do not reuse them as current goals after motion without re-evaluation. No automatic scene-point update is provided.
Use both camera views where informative, but state when either cannot establish clearance. Target distance or a visible floor strip does not establish full-body clearance. Before a base move explain the relevant visual/depth evidence, remaining occlusion and why it supports the chosen distance.
A chunk executes continuously without intermediate Astra visual decisions. Use separate move_to calls when an intermediate pose needs visual confirmation; combine only when you judge that intermediate observation unnecessary. Balance additional calls and settling against the remaining budget. No force or stalled-progress event interrupts a command.
"""

PROMPT += """
Each request is self-contained, with no hidden prior session. Historical image labels include their observation ID and turn; those images are not current sensor state. recall_observation(observation_id) requests one older image group from this attempt, costs a tool call but no environment step. All other parameters are null and poses=[]. Its images appear only on the next decision alongside previous/current views. It cannot replay motion, and locate_point still accepts only the latest observation. Your old notes and task_state are beliefs, not measured facts. Keep notes concise and use history to avoid repeating rejected plans.
"""
