"""v8 uses robot-mass-derived torso damping during gripper settling."""
import xml.etree.ElementTree as ET
import numpy as np
from .eef_tools import vector
from .eef_tools_v7 import FetchToolsV7

VERSION='eef-tool-v8-critical-torso-settling-r1'
TORSO_MOVING_MASS=29.157648076433205
TORSO_STIFFNESS=1000.
TORSO_DAMPING=100.
TORSO_VELOCITY_SECONDS=max(0.,(2*np.sqrt(TORSO_MOVING_MASS*TORSO_STIFFNESS)-TORSO_DAMPING)/TORSO_STIFFNESS)


def moving_torso_mass(urdf):
    xml=ET.parse(urdf).getroot();children={}
    for joint in xml.findall('joint'):
        children.setdefault(joint.find('parent').get('link'),[]).append(joint.find('child').get('link'))
    links={node.get('name'):node for node in xml.findall('link')}
    pending=['torso_lift_link'];mass=0.
    while pending:
        name=pending.pop();node=links[name].find('inertial/mass')
        if node is not None:mass+=float(node.get('value'))
        pending.extend(children.get(name,[]))
    return mass


class FetchToolsV8(FetchToolsV7):
    def settling_action(self,reference,previous_action):
        action=super().settling_action(reference,previous_action)
        q=vector(self.read_qpos(),15);velocity=vector(self.read_qvel(),15)
        # Extra velocity feedback brings the nominal scalar robot PD system
        # to critical damping. It is derived from URDF mass, not A1 refitting.
        offset=self.settling.position_gain*(vector(reference,15)[3]-q[3])-TORSO_VELOCITY_SECONDS*velocity[3]
        desired=np.clip(offset/self.settling.official_delta_scale,-self.settling.action_cap,self.settling.action_cap)
        previous=vector(previous_action,13)[10]
        action[10]=np.clip(previous+np.clip(desired-previous,-self.settling.action_change_cap,self.settling.action_change_cap),-self.settling.action_cap,self.settling.action_cap)
        return action
