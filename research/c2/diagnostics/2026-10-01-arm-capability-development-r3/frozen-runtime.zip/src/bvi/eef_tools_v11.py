"""v11 uses measured torso velocity in exact nominal sampled PD inversion."""
import numpy as np
from scipy.linalg import expm
from .eef_tools import vector
from .eef_tools_v10 import FetchToolsV10
from .eef_tools_v8 import TORSO_MOVING_MASS,TORSO_STIFFNESS,TORSO_DAMPING,TORSO_VELOCITY_SECONDS,moving_torso_mass
VERSION='eef-tool-v11-measured-torso-momentum-r1'

def torso_response(dt):
    # q relative to its measured value at the beginning of this control step.
    # qdd = K/m*(0.1*u-q) - D/m*qdot. Augment with constant normalized u.
    a=np.array([[0.,1.,0.],[-TORSO_STIFFNESS/TORSO_MOVING_MASS,-TORSO_DAMPING/TORSO_MOVING_MASS,.1*TORSO_STIFFNESS/TORSO_MOVING_MASS],[0.,0.,0.]])
    transition=expm(a*dt)
    return float(transition[0,1]),float(transition[0,2])

class FetchToolsV11(FetchToolsV10):
    def inverse_action(self,delta,feedback_reference):
        action=super().inverse_action(delta,feedback_reference)
        q=vector(self.read_qpos(),15);v=vector(self.read_qvel(),15)
        coast,gain=torso_response(self.control_dt)
        desired=delta[3]+self.p.feedback*(feedback_reference[3]-q[3])
        action[10]=np.clip((desired-coast*v[3])/gain,-1.,1.)
        return action
