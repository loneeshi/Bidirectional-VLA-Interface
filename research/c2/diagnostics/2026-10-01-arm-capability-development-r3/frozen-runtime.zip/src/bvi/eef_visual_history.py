"""Attempt-local measured history. Never reads evaluation-side results."""
import math

STATE_FIELDS = ('belief', 'uncertainty', 'expected_change', 'next_check')


def history_index(history):
    cursor = 0
    rows = []
    for turn, entry in enumerate(history):
        call, result = entry['call'] or {}, entry['result']
        steps = int(result.get('steps_used', 0))
        rows.append([turn, call.get('tool', 'invalid'), cursor, cursor + steps,
                     result.get('arrived')])
        cursor += steps
    return {'columns': ['turn', 'tool', 'start_step', 'end_step', 'arrived'], 'rows': rows}


def state_snapshot(obs):
    return {k: obs[k] for k in ('observation_id', 'odometry', 'tcp_pose', 'steps_remaining')}


def transition(previous, current):
    if previous is None:
        return None
    old, new = previous['odometry'], current['odometry']
    yaw = old['dyaw_rad']; dx = new['dx_m']-old['dx_m']; dy = new['dy_m']-old['dy_m']
    delta = new['dyaw_rad']-yaw
    return {'before': previous, 'after': state_snapshot(current),
            'base_delta_in_previous_base': [math.cos(yaw)*dx+math.sin(yaw)*dy,
                                           -math.sin(yaw)*dx+math.cos(yaw)*dy,
                                           math.atan2(math.sin(delta), math.cos(delta))],
            'warning': 'Old images and located points belong to their observation frame; no scene point was refreshed.'}
