"""Stateless request-specific budget checks; full archives remain outside model context."""
import json
from decimal import Decimal
from .eef_compact_config import *
from .eef_compact_contract import build_wire,build_reflection,audit_wire,validate_call,validate_reflection,reasoning_summaries,non_image_bytes
from .eef_visual_api import cost


class BudgetLimitError(ValueError):
    pass


def estimate_wire(wire):
    body=json.loads(wire)
    if 'previous_response_id' in body or body.get('store') is not False:raise ValueError('hidden history forbidden')
    images=[c for message in body['input'] for c in message['content'] if c['type']=='input_image']
    if len(images) not in (0,4,8,12):raise ValueError('bounded image groups')
    image_tokens=len(images)*480 # 640/32 squared *1.2, no resizing.
    input_bound=non_image_bytes(wire)+1024+image_tokens
    if input_bound+OUTPUT_CAP>CONTEXT_LIMIT:raise ValueError('context cap')
    return {'image_count':len(images),'image_tokens':image_tokens,'text_bytes':non_image_bytes(wire),
            'input_bound':input_bound,'output_cap':OUTPUT_CAP,
            'reserve_usd':str(cost(input_bound,OUTPUT_CAP,reserve_write=True))}


def committed_cost(entries):
    # Release unused reservation only after a definitive response with usable usage.
    return sum((Decimal(e['estimated_usd']) if e['status'] in ('valid','invalid_call') and e.get('estimated_usd') is not None
                else Decimal(e['reserve_usd']) for e in entries),Decimal(0))


def build_request(bundle,archive,entries,usd_cap,authorization_sha256):
    if bundle['authorization_sha256']!=authorization_sha256:raise ValueError('authorization binding')
    if any(e['status'] not in ('valid','invalid_call') for e in entries):raise ValueError('unknown provider outcome; stop')
    local=[e for e in entries if e['position']==bundle['position']]
    if any(e['kind']=='reflection' for e in local) or len(local)!=bundle['turn']:raise ValueError('request order')
    wire=build_wire(bundle,archive) if bundle['kind']=='tool' else build_reflection(bundle,archive)
    receipt=estimate_wire(wire);amount=Decimal(receipt['reserve_usd'])
    committed=committed_cost(entries)
    if len(entries)>=78 or not Decimal(usd_cap).is_finite() or Decimal(usd_cap)<=0 or committed+amount>Decimal(usd_cap):
        raise BudgetLimitError('hard USD/request limit; stop before network, no quality downgrade')
    return wire,amount,receipt


def parse_response(raw,receipt,reflection=False):
    body=json.loads(raw);usage=body.get('usage') or {};inp=usage.get('input_tokens');out=usage.get('output_tokens')
    result={'status':'censored','reason':'provider_contract','call':None,'reflection':None,
            'provider_id':body.get('id'),'usage':usage,'reasoning_summaries':reasoning_summaries(body),'estimated_usd':None}
    if type(inp) is int and inp>=0 and type(out) is int and out>=0:result['estimated_usd']=str(cost(inp,out,reserve_write=True))
    if (body.get('status')!='completed' or body.get('model')!=MODEL or body.get('service_tier') not in (None,'default')
        or not isinstance(body.get('id'),str) or not body['id'].startswith('resp_')
        or result['estimated_usd'] is None or inp>receipt['input_bound'] or out>OUTPUT_CAP):return result
    texts=[c['text'] for item in body.get('output',[]) if item.get('type')=='message' for c in item.get('content',[]) if c.get('type')=='output_text']
    try:
        if len(texts)!=1:return result
        value=json.loads(texts[0]);(validate_reflection if reflection else validate_call)(value)
    except (TypeError,ValueError,KeyError):return {**result,'status':'censored' if reflection else 'invalid_call','reason':'invalid_tool_call'}
    return {**result,'status':'valid','reason':None,'call':None if reflection else value,'reflection':value if reflection else None}
