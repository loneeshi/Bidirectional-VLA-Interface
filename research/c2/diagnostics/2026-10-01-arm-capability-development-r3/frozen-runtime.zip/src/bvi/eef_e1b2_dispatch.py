"""B2-only dispatcher: validated notes; done/give_up consume zero actions."""
from .eef_e1b2_contract import validate_call,validate_reflection
from .eef_e1b_dispatch_v13 import dispatch as v13_dispatch

def dispatch(executor,call):
    try:validate_call(call)
    except (ValueError,TypeError,KeyError) as error:
        return None,{'accepted':False,'reason':'invalid_tool_call','parameter_error':str(error)[:150],'steps_used':0}
    if call['tool'] in ('done','give_up'):
        return call,{'accepted':True,'reason':call['tool'],'steps_used':0}
    _,result=v13_dispatch(executor,{k:v for k,v in call.items() if k!='note'})
    return call,result

class AttemptAccounting:
    """One attempt's counters; reflection has no reference to an executor."""
    def __init__(self):
        self.tool_calls=0;self.reflection_requested=False;self.hindsight=None
    def record_tool_call(self):
        if self.reflection_requested or self.tool_calls>=25:raise ValueError('tool-call scope exhausted')
        self.tool_calls+=1
    def request_reflection(self,category):
        if category not in ('time_limit','cumulative_force_limit') or self.reflection_requested:
            raise ValueError('ineligible or duplicate reflection')
        self.reflection_requested=True
    def record_reflection(self,value):
        if not self.reflection_requested or self.hindsight is not None:raise ValueError('reflection state')
        self.hindsight=validate_reflection(value)['hindsight']
