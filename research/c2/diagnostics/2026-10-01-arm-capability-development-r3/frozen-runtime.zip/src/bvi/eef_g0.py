"""CPU trajectory compression for the frozen G0 diagnostic."""
import numpy as np
from scipy.spatial.transform import Rotation, Slerp


def keyframe_indices(frames, position_tol=.01, rotation_tol=.05):
    if not frames:
        raise ValueError('empty teacher trajectory')
    keep = {0, len(frames)-1}
    for i in range(1, len(frames)):
        if abs(frames[i]['gripper_command']-frames[i-1]['gripper_command']) > 1e-6:
            keep.update(range(max(0, i-1), min(len(frames), i+2)))
    def compress(a, b):
        if b-a < 2:
            return
        poses = [np.asarray(frames[k]['tcp_base']) for k in (a, b)]
        slerp = Slerp([a, b], Rotation.from_matrix(np.stack([p[:3, :3] for p in poses])))
        errors = []
        for i in range(a+1, b):
            fraction = (i-a)/(b-a)
            actual = np.asarray(frames[i]['tcp_base'])
            p = poses[0][:3, 3]*(1-fraction)+poses[1][:3, 3]*fraction
            pe = np.linalg.norm(actual[:3, 3]-p)/position_tol
            re = (Rotation.from_matrix(actual[:3, :3])*slerp(i).inv()).magnitude()/rotation_tol
            errors.append(max(pe, re))
        if max(errors) > 1:
            worst = a+1+int(np.argmax(errors))
            keep.add(worst)
            compress(a, worst)
            compress(worst, b)
    anchors = sorted(keep)
    for a, b in zip(anchors, anchors[1:]):
        compress(a, b)
    return sorted(keep)


def strict_pick(info):
    keys = ('is_grasped', 'ee_rest', 'robot_rest', 'is_static', 'cumulative_force_within_limit')
    def value(v):
        if isinstance(v, list):
            v = v[0]
        return v
    return all(bool(value(info.get(k, False))) for k in keys) and float(
        value(info.get('robot_cumulative_force', float('inf')))) < 5000
