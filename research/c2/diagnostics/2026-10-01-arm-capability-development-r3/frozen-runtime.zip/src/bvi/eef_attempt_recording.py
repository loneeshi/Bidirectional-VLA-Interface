"""Evaluation-only, live recording: exactly initial frame + one per env step."""
from pathlib import Path
import json
import numpy as np


def state_differences(before, after, path='state'):
    """Evaluation-only exact diff; do not infer physical meaning or loosen gates."""
    if isinstance(before, dict) and isinstance(after, dict):
        rows=[]
        for key in sorted(before.keys() | after.keys()):
            if key not in before or key not in after: rows.append({'path':path+'/'+str(key),'kind':'missing_key'})
            else: rows.extend(state_differences(before[key],after[key],path+'/'+str(key)))
        return rows
    if isinstance(before,list) and isinstance(after,list):
        if len(before)!=len(after):return [{'path':path,'kind':'length_changed'}]
        return [row for i,(a,b) in enumerate(zip(before,after)) for row in state_differences(a,b,f'{path}/{i}')]
    a,b=np.asarray(before),np.asarray(after)
    if np.array_equal(a,b):return []
    row={'path':path,'before_shape':list(a.shape),'after_shape':list(b.shape),
         'before':a.tolist(),'after':b.tolist()}
    if a.shape==b.shape and a.dtype.kind in 'biuf' and b.dtype.kind in 'biuf':
        finite=np.isfinite(a)&np.isfinite(b)
        row['finite_max_abs_delta']=float(np.max(np.abs(a[finite].astype(float)-b[finite].astype(float)),initial=0))
        row['nonfinite_count']=int(np.size(finite)-np.count_nonzero(finite))
    return [row]


class AttemptRecording:
    def __init__(self, directory, fps):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.fps = float(fps)
        self.count = 0

    def capture_environment(self, environment):
        """Read the evaluator camera without render() marker/state mutation."""
        from .eef_visual_sensing import state_copy, state_equal
        before = state_copy(environment.get_state_dict())
        environment.scene.update_render(update_sensors=False, update_human_render_cameras=True)
        images = environment.scene.get_human_render_camera_images()
        if len(images) != 1:
            raise ValueError('expected one frozen evaluator camera')
        self.capture(lambda: next(iter(images.values())))
        after = state_copy(environment.get_state_dict())
        if not state_equal(before, after):
            (self.directory.parent/'recording-state-diff.eval-only.json').write_text(
                json.dumps({'frame':self.count-1,'differences':state_differences(before,after)},indent=2),encoding='utf-8')
            raise ValueError('evaluation recording changed simulator state after direct camera capture')

    def capture(self, render):
        from PIL import Image
        frame = render()
        if hasattr(frame, 'detach'): frame = frame.detach().cpu().numpy()
        frame = np.asarray(frame)
        if frame.ndim == 4: frame = frame[0]
        if frame.ndim != 3 or frame.shape[-1] != 3 or frame.dtype != np.uint8:
            raise ValueError('invalid evaluation video frame')
        # Durable PNGs survive a killed runner; CPU packaging happens after exit.
        Image.fromarray(frame).save(self.directory / f'{self.count:06d}.png')
        self.count += 1
