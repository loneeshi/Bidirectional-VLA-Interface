"""Offline-testable P0 boundary for C2 organizer actions and prompt history.

The action catalog is derived from the current Observation only. Holding is
measured through the simulator's existing bilateral grasp predicate before an
API request. These checks prevent known impossible Pick/Place requests; they
do not assert that an offered navigation or recovery route will succeed.
"""
from __future__ import annotations

from dataclasses import replace
import hashlib
import json
import math

from .protocol import AllowedCall, Observation, ProtocolError


def action_catalog(observation: Observation, specs) -> dict[str, AllowedCall]:
    calls = sorted({call for call in observation.allowed_calls if call.skill in specs},
                   key=lambda call: (call.skill, call.target_id))
    return {f"A{i:03d}": call for i, call in enumerate(calls)}


def measured_holding(adapter) -> dict:
    from .mshab_adapter import scalar

    held = []
    rows = []
    for goal in adapter.catalog.goals:
        object_id = goal["object_id"]
        index = adapter.catalog.bindings[("pick", object_id)]
        actor = adapter.uenv.subtask_objs[index]
        grasped = bool(scalar(adapter.uenv.agent.is_grasping(actor, max_angle=30)))
        rows.append({"target_id": object_id, "is_grasped": grasped})
        if grasped:
            held.append(object_id)
    if len(held) > 1:
        raise ProtocolError("C2 holding measurement is ambiguous: multiple objects grasped")
    return {"status": "measured_bilateral_finger_contact_30deg",
            "held_target_id": held[0] if held else None,
            "objects": rows}


def prepare_observation(observation: Observation, adapter, *, holding=None) -> Observation:
    """Expose measured holding and remove Pick/Place calls with false prerequisites."""
    holding = measured_holding(adapter) if holding is None else holding
    if holding.get("status") != "measured_bilateral_finger_contact_30deg":
        raise ProtocolError("C2 holding measurement unavailable")
    held = holding.get("held_target_id")
    if held is not None and held not in {g["object_id"] for g in adapter.catalog.goals}:
        raise ProtocolError("C2 held target is not in the current catalog")
    destination_to_object = {g["destination_id"]: g["object_id"]
                             for g in adapter.catalog.goals}
    calls = []
    for call in observation.allowed_calls:
        if call.skill == "pick" and held is not None:
            continue
        if call.skill == "place" and destination_to_object.get(call.target_id) != held:
            continue
        if call.skill == "reposition":
            recovery = observation.metadata.get("recovery", {})
            eligible = recovery.get("eligible_targets", [])
            matches = [row for row in eligible if row.get("target_id") == call.target_id]
            if matches and not any((row.get("skill") == "pick" and held is None) or
                                   (row.get("skill") == "place" and
                                    destination_to_object.get(call.target_id) == held)
                                   for row in matches):
                continue
        calls.append(call)
    prerequisites = {
        "navigate": "May move the base; an offered target still needs measured arrival.",
        "pick": "Requires an empty gripper and the offered target object.",
        "place": "Requires the matching object to be grasped by both fingers.",
        "reposition": "Requires a prior failed manipulation and a valid preparation target; SAC retry needs measured arrival.",
        "abort_task": "Stops this episode unsuccessfully with a reason.",
    }
    return replace(observation, allowed_calls=tuple(calls),
                   metadata={**observation.metadata, "holding": holding,
                             "tool_prerequisites": prerequisites})


def rejection_proposal(text: str) -> dict:
    """Keep the attempted action without trusting arbitrary model prose."""
    def finite_float(value: str) -> float:
        parsed = float(value)
        if not math.isfinite(parsed):
            raise ValueError('Nonfinite JSON number in rejected response')
        return parsed

    def invalid_constant(value: str) -> None:
        raise ValueError('Nonfinite JSON constant in rejected response')

    try:
        data = json.loads(text, parse_float=finite_float,
                          parse_constant=invalid_constant)
    except (ValueError, TypeError):
        return {"response_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                "raw_excerpt": text[:160]}
    if not isinstance(data, dict):
        return {"response_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                "raw_excerpt": text[:160]}
    return {key: data[key] for key in ("action_id", "skill", "target_id",
                                      "recovery_candidate_id", "recovery_goal")
            if key in data}


def append_rejection(history: list[dict], observation_id: str, error) -> dict:
    """Each model rejection is represented; identical consecutive ones are counted."""
    proposal = dict(getattr(error, "proposed_action", {}) or {})
    reason = str(error)
    signature = (observation_id, reason,
                 json.dumps(proposal, sort_keys=True, ensure_ascii=False))
    if history and history[-1].get("kind") == "model_rejection":
        previous = history[-1]
        previous_signature = (previous["observation_id"], previous["reason"],
                              json.dumps(previous["proposed_action"], sort_keys=True,
                                         ensure_ascii=False))
        if signature == previous_signature:
            previous["repeat_count"] += 1
            previous["attempt_ids"].append(error.attempt_id)
            return previous
    row = {"kind": "model_rejection", "observation_id": observation_id,
           "reason": reason, "proposed_action": proposal,
           "repeat_count": 1, "attempt_ids": [error.attempt_id],
           "outcome": "rejected_without_physical_action"}
    history.append(row)
    return row


class NoProgressWatchdog:
    def __init__(self, limit: int = 3):
        if type(limit) is not int or limit < 1:
            raise ValueError("No-progress watchdog limit must be positive")
        self.limit = limit
        self.frame_id = None
        self.count = 0

    def invalid(self, frame_id: str) -> bool:
        if frame_id != self.frame_id:
            self.frame_id, self.count = frame_id, 0
        self.count += 1
        return self.count >= self.limit

    def progress(self) -> None:
        self.frame_id, self.count = None, 0
