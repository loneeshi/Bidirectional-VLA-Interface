"""E1-B robot-only executor: measured boundaries and attempt-relative base control.

No scene, map, world-pose, simulator or provider dependencies.
"""
import math
import numpy as np
from .eef_tools import vector, validate_official_controller
from .eef_tools_v11 import FetchToolsV11

VERSION = 'eef-tool-v12-odometry-base-r1'
LINEAR_LIMIT = .5
ANGULAR_LIMIT = 1.
BASE_STEP_CAP = 80


def wrap(value):
    return math.atan2(math.sin(value), math.cos(value))


def odometry(initial, current):
    """URDF root x/y translation followed by root z rotation, in initial base."""
    start, q = vector(initial, 3), vector(current, 3)
    c, s = math.cos(start[2]), math.sin(start[2])
    dx, dy = q[:2] - start[:2]
    return np.array([c*dx+s*dy, -s*dx+c*dy, wrap(q[2]-start[2])])


def validate_base_runtime(controller, control_freq):
    validate_official_controller(controller)
    cfg = controller.controllers['base'].config
    if (tuple(cfg.joint_names) != ('root_x_axis_joint', 'root_y_axis_joint', 'root_z_rotation_joint')
            or not cfg.normalize_action or not np.allclose(cfg.lower, [-1., -3.14])
            or not np.allclose(cfg.upper, [1., 3.14]) or float(control_freq) != 20.):
        raise ValueError('frozen base mapping or measured 20 Hz control frequency mismatch')


class FetchToolsV12(FetchToolsV11):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not math.isclose(self.control_dt, .05, abs_tol=1e-12):
            raise ValueError('v12 requires verified 20 Hz control frequency')
        self._initial_base = vector(self.read_qpos(), 15)[:3].copy()
        self._base_active = False

    def odometry(self):
        return odometry(self._initial_base, self.read_qpos()[:3])

    def _sync_boundary(self):
        measured = vector(self.read_qpos(), 15).copy()
        self.last_plan_endpoint = measured
        self.last_arm_target = measured.copy()

    def move_eef_chunk(self, targets, *, max_steps):
        try:
            return super().move_eef_chunk(targets, max_steps=max_steps)
        finally:
            self._sync_boundary()

    def set_gripper(self, command):
        try:
            return super().set_gripper(command)
        finally:
            self._sync_boundary()

    def return_to_rest(self):
        try:
            return super().return_to_rest()
        finally:
            self._sync_boundary()

    def _step(self, action, kind, **info):
        # Shared authoritative action counter, including base steps and stops.
        if not self._available():
            return False
        action = vector(action, 13)
        if np.max(abs(action)) > 1+1e-10 or (np.any(action[11:] != 0) and not self._base_active):
            raise ValueError('action bound or unauthorized base channel')
        before = vector(self.read_qpos(), 15).copy()
        status = self.step_callback(action)
        self.previous_delta = vector(self.read_qpos(), 15)-before
        self.steps += 1
        self.stopped = bool(status.get('terminated') or status.get('truncated'))
        self.trace.append({'step': self.steps, 'kind': kind, 'qpos': self.read_qpos().tolist(),
                           'action': action.tolist(), 'delta': self.previous_delta.tolist(), **info})
        return not self.stopped

    def move_base(self, turn_rad, forward_m, *, max_steps=80):
        if (type(turn_rad) not in (float, int) or type(forward_m) not in (float, int)
                or not math.isfinite(turn_rad) or not math.isfinite(forward_m)
                or abs(turn_rad)>math.pi or abs(forward_m)>1.5):
            raise ValueError('move_base requires finite |turn_rad|<=pi and |forward_m|<=1.5')
        if type(max_steps) is not int or not 0 <= max_steps <= BASE_STEP_CAP:
            raise ValueError('base step budget must be an integer from 0 to 80')
        before = self.steps
        self.deadline = min(self.max_steps, before+max_steps)
        start = self.odometry()
        heading = wrap(start[2]+turn_rad)
        direction = np.array([math.cos(heading), math.sin(heading)])
        target = start[:2]+forward_m*direction
        hold = vector(self.read_qpos(), 15).copy()
        previous_action = np.zeros(13)
        phase = 'turn'
        turn_progress = 0.
        last_yaw = start[2]
        arrived = False
        self._base_active = True
        try:
            while not self.stopped:
                current = self.odometry()
                turn_progress += wrap(current[2]-last_yaw)
                last_yaw = current[2]
                yaw_error = wrap(heading-current[2])
                turn_error = turn_rad-turn_progress
                if phase == 'turn' and abs(turn_error) <= .03:
                    phase = 'drive'
                xy_error = float(np.linalg.norm(target-current[:2]))
                if phase == 'drive' and xy_error <= .02 and abs(yaw_error) <= .03:
                    arrived = True
                    break
                if not self._available():
                    break
                linear = 0.
                angular = float(np.clip(2*(turn_error if phase=='turn' else yaw_error), -ANGULAR_LIMIT, ANGULAR_LIMIT))
                if phase == 'drive' and xy_error > .02:
                    # Signed along-track correction supports backward and overshoot.
                    error = target-current[:2]
                    along = float(error @ direction)
                    sign = 1. if along >= 0 else -1.
                    desired = math.atan2(error[1], error[0])+(math.pi if sign < 0 else 0.)
                    steering = wrap(desired-current[2])
                    angular = float(np.clip(2*steering, -ANGULAR_LIMIT, ANGULAR_LIMIT))
                    linear = sign*min(LINEAR_LIMIT, 2*xy_error)*max(0., math.cos(steering))
                    if abs(steering)>math.pi/4:
                        linear = 0.
                action = self.settling_action(hold, previous_action)
                action[11:] = [linear, angular/3.14]
                self._step(action, 'base_'+phase, reference_qpos=hold.tolist())
                previous_action = action
            current = self.odometry()
            delta = odometry(start, current)
            return {'accepted': True, 'arrived': arrived,
                    'reason': 'official_terminated' if self.stopped else 'ok' if arrived else 'tool_step_limit',
                    'steps_used': self.steps-before, 'requested_turn_rad': float(turn_rad),
                    'requested_forward_m': float(forward_m), 'actual_turn_rad': float(delta[2]),
                    'actual_forward_m': float((current[:2]-start[:2]) @ direction),
                    'position_error_m': float(np.linalg.norm(target-current[:2])),
                    'rotation_error_rad': abs(wrap(heading-current[2])), 'official_terminated': self.stopped}
        finally:
            self._base_active = False
            self._sync_boundary()
            # Last EEF goal belonged to the old base frame; close at measured TCP.
            self.last_goal = self.fk.tcp(self.read_qpos())
