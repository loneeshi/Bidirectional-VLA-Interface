"""Fail-closed audit of the exact serialized offline spatial model payload.

The caller must send the returned bytes unchanged. Sensor manifest entries are
produced during rendering and bound to those same bytes by SHA-256.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import json
import math
from collections.abc import Mapping
from io import BytesIO

from PIL import Image

from bvi.offline_spatial_contract import MOTIONS, SCENE_ANSWER_SCHEMA, motion_answer_schema

ALLOWED_KEYS = frozenset({
    "question_kind", "target_semantics", "proprioception", "odometry",
    "head_rgb", "head_depth", "hand_rgb", "hand_depth",
    "motion_actions", "prompt", "answer_schema", "condition", "depth_encoding",
})
DEPTH_ENCODING = "0=invalid; 1..255 linearly maps 0..4000 millimeters; values above 4000 millimeters saturate at 255"
CONDITIONS = frozenset({"rgbd_p0", "rgbd_p1", "rgb_p1",
                        "privileged_topdown_p1", "highres_rgbd_p1"})
SENSOR_FIELDS = {"head_rgb": ("fetch_head", "rgb"),
                 "head_depth": ("fetch_head", "depth"),
                 "hand_rgb": ("fetch_hand", "rgb"),
                 "hand_depth": ("fetch_hand", "depth")}
ODOMETRY_FIELDS = frozenset({"delta_forward_m", "delta_left_m", "delta_yaw_rad",
                             "velocity_forward_m_s", "velocity_left_m_s", "yaw_rate_rad_s"})
PROPRIOCEPTION_FIELDS = frozenset({"joint_positions", "joint_velocities"})
FORBIDDEN_NAMES = (
    "world_pose", "target_pose_xyz", "base_pose_xyz_yaw", "base_link_pose",
    "target_bearing_left_rad", "base_target_horizontal_distance_m",
    "collision_mesh", "navmesh", "ik_result", "ik_witness", "fetch_nav",
    "fetch_workspace", "ground_truth", "strict_pick_success", "pick_outcome",
    "source_snapshot_sha256", "q2_labels", "q3_labels",
)


def _numeric(value):
    return type(value) in (float, int) and math.isfinite(value)


def _audit_sensor(field, value, trusted, expected_size):
    if not isinstance(value, Mapping) or set(value) != {
            "camera", "modality", "sha256", "data_base64"}:
        raise ValueError(f"sensor object schema: {field}")
    if (value["camera"], value["modality"]) != SENSOR_FIELDS[field]:
        raise ValueError(f"third-person or modality mismatch: {field}")
    if not isinstance(trusted, Mapping) or set(trusted) != {
            "sha256", "camera", "modality", "width", "height"}:
        raise ValueError(f"missing trusted sensor manifest: {field}")
    expected_hash = trusted["sha256"]
    if (trusted["camera"], trusted["modality"]) != SENSOR_FIELDS[field] or (
            trusted["width"], trusted["height"]) != (expected_size, expected_size):
        raise ValueError(f"untrusted camera or resolution: {field}")
    try:
        raw = base64.b64decode(value["data_base64"], validate=True)
    except (ValueError, binascii.Error, TypeError) as exc:
        raise ValueError(f"invalid sensor bytes: {field}") from exc
    if not raw or hashlib.sha256(raw).hexdigest() != expected_hash or value["sha256"] != expected_hash:
        raise ValueError(f"sensor bytes differ from trusted manifest: {field}")
    try:
        with Image.open(BytesIO(raw)) as image:
            if image.format != "PNG" or image.size != (expected_size, expected_size):
                raise ValueError("sensor PNG dimensions")
            if image.mode != ("RGB" if value["modality"] == "rgb" else "L"):
                raise ValueError("sensor PNG encoding")
            image.verify()
    except (OSError, ValueError) as exc:
        raise ValueError(f"invalid sensor PNG: {field}") from exc


def audit_request(request: Mapping, *, sensor_manifest: Mapping,
                  expected_prompt_sha256: str, expected_target_semantics: str,
                  privileged: bool = False) -> bytes:
    """Reject untrusted data, then return canonical bytes to dispatch unchanged."""
    if not isinstance(request, Mapping) or request.get("condition") not in CONDITIONS:
        raise ValueError("request or condition")
    allowed = ALLOWED_KEYS | ({"simulator_ground_truth_topdown"} if privileged else set())
    if set(request) - allowed or not {"question_kind", "prompt", "answer_schema",
                                      "condition", "target_semantics"} <= set(request):
        raise ValueError("request field violation")
    if privileged != (request["condition"] == "privileged_topdown_p1"):
        raise ValueError("privilege condition mismatch")
    if privileged != ("simulator_ground_truth_topdown" in request):
        raise ValueError("topdown privilege marker mismatch")
    if request["target_semantics"] != expected_target_semantics:
        raise ValueError("unfrozen target semantics")
    if not isinstance(request["prompt"], str) or hashlib.sha256(
            request["prompt"].encode("utf-8")).hexdigest() != expected_prompt_sha256:
        raise ValueError("prompt differs from frozen version")
    if request["question_kind"] == "scene_questions":
        if "motion_actions" in request or request["answer_schema"] != SCENE_ANSWER_SCHEMA:
            raise ValueError("scene question contract")
    elif request["question_kind"] == "motion_questions":
        actions = request.get("motion_actions")
        known = {row[0]: {"action_id": row[0], "kind": row[1], "amount": row[2]}
                 for row in MOTIONS}
        if not isinstance(actions, list) or not actions or any(
                not isinstance(a, Mapping) or a.get("action_id") not in known or
                a != known[a["action_id"]] for a in actions):
            raise ValueError("motion question actions")
        ids = [a["action_id"] for a in actions]
        if len(set(ids)) != len(ids) or request["answer_schema"] != motion_answer_schema(ids):
            raise ValueError("motion question contract")
    else:
        raise ValueError("question kind")
    required_sensors = {"head_rgb", "hand_rgb"}
    if request["condition"] != "rgb_p1":
        required_sensors |= {"head_depth", "hand_depth"}
        if request.get("depth_encoding") != DEPTH_ENCODING:
            raise ValueError("unfrozen depth visualization encoding")
    elif "depth_encoding" in request:
        raise ValueError("RGB condition must not include depth encoding")
    if {key for key in SENSOR_FIELDS if key in request} != required_sensors:
        raise ValueError("sensor set differs from condition")
    if set(sensor_manifest) != required_sensors:
        raise ValueError("trusted sensor manifest mismatch")
    expected_size = 256 if request["condition"] == "highres_rgbd_p1" else 128
    for field in required_sensors:
        _audit_sensor(field, request[field], sensor_manifest[field], expected_size)
    if privileged:
        topdown = request["simulator_ground_truth_topdown"]
        if not isinstance(topdown, Mapping) or set(topdown) != {
                "source", "sha256", "data_base64"} or topdown["source"] != "simulator_ground_truth":
            raise ValueError("privileged map source marker")
        try:
            raw = base64.b64decode(topdown["data_base64"], validate=True)
        except (ValueError, binascii.Error, TypeError) as exc:
            raise ValueError("privileged map bytes") from exc
        if not raw or topdown["sha256"] != hashlib.sha256(raw).hexdigest():
            raise ValueError("privileged map hash")
        try:
            with Image.open(BytesIO(raw)) as image:
                if image.format != "PNG" or image.mode != "RGB" or image.size != (940, 430):
                    raise ValueError("privileged map encoding or dimensions")
                image.verify()
        except (OSError, ValueError) as exc:
            raise ValueError("invalid privileged map PNG") from exc
    for field, names in (("proprioception", PROPRIOCEPTION_FIELDS),
                         ("odometry", ODOMETRY_FIELDS)):
        values = request.get(field, {})
        if not isinstance(values, Mapping) or set(values) - names:
            raise ValueError(f"unapproved {field} field")
        for key, value in values.items():
            if field == "proprioception":
                if not isinstance(value, Mapping) or any(not _numeric(x) for x in value.values()):
                    raise ValueError("invalid joint measurement")
            elif not _numeric(value):
                raise ValueError("invalid local odometry")
    # Scan nested field names and text outside the intentionally privileged map.
    def walk(value):
        if isinstance(value, Mapping):
            for key, child in value.items():
                if any(term in str(key).lower() for term in FORBIDDEN_NAMES):
                    raise ValueError(f"forbidden nested field: {key}")
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)
        elif isinstance(value, str):
            if "fetch_nav" in value.lower() or "fetch_workspace" in value.lower():
                raise ValueError("third-person camera provenance")
    walk({key: value for key, value in request.items()
          if key != "simulator_ground_truth_topdown"})
    return json.dumps(request, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")
