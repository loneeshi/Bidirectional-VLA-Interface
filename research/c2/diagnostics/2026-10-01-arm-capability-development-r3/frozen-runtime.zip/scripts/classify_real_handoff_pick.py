"""Classify a recorded first-Pick SAC trace using the frozen census rules.

This CPU-only classifier expects measured per-step contacts and geometry. It
fails closed when those measurements are absent; missing data are not counted
as reach or timeout failures.
"""

import argparse
import json
from pathlib import Path


F_TOUCH_N = 1.0
D_REACH_M = 0.15
BASE_LINKS = frozenset({"base_link", "r_wheel_link", "l_wheel_link", "estop_link", "laser_link"})
ARM_BODY_LINKS = frozenset({
    "bellows_link", "bellows_link2", "elbow_flex_link", "forearm_roll_link",
    "gripper_link", "head_camera_depth_frame", "head_camera_depth_optical_frame",
    "head_camera_link", "head_camera_rgb_frame", "head_camera_rgb_optical_frame",
    "head_pan_link", "head_tilt_link", "root_arm_1_link_1", "root_arm_1_link_2",
    "shoulder_lift_link", "shoulder_pan_link", "torso_fixed_link", "torso_lift_link",
    "upperarm_roll_link", "wrist_flex_link", "wrist_roll_link",
})


def classify(trace):
    if trace.get("infrastructure_censored"):
        return "infrastructure_censored"
    steps = trace.get("steps")
    if not isinstance(steps, list) or not steps:
        return "unclassified"
    if trace.get("strict_pick_success") is True:
        return "strict_success"
    if trace.get("strict_pick_success") is not False:
        return "unclassified"
    if any(any(key not in step or step[key] is None
               for key in ("is_grasped", "target_pair_force_n")) for step in steps):
        return "unclassified"
    if any(step["is_grasped"] for step in steps):
        return "grasped_but_incomplete"
    if any(step["target_pair_force_n"] > F_TOUCH_N for step in steps):
        return "grasp_failure"
    if any(step["target_pair_force_n"] > 0 for step in steps):
        return "unclassified"  # Contact below F_touch invalidates no-contact categories.
    if any(any(key not in step or step[key] is None
               for key in ("tcp_target_distance_m", "non_target_contacts",
                           "robot_total_contact_impulse_ns")) for step in steps):
        return "unclassified"

    totals = {}
    all_impulse = 0.0
    force_limit_step = trace.get("force_limit_step")
    force_limit_max = None
    for index, step in enumerate(steps):
        all_impulse += float(step["robot_total_contact_impulse_ns"])
        contacts = step["non_target_contacts"]
        if not isinstance(contacts, list):
            return "unclassified"
        if force_limit_step == index:
            force_limit_max = max(contacts, key=lambda pair: pair["impulse_ns"], default=None)
        for pair in contacts:
            key = (pair["robot_link"], pair["other"])
            totals[key] = totals.get(key, 0.0) + float(pair["impulse_ns"])
    if totals:
        dominant, dominant_impulse = max(totals.items(), key=lambda item: item[1])
        at_limit = force_limit_max is not None and dominant == (
            force_limit_max["robot_link"], force_limit_max["other"])
        if dominant_impulse > 0 and (dominant_impulse > 0.5 * all_impulse or at_limit):
            link = dominant[0]
            if link in BASE_LINKS:
                return "base_obstacle_collision"
            if link in ARM_BODY_LINKS:
                return "arm_or_body_environment_collision"
            return "unclassified"
    minimum = min(float(step["tcp_target_distance_m"]) for step in steps)
    if minimum > D_REACH_M:
        return "not_reached"
    if trace.get("official_termination_reason") == "pick_horizon_exhausted":
        return "approached_without_contact_timeout"
    return "unclassified"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trace", type=Path)
    args = parser.parse_args()
    trace = json.loads(args.trace.read_text(encoding="utf-8"))
    print(json.dumps({"mechanism": classify(trace), "f_touch_n": F_TOUCH_N,
                      "d_reach_m": D_REACH_M, "base_links": sorted(BASE_LINKS),
                      "arm_body_links": sorted(ARM_BODY_LINKS)}))


if __name__ == "__main__":
    main()
