"""Evaluation-only command geometry, not a prediction of physical execution."""
import numpy as np
from project_eef_trajectory_into_demo import rotation_z


def segments(result):
    frames=result['frames']; initial=result.get('initial_robot_state') or {}
    records=result.get('base_call_records_eval_only') or []
    first_q=initial.get('qpos') or (records[0].get('entry',{}).get('qpos') if records else None)
    cursor=0; output=[]
    for row in result.get('commands',[]):
        call=row.get('call') or {}; outcome=row.get('result') or {}
        end=cursor+int(outcome.get('steps_used') or 0)
        before=frames[cursor-1] if cursor else initial
        q=before.get('qpos') if before else None
        if q is None and not cursor:q=first_q
        path=[]; actual=[]; kind=None
        if q is not None and outcome.get('accepted') is not False:
            root=np.array([q[0],q[1],0.]); rot=rotation_z(q[2])
            if call.get('tool') in ('move_to','move_eef_chunk'):
                kind='TCP waypoint connectors (not IK/interpolated path)'
                if before.get('tcp_base') is not None:path.append(root+rot@np.asarray(before['tcp_base'])[:3,3])
                path.extend(root+rot@np.asarray(p['position']) for p in call.get('poses',[]))
                actual=[np.array([f['qpos'][0],f['qpos'][1],0.])+rotation_z(f['qpos'][2])@np.asarray(f['tcp_base'])[:3,3] for f in frames[cursor:end]]
            elif call.get('tool')=='move_base':
                kind='base translation after commanded turn'
                heading=q[2]+call['turn_rad']
                path=[root,root+np.array([np.cos(heading),np.sin(heading),0.])*call['forward_m']]
                actual=[np.array([f['qpos'][0],f['qpos'][1],0.]) for f in frames[cursor:end]]
        output.append({'turn':row.get('turn'),'start':cursor,'end':end,'kind':kind,'commanded':path,'actual':actual})
        cursor=end
    return output


def draw_command_comparison(image, plans, qpos, step):
    from PIL import ImageDraw,ImageFont
    from project_eef_trajectory_into_demo import project
    draw=ImageDraw.Draw(image)
    try:font=ImageFont.truetype('DejaVuSans.ttf',12)
    except OSError:font=ImageFont.load_default()
    # Only reveal a command after it was issued, never future commands.
    plan=next((p for p in plans if p['start']<step<=p['end']),None)
    def line(points,color,dashed=False):
        for a,b in zip(points,points[1:]):
            pa,pb=project(a,qpos),project(b,qpos)
            if pa is None or pb is None:continue
            if dashed:
                n=max(1,int(np.linalg.norm(np.array(pb)-pa)/8))
                for i in range(0,n,2):
                    x=np.array(pa)+(np.array(pb)-pa)*i/n;y=np.array(pa)+(np.array(pb)-pa)*min(i+1,n)/n
                    draw.line([tuple(x),tuple(y)],fill=color,width=3)
            else:draw.line([pa,pb],fill=color,width=4)
    if plan and plan['kind']:
        line(plan['commanded'],(255,70,220),True)
        line(plan['actual'][:step-plan['start']],(255,205,30))
    draw.rectangle((5,55,507,99),fill=(10,20,30))
    draw.text((10,58),'Pink dashed: commanded | Yellow: executed this call',font=font,fill='white')
    draw.text((10,78),(plan or {}).get('kind') or 'No metric path in this tool call',font=font,fill='white')
    return image
