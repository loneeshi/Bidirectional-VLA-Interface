"""Export one frozen handoff's official Fetch RGB-D and same-snapshot geometry.

No policy, model, simulator step, or navigation call is made here.
"""
from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import time
from types import SimpleNamespace

from run_real_handoff_pick_case import GPU1, MSHAB_COMMIT, SEQUENTIAL_SHA256, digest, tensor_digest
from run_real_handoff_gate_v2_condition import cpu_rng_states_after_deserialization, rebase_init_config_index

MANISKILL_SAPIEN_ENV_SHA256 = "09a176d2a81924ae3b0234405bab2d45cd861a250c37ea52f12b6994b5753208"


def save_json(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False,
                               allow_nan=False), encoding="utf-8")


def depth_visualization_8bit(depth_mm):
    """0 marks invalid; 1..255 linearly encodes 0..4000 mm, saturating above."""
    import numpy as np

    depth = np.asarray(depth_mm)
    if depth.ndim != 2 or not np.issubdtype(depth.dtype, np.integer):
        raise ValueError("depth must be a two-dimensional integer millimeter array")
    clipped = np.clip(depth.astype(np.float32), 0, 4000)
    return np.where(depth > 0, 1 + np.rint(clipped * 254 / 4000), 0).astype(np.uint8)


def trusted_sensor_manifest(view_dir: Path, resolution: int) -> dict:
    """Produce only the exact fields accepted by the model-request auditor."""
    from PIL import Image

    if resolution not in (128, 256):
        raise ValueError("unexpected sensor resolution")
    result = {}
    for field, camera, modality in (
        ("head_rgb", "fetch_head", "rgb"),
        ("head_depth", "fetch_head", "depth"),
        ("hand_rgb", "fetch_hand", "rgb"),
        ("hand_depth", "fetch_hand", "depth"),
    ):
        path = view_dir / f"{camera}-{modality}.png"
        with Image.open(path) as image:
            if image.format != "PNG" or image.size != (resolution, resolution):
                raise ValueError(f"invalid rendered sensor dimensions: {path.name}")
            if modality == "rgb" and image.mode != "RGB":
                raise ValueError(f"invalid RGB encoding: {path.name}")
            if modality == "depth" and image.mode != "L":
                raise ValueError(f"invalid depth encoding: {path.name}")
            image.verify()
        result[field] = {"sha256": digest(path), "camera": camera,
                         "modality": modality, "width": resolution,
                         "height": resolution}
    return result


def state_difference_summary(reference, observed, *, limit: int = 32) -> list[dict]:
    """Identify changed state leaves without serializing large simulator tensors."""
    import numpy as np

    changes = []

    def walk(left, right, path):
        if len(changes) >= limit:
            return
        if isinstance(left, dict) and isinstance(right, dict):
            for key in sorted(set(left) | set(right), key=str):
                child_path = f"{path}.{key}" if path else str(key)
                if key not in left or key not in right:
                    changes.append({"path": child_path, "error": "missing_key"})
                else:
                    walk(left[key], right[key], child_path)
                if len(changes) >= limit:
                    return
            return
        if isinstance(left, (list, tuple)) and isinstance(right, (list, tuple)):
            if len(left) != len(right):
                changes.append({"path": path, "error": "length_mismatch"})
                return
            for index, (a, b) in enumerate(zip(left, right)):
                walk(a, b, f"{path}[{index}]")
                if len(changes) >= limit:
                    return
            return
        if hasattr(left, "detach"):
            left = left.detach().cpu().numpy()
        if hasattr(right, "detach"):
            right = right.detach().cpu().numpy()
        a, b = np.asarray(left), np.asarray(right)
        if a.shape != b.shape:
            changes.append({"path": path, "error": "shape_mismatch"})
            return
        if a.dtype.kind in "biuf" and b.dtype.kind in "biuf":
            difference = float(np.max(np.abs(a.astype(float) - b.astype(float)),
                                      initial=0))
        else:
            difference = 0.0 if np.array_equal(a, b) else float("inf")
        if not math.isfinite(difference) or difference > 0:
            changes.append({"path": path, "max_abs_error":
                            difference if math.isfinite(difference) else "infinite"})

    walk(reference, observed, "")
    return changes


def read_sensor_data_without_evaluate(uenv) -> dict:
    """Use ManiSkill's camera pathway without MS-HAB's mutating get_info()."""
    data = uenv._get_obs_sensor_data()
    if not isinstance(data, dict) or not {"fetch_head", "fetch_hand"} <= set(data):
        raise ValueError("expected official head and hand sensor data")
    return data


def run(args):
    import numpy as np
    import sapien
    import torch
    from PIL import Image
    from mani_skill import ASSET_DIR
    from mani_skill.envs.sapien_env import BaseEnv
    from mshab.envs.make import EnvConfig
    import mshab.envs.sequential_task as sequential
    import bvi.nav_camera_env  # noqa: F401, registers BVISequentialWorkspaceCamera-v0
    from bvi.logging import JsonlLogger
    from bvi.mshab_adapter import make_mshab_adapter, scalar
    from check_c2_snapshot_restore import max_error, restore
    from export_c2_collision_bundle import capture_reference, export_bundle
    from audit_c2_fetch_self_filter import audit as audit_self_filter
    from extract_c2_grasp_templates import extract as extract_grasps

    started = time.monotonic()
    auth = json.loads(args.authorization.read_text(encoding="utf-8"))
    expected_output = Path(
        "/home/pshuai/bvi-research/runs/real-handoff-spatial-stage1-20260927/"
        "results-render-batch-001")
    if (os.environ.get("CUDA_VISIBLE_DEVICES") != GPU1 or
        auth.get("status") != "user_approved" or
        auth.get("authorization_id") != "spatial-stage1-gpu1-render-batch-001" or
        auth.get("experiment_id") != "real-handoff-spatial-stage1-20260927" or
        auth.get("gpu_uuid") != GPU1 or
        auth.get("freeze_input_v10_sha256") != digest(args.freeze) or
        auth.get("single_process_seconds_max") != 120 or
        auth.get("gpu1_process_seconds_max") != 3600 or
        auth.get("processes_max") != 59 or
        auth.get("parallel_processes_max") != 1 or
        auth.get("output_root") != str(expected_output) or
        args.output.parent != expected_output or
        args.output != Path(auth["output_root"]) / f"plan-{args.position:03d}" or
        auth.get("provider_requests_max") != 0 or
        auth.get("policy_actions_max") != 0 or
        auth.get("runpod_resources_max") != 0):
        raise ValueError("outside approved GPU1 render scope")
    frozen = json.loads(args.freeze.read_text(encoding="utf-8"))
    expected = {item["plan_position"]: item["snapshot_sha256"]
                for item in frozen["roster"]}
    positions = [item["plan_position"] for item in frozen["roster"]
                 if item["plan_position"] != 5]
    if (len(expected) != 60 or len(positions) != 59 or
            auth.get("positions") != positions or
            args.position not in positions or
            frozen.get("amendment_008", {}).get("accepted_pilot_result_sha256") !=
            auth.get("accepted_pilot_result_sha256")):
        raise ValueError("frozen render roster or accepted pilot differs")
    if digest(sequential.__file__) != SEQUENTIAL_SHA256:
        raise ValueError("official sequential runtime changed")
    if digest(Path(inspect.getfile(BaseEnv))) != MANISKILL_SAPIEN_ENV_SHA256:
        raise ValueError("pinned ManiSkill observation runtime changed")
    commit = subprocess.check_output(["git", "-C",
        str(Path(sequential.__file__).resolve().parents[2]), "rev-parse", "HEAD"],
        text=True).strip()
    if commit != MSHAB_COMMIT:
        raise ValueError("official runtime commit changed")
    if digest(args.snapshot) != expected[args.position]:
        raise ValueError("frozen handoff snapshot hash mismatch")
    roster = json.loads(args.roster.read_text(encoding="utf-8"))
    row = roster["plans"][args.position]
    census = json.loads(args.census_result.read_text(encoding="utf-8"))
    if census["row"] != row or census["status"] != "completed":
        raise ValueError("census provenance mismatch")
    expected_input = census["handoff"]["pick_input_sha256"]
    rearrange = ASSET_DIR / "scene_datasets/replica_cad_dataset/rearrange"
    plan_path = rearrange / "task_plans/tidy_house/sequential/val/all.json"
    if digest(plan_path) != roster["source_task_plans_sha256"]:
        raise ValueError("task plan hash mismatch")
    episodes = json.loads(args.episode_configs.read_text(encoding="utf-8"))
    if digest(rearrange / row["init_config_name"]) != episodes["rows"][args.position]["episode_config_sha256"]:
        raise ValueError("episode configuration hash mismatch")
    args.output.mkdir(parents=True, exist_ok=False)
    report = {"schema": "bvi.real-handoff-spatial-gpu1-render-case/1",
              "position": args.position, "plan_uid": row["plan_uid"],
              "snapshot_sha256": expected[args.position], "status": "started",
              "freeze_input_v10_sha256": digest(args.freeze),
              "views": [], "policy_actions": 0, "provider_requests": 0}
    save_json(args.output / "result.json", report)
    snapshot = None
    try:
        for resolution in (128, 256):
            kwargs = {"require_build_configs_repeated_equally_across_envs": False,
                      "add_event_tracker_info": True,
                      "sensor_configs": {"width": resolution, "height": resolution},
                      "human_render_camera_configs": {"width": 512, "height": 512},
                      "task_cfgs": {"navigate": {"ignore_arm_checkers": True}}}
            if "invisible_goals_in_human_render" in inspect.signature(BaseEnv.__init__).parameters:
                kwargs["invisible_goals_in_human_render"] = True
            cfg = EnvConfig(env_id="BVISequentialWorkspaceCamera-v0", num_envs=1,
                            max_episode_steps=7000, task_plan_fp=str(plan_path),
                            obs_mode="rgbd", render_mode="rgb_array", record_video=False,
                            info_on_video=False, continuous_task=True, frame_stack=3,
                            stationary_base=False, stationary_torso=False,
                            stationary_head=True, env_kwargs=kwargs)
            view_dir = args.output / f"{resolution}"
            view_dir.mkdir()
            adapter = None
            try:
                logger = JsonlLogger(view_dir / "adapter-events.jsonl", f"render-{args.position}-{resolution}")
                adapter = make_mshab_adapter(cfg, logger, view_dir,
                                             seed=row["asset_plan_index"])
                bci = adapter.uenv.scene_builder.build_config_names_to_idxs[row["build_config_name"]]
                tpi = row["task_plan_index_within_build_config"]
                adapter.reset(row["asset_plan_index"], options={"reconfigure": True,
                    "build_config_idxs": [bci],
                    "task_plan_idxs": torch.tensor([tpi], device=adapter.uenv.device)})
                if snapshot is None:
                    snapshot = torch.load(args.snapshot, map_location=adapter.uenv.device,
                                          weights_only=False)
                    cpu_rng_states_after_deserialization(snapshot)
                rebase_init_config_index(snapshot, int(adapter.uenv.init_config_idxs[0]))
                restore(adapter, snapshot, mode="public")
                error = max_error(snapshot["simulator"], adapter.uenv.get_state_dict())
                if error > 1e-5 or int(scalar(adapter.uenv.subtask_pointer)) != 1:
                    raise ValueError(f"handoff restore failed: {error}")
                input_sha = tensor_digest(adapter.observe().policy) if resolution == 128 else None
                if resolution == 128 and input_sha != expected_input:
                    raise ValueError("official 128px SAC input hash mismatch")
                after_input_error = max_error(snapshot["simulator"],
                                              adapter.uenv.get_state_dict())
                report["state_integrity_after_official_input"] = {
                    "max_error": after_input_error if math.isfinite(after_input_error) else "infinite",
                    "changed_fields": state_difference_summary(
                        snapshot["simulator"], adapter.uenv.get_state_dict())
                    if after_input_error > 1e-5 else []}
                save_json(args.output / "result.json", report)
                if after_input_error > 1e-5:
                    raise ValueError("official input observation changed handoff simulator state")
                # BaseEnv.get_obs() calls get_info() first. In this MS-HAB task,
                # get_info() runs evaluate(), which mutates the task clock and force
                # counters. Read the same camera pathway directly, without evaluating
                # the task or advancing any simulator action.
                sensor_data = read_sensor_data_without_evaluate(adapter.uenv)
                after_render_error = max_error(snapshot["simulator"],
                                               adapter.uenv.get_state_dict())
                report["state_integrity_after_sensor_read"] = {
                    "max_error": after_render_error if math.isfinite(after_render_error) else "infinite",
                    "changed_fields": state_difference_summary(
                        snapshot["simulator"], adapter.uenv.get_state_dict())
                    if after_render_error > 1e-5 else []}
                save_json(args.output / "result.json", report)
                if after_render_error > 1e-5:
                    raise ValueError("sensor rendering changed handoff simulator state")
                files = []
                for camera in ("fetch_head", "fetch_hand"):
                    for modality in ("rgb", "depth"):
                        value = sensor_data[camera][modality].detach().cpu().numpy()
                        if value.shape[0] != 1 or value.shape[1:3] != (resolution, resolution):
                            raise ValueError(f"unexpected {camera}/{modality} shape: {value.shape}")
                        value = value[0]
                        file = view_dir / f"{camera}-{modality}.png"
                        if modality == "rgb":
                            if value.ndim != 3 or value.shape[-1] != 3:
                                raise ValueError(f"unexpected RGB channels: {value.shape}")
                            Image.fromarray(value.astype(np.uint8)).save(file)
                        else:
                            if value.ndim != 3 or value.shape[-1] != 1:
                                raise ValueError(f"unexpected depth channels: {value.shape}")
                            raw_path = view_dir / f"{camera}-depth-raw.npy"
                            np.save(raw_path, value)
                            # Preserve the numerical millimeters separately from the
                            # fixed 8-bit visual encoding shown to the model.
                            depth_u16 = np.clip(value[..., 0], 0, 65535).astype(np.uint16)
                            numeric_path = view_dir / f"{camera}-depth-mm16.png"
                            Image.fromarray(depth_u16).save(numeric_path)
                            Image.fromarray(depth_visualization_8bit(value[..., 0])).save(file)
                        entry = {"camera": camera, "modality": modality,
                                 "path": file.relative_to(args.output).as_posix(),
                                 "sha256": digest(file), "shape": list(value.shape),
                                 "dtype": str(value.dtype), "resolution": resolution}
                        if modality == "depth":
                            entry.update({"raw_npy": raw_path.relative_to(args.output).as_posix(),
                                          "raw_npy_sha256": digest(raw_path),
                                          "numeric_png": numeric_path.relative_to(args.output).as_posix(),
                                          "numeric_png_sha256": digest(numeric_path),
                                          "display_encoding": "uint8_png_0_invalid_1_to_255_linear_0_to_4000mm",
                                          "raw_encoding": "numpy_npy_unmodified_int16_millimeters"})
                        files.append(entry)
                trusted = trusted_sensor_manifest(view_dir, resolution)
                trusted_path = view_dir / "trusted-sensor-manifest.json"
                save_json(trusted_path, trusted)
                if resolution == 128:
                    geometry_dir = args.output / "geometry"
                    geometry_dir.mkdir()
                    floor_source = (ASSET_DIR /
                        "scene_datasets/replica_cad_dataset/configs/scenes" /
                        (Path(row["build_config_name"]).stem +
                         ".fetch.navigable_positions_simplified.obj"))
                    if not floor_source.is_file():
                        raise ValueError("official floor triangles missing")
                    floor_copy = geometry_dir / "floor-triangles.obj"
                    shutil.copyfile(floor_source, floor_copy)
                    if digest(floor_copy) != digest(floor_source):
                        raise ValueError("copied floor triangles differ from official source")
                    report["floor_triangles"] = {
                        "source": str(floor_source),
                        "source_sha256": digest(floor_source),
                        "copy_path": floor_copy.relative_to(args.output).as_posix(),
                        "copy_sha256": digest(floor_copy)}
                    bundle_dir = geometry_dir / "collision-bundle"
                    target_hash = "object-" + hashlib.sha256(
                        row["first_pick_obj_id"].encode()).hexdigest()[:12]
                    proposal = {"seed": row["asset_plan_index"],
                                "plan_uid": row["plan_uid"],
                                "handoff_snapshot_sha256": expected[args.position],
                                "request": {"target_id": target_hash,
                                            "call_id": "spatial-stage1-gpu1-render-batch-001"}}
                    bundle = export_bundle(adapter.uenv, SimpleNamespace(images={}),
                        bundle_dir, candidate="C0", proposal=proposal,
                        reference=capture_reference(adapter.uenv),
                        source_scope="real_handoff_batch")
                    bundle_path = bundle_dir / "bundle.json"
                    audit = audit_self_filter(bundle_path, args.self_filter_sources,
                                              sapien.__version__)
                    save_json(geometry_dir / "self-filter-audit.json", audit)
                    templates = extract_grasps(bundle_path, plan_path,
                        rearrange / "grasp_poses/tidy_house", rearrange, 8)
                    save_json(bundle_dir / "grasp-templates.json", templates)
                    if (bundle["status"] != "observed_missing_witness_inputs" or
                            audit["status"] != "simulator_verified_complete"):
                        raise ValueError("same-snapshot geometry coverage incomplete")
                    report["geometry"] = {"bundle_status": bundle["status"],
                        "bundle_issues": bundle["issues"],
                        "self_filter_status": audit["status"],
                        "template_status": templates["status"],
                        "bundle_sha256": digest(bundle_path),
                        "audit_sha256": digest(geometry_dir / "self-filter-audit.json"),
                        "templates_sha256": digest(bundle_dir / "grasp-templates.json")}
                after_export_error = max_error(snapshot["simulator"],
                                               adapter.uenv.get_state_dict())
                if after_export_error > 1e-5:
                    raise ValueError("geometry export changed handoff simulator state")
                report["views"].append({"resolution": resolution,
                    "restore_max_error": error, "pick_input_sha256": input_sha,
                    "expected_pick_input_sha256": expected_input if resolution == 128 else None,
                    "post_render_state_max_error": after_render_error,
                    "post_export_state_max_error": after_export_error,
                    "trusted_sensor_manifest_sha256": digest(trusted_path),
                    "files": files})
                save_json(args.output / "result.json", report)
            finally:
                if adapter is not None:
                    adapter.close()
        report["status"] = "completed"
        return report
    finally:
        report["elapsed_process_seconds_before_exit"] = time.monotonic() - started
        save_json(args.output / "result.json", report)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--position", type=int, required=True)
    for name in ("authorization", "snapshot", "roster", "census-result",
                 "episode-configs", "self-filter-sources", "output", "freeze"):
        parser.add_argument("--" + name, type=Path, required=True)
    print(json.dumps(run(parser.parse_args()), sort_keys=True))


if __name__ == "__main__":
    main()
