"""Durable, bounded server broker. No simulator imports or hardcoded USD ceiling."""
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import time

from bvi.eef_compact_api import estimate_wire, parse_response, committed_cost
from bvi.eef_compact_contract import audit_wire, build_wire, build_reflection
from eef_compact_retry_broker import POLICY, retryable
from eef_compact_broker import transport_error_details
from eef_server_transport import LeaseExpired


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        import os
        os.fsync(stream.fileno())
    tmp.replace(path)


def validate_authorization(auth, now):
    if (auth.get('status') != 'authorized' or not auth.get('authorization_evidence')
            or auth.get('transport_retry') != POLICY or auth.get('prior_budget_transferred') != 0
            or auth.get('resolution') != 640 or auth.get('image_groups') != 2
            or auth.get('model') != 'gpt-6-astra' or auth.get('reasoning') != 'medium'):
        raise ValueError('server authorization or frozen condition mismatch')
    cap = Decimal(auth['usd_cap'])
    if not cap.is_finite() or cap <= 0:
        raise ValueError('positive finite USD authorization required')
    for key in ('logical_requests_cap', 'provider_requests_cap'):
        if type(auth.get(key)) is not int or auth[key] <= 0:
            raise ValueError('positive request caps required')
    if now >= auth['expires_at_epoch']:
        raise LeaseExpired('authorization expired')


def initial_ledger(auth, authorization_hash):
    return {'schema': 'bvi.eef-server-api-ledger/1', 'status': 'running',
            'authorization_sha256': authorization_hash, 'entries': [], 'deliveries': {},
            'scope': {k: auth[k] for k in ('usd_cap', 'logical_requests_cap',
                      'provider_requests_cap', 'gpu1_process_seconds_cap', 'prior_budget_transferred')}}


def frozen_wire(bundle, archive):
    wire = build_wire(bundle, archive) if bundle['kind'] == 'tool' else build_reflection(bundle, archive)
    return wire


def execute_wire(wire, folder, ledger_path, auth, authorization_hash, logical_id, send,
                 *, bundle, archive, reflection=False, live=lambda: True, clock=time.time, sleep=time.sleep):
    """Caller holds the batch process lock. send(wire, attempt_id, directory)."""
    folder, ledger_path = Path(folder), Path(ledger_path)
    folder.mkdir(parents=True, exist_ok=True)
    wire_hash = digest(wire)
    if wire != frozen_wire(bundle, archive) or reflection != (bundle['kind'] == 'reflection'):
        raise ValueError('actual serialized request differs from audited frozen inputs')
    delivery = folder/'delivery.json'
    account = json.loads(ledger_path.read_text(encoding='utf-8'))
    if account['authorization_sha256'] != authorization_hash or account['scope'] != initial_ledger(auth, authorization_hash)['scope']:
        raise ValueError('ledger authorization binding mismatch')
    if delivery.exists():
        prior = json.loads(delivery.read_text(encoding='utf-8'))
        if prior['request_sha256'] != wire_hash or prior['logical_request_id'] != logical_id or prior['authorization_sha256'] != authorization_hash:
            raise ValueError('durable delivery identity mismatch')
        return prior
    validate_authorization(auth, clock())
    estimate = estimate_wire(wire)
    amount = Decimal(estimate['reserve_usd'])
    entries = account['entries']
    answer = {'status': 'censored', 'call': None, 'reflection': None, 'api_attempts': 0,
              'api_attempted': False, 'request_sha256': wire_hash,
              'logical_request_id': logical_id, 'authorization_sha256': authorization_hash}
    def finish(reason=None, stop=False):
        if reason is not None:
            answer['reason'] = reason
        if stop:
            account['status'] = 'stopped_'+(reason or 'provider_contract')
        account['deliveries'][logical_id] = dict(answer)
        save(ledger_path, account)
        save(delivery, answer)
        return answer
    prior = [e for e in entries if e['logical_request_id'] == logical_id]
    if prior:
        if any(e['request_sha256'] != wire_hash for e in prior):
            raise ValueError('same logical request changed bytes')
        answer.update(api_attempts=len(prior), api_attempted=True)
        # A durable provider response is recoverable without sending again.
        raw_path = folder/'attempts'/f"{len(prior)-1:02d}"/'response-raw.json'
        if raw_path.exists():
            try:
                parsed = parse_response(raw_path.read_bytes(), estimate, reflection=reflection)
            except Exception:
                return finish('provider_parse_error', stop=True)
            prior[-1].update(parsed, response_sha256=digest(raw_path.read_bytes()))
            answer.update(parsed)
            return finish(stop=parsed['status'] == 'censored', reason=parsed.get('reason'))
        return finish('prior_send_without_durable_response', stop=True)
    unresolved = [e for e in entries if e['status'] not in ('valid', 'invalid_call')
                  and account['deliveries'].get(e['logical_request_id'], {}).get('status') not in ('valid', 'invalid_call')]
    if account['status'] != 'running' or unresolved:
        return finish('unresolved_prior_outcome', stop=True)
    if len({e['logical_request_id'] for e in entries}) >= auth['logical_requests_cap']:
        return finish('logical_request_limit', stop=True)
    (folder/'request-wire.json').write_bytes(wire)
    save(folder/'input-estimate.json', estimate)
    for attempt in range(POLICY['max_retries']+1):
        if attempt:
            sleep(POLICY['backoff_seconds'][attempt-1])
        if clock() >= auth['expires_at_epoch'] or not live():
            return finish('lease_expired', stop=True)
        if len(entries) >= auth['provider_requests_cap'] or committed_cost(entries)+amount > Decimal(auth['usd_cap']):
            return finish('budget_exhausted', stop=True)
        attempt_id = f"{auth['id']}-{logical_id}-attempt-{attempt:02d}"
        sub = folder/'attempts'/f'{attempt:02d}'
        sub.mkdir(parents=True, exist_ok=False)
        entry = {'request_id': attempt_id, 'logical_request_id': logical_id,
                 'request_sha256': wire_hash, 'status': 'reserved_before_network',
                 'reserve_usd': str(amount), 'estimated_usd': None,
                 'reserved_at_utc': datetime.fromtimestamp(clock(), timezone.utc).isoformat()}
        entries.append(entry)
        save(ledger_path, account)
        answer.update(api_attempted=True, api_attempts=attempt+1)
        try:
            raw = send(wire, attempt_id, sub)
        except Exception as exc:
            details = transport_error_details(exc)
            save(sub/'transport-error.json', details)
            entry.update(status='unknown_provider_outcome', transport_error=details)
            save(ledger_path, account)
            if retryable(exc) and attempt < POLICY['max_retries']:
                continue
            return finish('transport_error', stop=True)
        # Persist raw bytes before parse/ledger/delivery, making crashes recoverable.
        raw_path = sub/'response-raw.json'
        tmp = raw_path.with_suffix('.tmp')
        with tmp.open('wb') as stream:
            stream.write(raw)
            stream.flush()
            import os
            os.fsync(stream.fileno())
        tmp.replace(raw_path)
        try:
            parsed = parse_response(raw, estimate, reflection=reflection)
        except Exception:
            entry['status'] = 'unknown_provider_outcome'
            return finish('provider_parse_error', stop=True)
        entry.update(parsed, response_sha256=digest(raw))
        answer.update(parsed)
        return finish(parsed.get('reason'), stop=parsed['status'] == 'censored')
    raise AssertionError('bounded loop must return')
