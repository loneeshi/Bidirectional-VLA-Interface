"""Extract object-specific successful Pick poses for offline C2 geometry checks.

The official grasp asset stores ``T_agent_tcp_object`` from successful Pick
rollouts. This script binds its object category to the frozen task plan, then
computes a world-frame gripper-midpoint target using the captured object pose:

    T_world_midpoint = T_world_object @ inv(T_agent_tcp_object) @
                       T_agent_tcp_midpoint.

An 8 cm pregrasp offset along negative local TCP Z is a search hypothesis. It
is neither in the official asset nor proof of a collision-free approach. This
script reads files only and emits a separate attachment; the raw bundle stays
untouched. It performs no simulation, policy inference, or GPU work.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re

import numpy as np


SCHEMA = "c2-grasp-templates/1"
PREGRASP_BACKOFF_M = 0.08
FROZEN_SEED4 = (4, "tidy_house-sequential-val-553-0",
                "call-b7c4d9e2f1a8", "object-7df706aa8cd2")
FROZEN_SEED10 = (10, "tidy_house-sequential-val-586-0",
                 "call-13", "object-28e8c099370e")
FROZEN_SEED4_PROPOSAL_SHA256 = (
    "fa72808f515c3f5265bb1b4eef99c135f5db4b86eddb6f0a04ac1756f94d5792")
FROZEN_SEED10_PROPOSAL_SHA256 = (
    "ba03ad3570d2646c2970bdc6e9f4c357ab3c643175452fdf455780e0a582dae3")
FROZEN_SELECTION_MANIFEST_SHA256 = (
    "24fd70bd95e87a25142f353a04cefb18f0da196b63b386c5e37c3ee0d6bf0b34")
EXPECTED_DELTA = {"C1": [0, 0.20], "C2": [0, -0.20],
                  "C3": [1, 0.20], "C4": [1, -0.20],
                  "C5": [2, 0.35], "C6": [2, -0.35]}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def matrix(values, name: str) -> np.ndarray:
    value = np.asarray(values, dtype=np.float64)
    require(value.shape == (4, 4) and np.isfinite(value).all(), f"invalid_{name}")
    require(np.allclose(value[3], [0, 0, 0, 1], atol=1e-6), f"invalid_{name}_bottom_row")
    require(np.allclose(value[:3, :3].T @ value[:3, :3], np.eye(3), atol=1e-3),
            f"invalid_{name}_rotation")
    require(np.linalg.det(value[:3, :3]) > 0.99, f"invalid_{name}_handedness")
    return value


def pose7_to_matrix(raw_pose) -> np.ndarray:
    """ManiSkill/Sapien raw Pose layout is [x,y,z,qw,qx,qy,qz]."""
    value = np.asarray(raw_pose, dtype=np.float64)
    require(value.shape == (7,) and np.isfinite(value).all(), "invalid_asset_pose")
    qw, qx, qy, qz = value[3:]
    require(abs(np.linalg.norm(value[3:]) - 1.0) < 1e-3,
            "asset_quaternion_not_unit")
    result = np.eye(4)
    result[:3, :3] = np.array([
        [1-2*(qy*qy+qz*qz), 2*(qx*qy-qw*qz), 2*(qx*qz+qw*qy)],
        [2*(qx*qy+qw*qz), 1-2*(qx*qx+qz*qz), 2*(qy*qz-qw*qx)],
        [2*(qx*qz-qw*qy), 2*(qy*qz+qw*qx), 1-2*(qx*qx+qy*qy)],
    ])
    result[:3, 3] = value[:3]
    return matrix(result, "asset_pose")


def matching_object(plans: dict, plan_uid: str, target_id: str) -> str:
    match = re.fullmatch(r"tidy_house-sequential-val-(\d+)-0", plan_uid)
    require(match is not None, "unsupported_plan_uid")
    index = int(match.group(1))
    rows = plans.get("plans", [])
    require(index < len(rows), "plan_index_out_of_range")
    plan = rows[index]
    subtasks = plan.get("subtasks", [])
    require(subtasks and subtasks[0].get("uid") == plan_uid,
            "plan_uid_index_binding_mismatch")
    matches = []
    for subtask in subtasks:
        if subtask.get("type") != "pick":
            continue
        object_id = subtask["obj_id"]
        hashed = "object-" + hashlib.sha256(object_id.encode()).hexdigest()[:12]
        if hashed == target_id:
            matches.append(object_id)
    require(len(matches) == 1, f"target_id_plan_binding_count:{len(matches)}")
    return matches[0]


def validate_seed4_proposal(bundle: dict, bundle_path: Path,
                            frozen_proposal_path: Path | None) -> dict:
    """Bind a seed4 export to the immutable rank-3 proposal and run summary."""
    require(frozen_proposal_path is not None, "seed4_frozen_proposal_required")
    require(frozen_proposal_path.is_file() and
            sha256(frozen_proposal_path) == FROZEN_SEED4_PROPOSAL_SHA256,
            "seed4_frozen_proposal_hash_mismatch")
    frozen = json.loads(frozen_proposal_path.read_text(encoding="utf-8"))
    require(frozen.get("schema") == "c2-frozen-rank3-proposal/1" and
            frozen.get("frozen_selection_manifest_sha256") ==
            FROZEN_SELECTION_MANIFEST_SHA256 and
            frozen.get("source_binding", {}).get("selection_rank") == 3 and
            frozen["source_binding"].get("call_id") == FROZEN_SEED4[2] and
            len(frozen.get("pilot_proposals", [])) == 1,
            "seed4_frozen_proposal_identity_mismatch")
    spec = bundle.get("summary", {})
    require(isinstance(spec.get("path"), str) and
            isinstance(spec.get("sha256"), str),
            "seed4_bundle_summary_missing")
    summary_path = bundle_path.parent / spec["path"]
    require(summary_path.is_file() and sha256(summary_path) == spec["sha256"],
            "seed4_bundle_summary_hash_mismatch")
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    candidate = bundle["candidate"]
    require(summary.get("status") == "completed_geometry_precheck" and
            summary.get("geometry_candidate") == candidate and
            summary.get("geometry", {}).get("candidate_id") == candidate and
            (candidate == "C0" or
             summary["geometry"].get("requested_axis_delta") ==
             EXPECTED_DELTA[candidate]) and
            summary.get("proposal") == frozen["pilot_proposals"][0] and
            (summary["proposal"].get("seed"),
             summary["proposal"].get("plan_uid"),
             summary["proposal"].get("request", {}).get("call_id"),
             summary["proposal"].get("request", {}).get("target_id")) ==
            FROZEN_SEED4,
            "seed4_frozen_summary_binding_mismatch")
    return {"path": str(frozen_proposal_path),
            "sha256": FROZEN_SEED4_PROPOSAL_SHA256,
            "selection_manifest_sha256": FROZEN_SELECTION_MANIFEST_SHA256}


def validate_seed10_proposal(bundle: dict, bundle_path: Path,
                             frozen_proposal_path: Path | None) -> dict:
    """Bind a seed10 export to the immutable rank-4 proposal and run summary."""
    require(frozen_proposal_path is not None, "seed10_frozen_proposal_required")
    require(frozen_proposal_path.is_file() and
            sha256(frozen_proposal_path) == FROZEN_SEED10_PROPOSAL_SHA256,
            "seed10_frozen_proposal_hash_mismatch")
    frozen = json.loads(frozen_proposal_path.read_text(encoding="utf-8"))
    require(frozen.get("schema") == "c2-frozen-rank4-proposal/1" and
            frozen.get("frozen_selection_manifest_sha256") ==
            FROZEN_SELECTION_MANIFEST_SHA256 and
            frozen.get("source_binding", {}).get("selection_rank") == 4 and
            frozen["source_binding"].get("call_id") == FROZEN_SEED10[2] and
            len(frozen.get("pilot_proposals", [])) == 1,
            "seed10_frozen_proposal_identity_mismatch")
    spec = bundle.get("summary", {})
    require(isinstance(spec.get("path"), str) and
            isinstance(spec.get("sha256"), str),
            "seed10_bundle_summary_missing")
    summary_path = bundle_path.parent / spec["path"]
    require(summary_path.is_file() and sha256(summary_path) == spec["sha256"],
            "seed10_bundle_summary_hash_mismatch")
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    candidate = bundle["candidate"]
    require(summary.get("status") == "completed_geometry_precheck" and
            summary.get("geometry_candidate") == candidate and
            summary.get("geometry", {}).get("candidate_id") == candidate and
            (candidate == "C0" or
             summary["geometry"].get("requested_axis_delta") ==
             EXPECTED_DELTA[candidate]) and
            summary.get("proposal") == frozen["pilot_proposals"][0] and
            (summary["proposal"].get("seed"),
             summary["proposal"].get("plan_uid"),
             summary["proposal"].get("request", {}).get("call_id"),
             summary["proposal"].get("request", {}).get("target_id")) ==
            FROZEN_SEED10,
            "seed10_frozen_summary_binding_mismatch")
    return {"path": str(frozen_proposal_path),
            "sha256": FROZEN_SEED10_PROPOSAL_SHA256,
            "selection_manifest_sha256": FROZEN_SELECTION_MANIFEST_SHA256}


def extract(bundle_path: Path, plans_path: Path, asset_root: Path,
            source_root: Path, sample_count: int,
            frozen_proposal_path: Path | None = None) -> dict:
    import torch

    bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
    require(bundle.get("schema") == "c2-cpu-reachability/1", "bundle_schema_mismatch")
    if bundle.get("source_scope") == "real_handoff_batch":
        require(bundle.get("candidate") == "C0" and
                isinstance(bundle.get("handoff_snapshot_sha256"), str) and
                len(bundle["handoff_snapshot_sha256"]) == 64 and
                bundle.get("plan_uid") and bundle.get("target_id"),
                "incomplete_real_handoff_grasp_binding")
        frozen_source = None
    else:
        require(bundle.get("candidate") in
                ("C0", "C1", "C2", "C3", "C4", "C5", "C6") and
                ((bundle.get("seed") == 8 and
                  bundle.get("plan_uid") == "tidy_house-sequential-val-17-0" and
                  bundle.get("target_id") == "object-03ff81c74789") or
                 (bundle.get("seed"), bundle.get("plan_uid"),
                  bundle.get("target_id")) ==
                 (FROZEN_SEED4[0], FROZEN_SEED4[1], FROZEN_SEED4[3]) or
                 (bundle.get("seed"), bundle.get("plan_uid"),
                  bundle.get("target_id")) ==
                 (FROZEN_SEED10[0], FROZEN_SEED10[1], FROZEN_SEED10[3])),
                "not_frozen_A1_geometry")
        frozen_source = (validate_seed4_proposal(bundle, bundle_path,
                                                 frozen_proposal_path)
                         if bundle["seed"] == 4 else
                         validate_seed10_proposal(bundle, bundle_path,
                                                  frozen_proposal_path)
                         if bundle["seed"] == 10 else None)
    plan_uid = bundle["plan_uid"]
    target_id = bundle["target_id"]
    plans = json.loads(plans_path.read_text(encoding="utf-8"))
    object_id = matching_object(plans, plan_uid, target_id)
    object_type = object_id.rsplit("-", 1)[0]
    scene_id = bundle.get("target_scene_id")
    require(isinstance(scene_id, str) and scene_id.endswith("env-0_" + object_id),
            "simulator_target_actor_not_bound_to_plan_object")
    asset_path = asset_root / object_type / "grasp_poses.pt"
    require(asset_path.is_file(), "matching_official_grasp_asset_missing")
    asset = torch.load(asset_path, map_location="cpu", weights_only=True)
    require(set(asset) == {"success_qpos", "success_obj_raw_pose_wrt_tcp"},
            "unexpected_asset_keys")
    qpos = asset["success_qpos"].detach().cpu().numpy()
    raw = asset["success_obj_raw_pose_wrt_tcp"].detach().cpu().numpy()
    require(raw.ndim == 2 and raw.shape[1] == 7 and qpos.ndim == 2
            and qpos.shape[0] == raw.shape[0] and raw.shape[0] > 0,
            "invalid_asset_tensor_shapes")
    require(np.isfinite(raw).all() and np.isfinite(qpos).all(),
            "nonfinite_asset_tensor")
    valid = np.flatnonzero((np.linalg.norm(raw[:, :3], axis=1) <= 0.15)
                          & (np.abs(np.linalg.norm(raw[:, 3:], axis=1) - 1) < 1e-3))
    require(len(valid) > 0, "no_official_spawn_eligible_grasps")
    require(sample_count > 0, "sample_count_must_be_positive")
    positions = np.linspace(0, len(valid)-1, min(sample_count, len(valid)), dtype=int)
    selected = valid[positions]
    target_world = matrix(bundle["target_pose_world"], "target_pose_world")
    tcp_in_link = matrix(bundle["robot"]["tcp_in_link"], "tcp_in_link")
    rows = []
    for index in selected:
        object_in_agent_tcp = pose7_to_matrix(raw[index])
        grasp = target_world @ np.linalg.inv(object_in_agent_tcp) @ tcp_in_link
        grasp = matrix(grasp, "grasp_midpoint_world")
        pregrasp = grasp.copy()
        pregrasp[:3, 3] -= PREGRASP_BACKOFF_M * grasp[:3, 2]
        rows.append({
            "id": f"official-{object_type}-{int(index):06d}",
            "source_row_index": int(index),
            "success_qpos": qpos[index].astype(float).tolist(),
            "success_obj_raw_pose_wrt_agent_tcp": raw[index].astype(float).tolist(),
            "success_obj_pose_wrt_agent_tcp": object_in_agent_tcp.tolist(),
            "grasp_tcp_world": grasp.tolist(),
            "pregrasp_tcp_world": pregrasp.tolist(),
            "pregrasp_method": "heuristic_local_tcp_minus_z_0p08m",
        })
    result = {
        "schema": SCHEMA,
        "status": "empirical_grasp_endpoint_templates_with_heuristic_pregrasp",
        "source_scope": bundle.get("source_scope", "frozen_A1"),
        "handoff_snapshot_sha256": bundle.get("handoff_snapshot_sha256"),
        "seed": bundle["seed"], "candidate": bundle["candidate"],
        "plan_uid": plan_uid, "target_id": target_id,
        "object_id": object_id, "object_type": object_type,
        "target_scene_id": scene_id,
        "bundle_source": {"path": str(bundle_path), "sha256": sha256(bundle_path)},
        "task_plan_source": {"path": str(source_root / "task_plans/tidy_house/sequential/val/all.json"),
                             "sha256": sha256(plans_path)},
        "grasp_asset_source": {"path": str(source_root / "grasp_poses/tidy_house" /
                                           object_type / "grasp_poses.pt"),
                               "sha256": sha256(asset_path)},
        "asset_tensor_shapes": {"success_qpos": list(qpos.shape),
                                "success_obj_raw_pose_wrt_tcp": list(raw.shape)},
        "sampling": {"method": "evenly_spaced_valid_original_row_indices",
                     "total_rows": int(len(raw)), "spawn_eligible_rows": int(len(valid)),
                     "requested_count": sample_count,
                     "selected_row_indices": [int(i) for i in selected]},
        "pose_semantics": {
            "asset": "T_agent_tcp_object from successful official Pick rollouts",
            "grasp": "T_world_object @ inverse(T_agent_tcp_object) @ T_agent_tcp_midpoint",
            "pregrasp": "8 cm backoff along negative grasp midpoint local Z; heuristic only",
        },
        "target_pose_world": target_world.tolist(),
        "tcp_in_link": tcp_in_link.tolist(),
        "grasps": rows,
    }
    if frozen_source is not None:
        result["frozen_proposal_source"] = frozen_source
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--task-plans", type=Path, required=True)
    parser.add_argument("--asset-root", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--sample-count", type=int, default=16)
    parser.add_argument("--frozen-proposal", type=Path,
                        help="Required for seed4/seed10: immutable ranked proposal JSON")
    args = parser.parse_args()
    result = extract(args.bundle, args.task_plans, args.asset_root,
                     args.source_root, args.sample_count, args.frozen_proposal)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        raise FileExistsError(args.output)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False),
                           encoding="utf-8")
    print(json.dumps({"output": str(args.output), "object_id": result["object_id"],
                      "selected": result["sampling"]["selected_row_indices"]}))


if __name__ == "__main__":
    main()
