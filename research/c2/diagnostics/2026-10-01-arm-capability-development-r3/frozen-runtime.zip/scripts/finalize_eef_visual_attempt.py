"""CPU-only delivery of full execution history, synchronized demo and trajectory."""
import argparse
import hashlib
import html
import json
import shutil
from pathlib import Path
from types import SimpleNamespace


def register_media(folder, media_root):
    """Local result collection; append to existing indexes, preserve prior entries."""
    folder, media_root = Path(folder), Path(media_root)
    result = json.loads((folder/'result.json').read_text(encoding='utf-8'))
    receipt = json.loads((folder/'delivery'/'delivery.json').read_text(encoding='utf-8'))
    date = result['recorded_at_utc'][:10]
    name = f"c2-pick-visual-{date}-plan{result['position']:03d}-{receipt['result_sha256'][:8]}"
    destination = media_root/name
    if destination.exists(): raise FileExistsError(destination)
    destination.mkdir(parents=True)
    shutil.copytree(folder/'delivery',destination/'delivery')
    shutil.copy2(folder/'result.json',destination/'result.json')
    for image in (folder/'sensors').glob('*/*.png'):
        target = destination/'sensors'/image.parent.name/image.name
        target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(image,target)
    manifest_path=media_root/'manifest.json'
    manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
    for video in (destination/'delivery').glob('*.mp4'):
        manifest['videos'].append({'filename':video.name,'path':video.relative_to(media_root).as_posix(),
            'sha256':sha(video),'bytes':video.stat().st_size,'position':result['position'],
            'condition':result.get('mode'),'outcome':result.get('termination_category'),
            'strict_pick_success':result.get('strict_pick_success'), 'status':result.get('status'),
            'recorded_at_utc':result['recorded_at_utc'],'kind':result.get('recording',{}).get('kind','online Astra attempt')})
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with (media_root/'README.md').open('a',encoding='utf-8') as stream:
        stream.write(f"\n- [{name}]({name}/delivery/README.md) — {result.get('status')}; strict Pick={result.get('strict_pick_success')}; delivery complete={receipt['complete']}.\n")
    return destination/'delivery'/'README.md'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def finalize(folder):
    folder = Path(folder)
    result_path = folder/'result.json'
    result = json.loads(result_path.read_text(encoding='utf-8'))
    out = folder/'delivery'; out.mkdir(exist_ok=True)
    receipt = {'evaluation_only':True, 'result_sha256':sha(result_path),
               'status':result.get('status'), 'artifacts':{}, 'errors':[]}
    sections = ['<meta charset="utf-8"><h1>Single-attempt execution history</h1>',
                '<p>Model notes are self-reports. Evaluation-only artifacts are not model inputs.</p>',
                '<p>'+html.escape(str({k:result.get(k) for k in ('position','mode','status','strict_pick_success','termination_category')}))+'</p>']
    commands = {c['turn']:c for c in result.get('commands',[])}
    sections.append('<p>Recording: '+html.escape(str(result.get('recording',{})))+'</p>')
    sections.append('<h2>All executed commands (evaluation record)</h2><pre>'+html.escape(json.dumps(result.get('commands',[]),ensure_ascii=False,indent=2))+'</pre>')
    # Include pending/censored requests, not only commands that executed.
    for request in sorted((folder/'requests').glob('*.json')):
        bundle = json.loads(request.read_text(encoding='utf-8'))
        response_path = folder/'responses'/request.name
        response = json.loads(response_path.read_text(encoding='utf-8')) if response_path.exists() else {'status':'missing_or_pending'}
        obs = bundle.get('observation',{})
        from bvi.eef_visual_history import history_index
        public = {k:v for k,v in obs.items() if k not in ('sensors','history')}
        public['history_index'] = history_index(obs.get('history',[]))
        sections.append('<h2>'+html.escape(request.stem)+'</h2>')
        for label, value in [('Observation',public),('Response',response),('Executed command',commands.get(bundle.get('turn')))]:
            sections.append('<h3>'+label+'</h3><pre>'+html.escape(json.dumps(value,ensure_ascii=False,indent=2))+'</pre>')
        for name in ('head_rgb','head_depth','hand_rgb','hand_depth'):
            path = folder/'sensors'/request.stem/(name+'.png')
            if path.exists(): sections.append(f'<p>{name}</p><img width="384" src="../sensors/{request.stem}/{name}.png">')
    (out/'history.html').write_text('\n'.join(sections),encoding='utf-8')
    if result.get('frames'):
        try:
            from visualize_eef_trajectory import extract, make_svg, make_html
            data=extract(result); data['source_sha256']=sha(result_path)
            svg, screen=make_svg(data)
            (out/'trajectory.svg').write_text(svg,encoding='utf-8')
            (out/'trajectory.html').write_text(make_html(svg,screen,data,None),encoding='utf-8')
        except Exception as exc: receipt['errors'].append('trajectory: '+str(exc))
        try:
            frames=sorted((folder/'recording-frames').glob('*.png'))
            if len(frames)!=len(result['frames'])+1: raise ValueError('missing live frames; no replay or interpolation substituted')
            if [p.name for p in frames] != [f'{i:06d}.png' for i in range(len(frames))]: raise ValueError('noncontiguous live frames')
            import imageio.v2 as imageio
            fps=1/float(result['control_dt'])
            with imageio.get_writer(out/'online-raw.mp4',fps=fps,codec='libx264',quality=8) as writer:
                for frame in frames: writer.append_data(imageio.imread(frame))
            from make_eef_demo_with_tcp_trajectory import run
            run(SimpleNamespace(video=out/'online-raw.mp4',result=result_path,
                output=out/'online-tcp-demo.mp4',receipt=out/'demo-receipt.json',fps=fps,
                kind=result.get('recording',{}).get('kind','online Astra attempt'),expected_video_sha256=sha(out/'online-raw.mp4'),expected_result_sha256=sha(result_path)))
            from project_eef_trajectory_into_demo import run as project_run
            project_run(SimpleNamespace(video=out/'online-raw.mp4',result=result_path,
                output=out/'online-command-vs-executed.mp4',receipt=out/'command-overlay-receipt.json',
                kind='online',command_overlay=True,expected_video_sha256=sha(out/'online-raw.mp4'),
                expected_result_sha256=sha(result_path)))
        except Exception as exc: receipt['errors'].append('video: '+str(exc))
    else:
        receipt['no_motion'] = True
    for name in ('history.html','trajectory.svg','trajectory.html','online-raw.mp4','online-tcp-demo.mp4','demo-receipt.json','online-command-vs-executed.mp4','command-overlay-receipt.json'):
        if (out/name).exists(): receipt['artifacts'][name]={'path':name,'sha256':sha(out/name)}
    receipt['complete'] = not receipt['errors'] and ('online-tcp-demo.mp4' in receipt['artifacts'] or receipt.get('no_motion',False))
    (out/'delivery.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['# Attempt delivery',f"Outcome: {result.get('status')}; strict Pick: {result.get('strict_pick_success')}",
           'Evaluation only. Video is an online recording, not an action replay.',
           *[f'- [{name}]({name})' for name in receipt['artifacts']],
           *['MISSING/BLOCKED: '+error for error in receipt['errors']]]
    (out/'README.md').write_text('\n\n'.join(lines)+'\n',encoding='utf-8')
    return receipt


if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--attempt',type=Path,required=True)
    parser.add_argument('--register-media',type=Path,help='Local docs/media root; use after collecting remote results')
    args=parser.parse_args()
    receipt_path=args.attempt/'delivery'/'delivery.json'
    receipt=json.loads(receipt_path.read_text(encoding='utf-8')) if args.register_media and receipt_path.exists() else finalize(args.attempt)
    if args.register_media: print(register_media(args.attempt,args.register_media))
    print(json.dumps(receipt,ensure_ascii=False))
    raise SystemExit(0 if receipt['complete'] else 1)
