"""Verify exact runtime paths and robot/environment assets before GPU admission."""
import argparse
import hashlib
import inspect
import json
import os
from pathlib import Path
import subprocess
import sys

SEQUENTIAL_SHA = '47fd4999f7326568a550890caa48eac070901525373fac667ff56384eeb2a6be'
BASE_ENV_SHA = '09a176d2a81924ae3b0234405bab2d45cd861a250c37ea52f12b6994b5753208'
MSHAB_COMMIT = 'e9ff3d23496d38e4431c8d913e147ffa007f7f72'


def configure_runtime(lab_root):
    runtime = lab_root/'src/official-mshab-runtime'
    for package in ('mshab', 'mani_skill'):
        if any(key == package or key.startswith(package+'.') for key in sys.modules):
            raise ValueError('runtime pin must precede environment imports')
    sys.path[:0] = [str(runtime/'mshab'), str(runtime/'ManiSkill')]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(lab_root, census_root, manifest):
    configure_runtime(lab_root)
    import torch
    from mani_skill import ASSET_DIR
    from mani_skill.envs.sapien_env import BaseEnv
    import mshab.envs.sequential_task as sequential
    sequential_path = Path(sequential.__file__)
    base_path = Path(inspect.getfile(BaseEnv))
    if sha(sequential_path) != SEQUENTIAL_SHA or sha(base_path) != BASE_ENV_SHA:
        raise ValueError('official source hashes changed')
    if subprocess.check_output(['git', '-C', str(sequential_path.parents[2]), 'rev-parse', 'HEAD'],
                               text=True).strip() != MSHAB_COMMIT:
        raise ValueError('official MS-HAB commit changed')
    if ASSET_DIR.resolve() != (lab_root/'assets/data').resolve():
        raise ValueError('official asset directory mismatch')
    roster = json.loads((census_root/'stage/roster.json').read_text())
    plan_file = ASSET_DIR/'scene_datasets/replica_cad_dataset/rearrange/task_plans/tidy_house/sequential/val/all.json'
    if sha(plan_file) != roster['source_task_plans_sha256']:
        raise ValueError('official task plans changed')
    checked = []
    for binding in json.loads(manifest.read_text())['roster']:
        case = census_root/'results-full-proposal'/f"plan-{binding['plan_position']:03d}"
        snapshot = case/'full-handoff-capture.pt'
        if sha(snapshot) != binding['snapshot_sha256']:
            raise ValueError('snapshot hash mismatch')
        # Trusted frozen local experiment artifacts, read onto CPU only.
        data = torch.load(snapshot, map_location='cpu', weights_only=False)
        if not {'simulator', 'attributes', 'torch_rng', 'cuda_rng'} <= set(data):
            raise ValueError('snapshot structure incomplete')
        checked.append(binding['plan_position'])
    if torch.cuda.is_initialized():
        raise ValueError('CPU source check initialized CUDA')
    return {'status': 'cpu_runtime_gate_passed', 'sequential_sha256': sha(sequential_path),
        'base_env_sha256': sha(base_path), 'snapshot_cpu_deserialization_positions': checked,
        'cuda_initialized': False, 'simulator_actions': 0, 'api_requests': 0}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--lab-root', type=Path, required=True)
    parser.add_argument('--census-root', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if os.environ.get('CUDA_VISIBLE_DEVICES') != '':
        parser.error('CPU check requires hidden GPUs')
    result = check(args.lab_root, args.census_root, args.manifest)
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result))
