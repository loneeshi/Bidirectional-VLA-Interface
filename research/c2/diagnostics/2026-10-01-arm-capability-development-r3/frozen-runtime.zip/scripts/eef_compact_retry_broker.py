"""Opt-in bounded transport retries; monetary ceiling comes only from authorization."""
import json
import time
import ssl
from decimal import Decimal
from pathlib import Path
from datetime import datetime, timezone
from urllib.error import URLError, HTTPError
from eef_compact_broker import digest, save, transport_error_details
from bvi.eef_compact_api import build_request, parse_response, committed_cost, BudgetLimitError

POLICY = {"version": "bounded-transport-v2", "max_retries": 2, "backoff_seconds": [1, 2]}


def retryable(exc):
    if isinstance(exc, HTTPError):
        return False  # HTTP/provider errors need a separate policy.
    cause = exc.reason if isinstance(exc, URLError) else exc
    if isinstance(cause, ssl.SSLCertVerificationError):
        return False
    if isinstance(cause, (ssl.SSLEOFError, ssl.SSLZeroReturnError)):
        return True
    if isinstance(cause, ssl.SSLError):
        return getattr(cause, 'reason', None) == 'UNEXPECTED_EOF_WHILE_READING'
    return isinstance(cause, (ConnectionError, TimeoutError))


def process(bundle_raw, folder, ledger_path, authorization, authorization_hash, send, archive, sleep=time.sleep):
    folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
    delivery = folder / 'delivery.json'; bh = digest(bundle_raw)
    if delivery.exists():
        prior = json.loads(delivery.read_text(encoding='utf-8'))
        if prior['request_bundle_sha256'] != bh: raise ValueError('changed request')
        return prior  # Re-deliver locally saved response; never call provider again.
    account = json.loads(Path(ledger_path).read_text(encoding='utf-8'))
    cap = Decimal(authorization['usd_cap'])
    request_cap = authorization['provider_requests_cap']
    expected = {'gpu_seconds': authorization['gpu1_process_seconds_cap'], 'requests': request_cap,
                'usd': authorization['usd_cap'], 'old_balance_transferred': 0}
    if (authorization.get('transport_retry') != POLICY or authorization.get('status') != 'authorized'
        or not authorization.get('authorization_evidence') or not cap.is_finite() or cap <= 0
        or type(request_cap) is not int or request_cap <= 0
        or account.get('status') != 'running' or account.get('scope') != expected
        or account.get('authorization_sha256') != authorization_hash):
        raise ValueError('retry authorization/ledger mismatch')
    if (authorization.get('context_version'), authorization.get('resolution'), authorization.get('image_groups')) != ('eef-compact-640-v1',640,2):
        raise ValueError('context mismatch')
    bundle = json.loads(bundle_raw)
    key = f"{bundle['position']:03d}-{bundle['kind']}-{bundle['turn']:03d}"
    entries = account['entries']
    answer = {'status':'censored','call':None,'api_attempted':False,'api_attempts':0,'request_bundle_sha256':bh}
    def finish(reason, status):
        answer['reason']=reason; account['status']=status
        save(ledger_path,account); save(delivery,answer); return answer
    if any(e.get('logical_request_id',e['request_id']) == key for e in entries):
        answer.update(api_attempted=True,api_attempts=sum(e.get('logical_request_id',e['request_id'])==key for e in entries))
        return finish('prior_request_without_durable_delivery','stopped_unknown_outcome')
    # Unknown attempts may remain only behind a completed logical response.
    completed = [e for e in entries if e['status'] in ('valid','invalid_call')]
    completed_keys = {e.get('logical_request_id',e['request_id']) for e in completed}
    if any(e['status'] not in ('valid','invalid_call') and
           (e['status'] != 'unknown_provider_outcome' or e.get('logical_request_id') not in completed_keys) for e in entries):
        return finish('unresolved_prior_request','stopped_unknown_outcome')
    (folder/'request-bundle.json').write_bytes(bundle_raw)
    try:
        wire, amount, estimate = build_request(bundle,archive,completed,authorization['usd_cap'],authorization_hash)
    except BudgetLimitError: return finish('budget_exhausted','stopped_budget')
    except Exception: return finish('audit_rejected','stopped_pre_network')
    (folder/'request-wire.json').write_bytes(wire); save(folder/'input-estimate.json',estimate)
    for attempt in range(POLICY['max_retries']+1):
        if len(entries)>=request_cap or committed_cost(entries)+amount>cap:
            return finish('budget_exhausted','stopped_budget')
        if attempt: sleep(POLICY['backoff_seconds'][attempt-1])
        attempt_key=f'{key}-attempt-{attempt:02d}'
        sub=folder/'attempts'/f'{attempt:02d}';sub.mkdir(parents=True)
        entry={'request_id':attempt_key,'logical_request_id':key,'position':bundle['position'],
               'turn':bundle['turn'],'kind':bundle['kind'],'status':'reserved_before_network',
               'reserve_usd':str(amount),'estimated_usd':None,'request_sha256':digest(wire),
               'reserved_at_utc':datetime.now(timezone.utc).isoformat()}
        entries.append(entry);save(ledger_path,account)
        answer.update(api_attempted=True,api_attempts=attempt+1)
        started=time.monotonic()
        try:
            raw=send(wire,attempt_key)
        except Exception as exc:
            details=transport_error_details(exc);details['elapsed_seconds']=time.monotonic()-started
            save(sub/'transport-error.json',details)
            entry.update(status='unknown_provider_outcome',transport_error=details)
            save(ledger_path,account)
            if retryable(exc) and attempt<POLICY['max_retries']: continue
            return finish('transport_error','stopped_unknown_outcome')
        (sub/'response-raw.json').write_bytes(raw)
        (folder/'response-raw.json').write_bytes(raw)
        try: parsed=parse_response(raw,estimate,reflection=bundle['kind']=='reflection')
        except Exception:
            entry['status']='unknown_provider_outcome'
            return finish('provider_parse_error','stopped_provider_contract')
        entry.update(parsed,response_sha256=digest(raw));answer.update(parsed)
        if parsed['status']=='censored': account['status']='stopped_provider_contract'
        save(ledger_path,account);save(delivery,answer);return answer
