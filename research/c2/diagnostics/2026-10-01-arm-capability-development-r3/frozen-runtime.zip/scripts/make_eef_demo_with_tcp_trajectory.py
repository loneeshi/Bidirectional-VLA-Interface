"""Pair a C2 demo video with the archived end-effector path, frame by frame.

This is evaluation-side visualization only. The video is never a model input.
The input video must contain one start frame plus one frame per simulator step.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import textwrap

from visualize_eef_trajectory import extract


WIDTH, HEIGHT = 1280, 720
VIDEO_WIDTH = 720
BG = (16, 26, 39)
PANEL = (25, 39, 56)
GRID = (67, 84, 102)
MUTED = (157, 176, 192)
ORANGE = (255, 177, 72)
CURRENT = (80, 233, 166)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def font(size: int):
    from PIL import ImageFont
    for name in ("DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                 "C:/Windows/Fonts/arial.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def projector(path: list[tuple[float, float]], rect: tuple[int, int, int, int]):
    x0, y0, width, height = rect
    xs, ys = zip(*path)
    lo_x, hi_x, lo_y, hi_y = min(xs), max(xs), min(ys), max(ys)
    center_x, center_y = (lo_x + hi_x) / 2, (lo_y + hi_y) / 2
    span_x = max((hi_x - lo_x) * 1.2, 0.18)
    span_y = max((hi_y - lo_y) * 1.2, 0.18)
    def project(x: float, y: float):
        return (round(x0 + width * (0.5 + (x - center_x) / span_x)),
                round(y0 + height * (0.5 - (y - center_y) / span_y)))
    return project, (center_x, center_y, span_x, span_y)


def draw_plot(draw, path, rect, current_step: int, title: str, x_label: str, y_label: str):
    x0, y0, width, height = rect
    draw.rounded_rectangle((x0 - 14, y0 - 45, x0 + width + 14, y0 + height + 27),
                           radius=12, fill=PANEL)
    draw.text((x0, y0 - 35), title, font=font(23), fill=(245, 250, 255))
    project, domain = projector(path, rect)
    cx, cy, sx, sy = domain
    for i in range(5):
        x = x0 + width * i / 4
        y = y0 + height * i / 4
        draw.line((x, y0, x, y0 + height), fill=GRID, width=1)
        draw.line((x0, y, x0 + width, y), fill=GRID, width=1)
    # Axes and changing numerical coordinates are part of the evaluation view.
    draw.text((x0, y0 + height + 5), f"{x_label}: {cx-sx/2:.2f} .. {cx+sx/2:.2f} m",
              font=font(14), fill=MUTED)
    draw.text((x0 + 230, y0 + height + 5), f"{y_label}: {cy-sy/2:.2f} .. {cy+sy/2:.2f} m",
              font=font(14), fill=MUTED)
    pixels = [project(*p) for p in path]
    if len(pixels) > 1:
        draw.line(pixels, fill=(82, 99, 112), width=2, joint="curve")
    if current_step > 0:
        draw.line(pixels[:current_step + 1], fill=ORANGE, width=5, joint="curve")
    sx0, sy0 = pixels[0]
    draw.ellipse((sx0 - 5, sy0 - 5, sx0 + 5, sy0 + 5), fill=(235, 245, 251))
    px, py = pixels[current_step]
    draw.ellipse((px - 10, py - 10, px + 10, py + 10), fill=CURRENT,
                 outline=(11, 37, 34), width=2)


def active_tool(commands: list[dict], step: int) -> dict | None:
    if step == 0:
        return None
    return next((row for row in commands if row["start"] < step <= row["end"]), None)


def draw_frame(video_frame, points: list[dict], commands: list[dict],
               step: int, title: str, kind: str, outcome: str):
    from PIL import Image, ImageDraw
    background = Image.new("RGB", (WIDTH, HEIGHT), BG)
    source = Image.fromarray(video_frame).convert("RGB")
    source = source.resize((VIDEO_WIDTH, HEIGHT), Image.Resampling.LANCZOS)
    background.paste(source, (0, 0))
    draw = ImageDraw.Draw(background)
    draw.rectangle((0, 0, VIDEO_WIDTH, 72), fill=(9, 19, 29))
    draw.text((20, 12), title, font=font(25), fill=(255, 255, 255))
    draw.text((20, 46), f"{kind} | evaluator camera, not an Astra input",
              font=font(17), fill=(190, 211, 227))
    draw.rectangle((VIDEO_WIDTH - 2, 0, VIDEO_WIDTH + 2, HEIGHT), fill=(223, 235, 242))
    draw.text((753, 17), "END-EFFECTOR TRAJECTORY", font=font(27), fill=(255, 255, 255))
    draw.text((754, 55), f"{outcome}    step {step}/{len(points)-1}",
              font=font(18), fill=CURRENT if outcome == "strict Pick success" else (255, 202, 120))
    tip_top = [(p["tx"], p["ty"]) for p in points]
    tip_side = [(p["tx"], p["tz"]) for p in points]
    draw_plot(draw, tip_top, (790, 145, 425, 145), step, "TCP top view", "x", "y")
    draw_plot(draw, tip_side, (790, 395, 425, 145), step, "TCP side view", "x", "z")
    p = points[step]
    draw.text((754, 593), f"TCP: x={p['tx']:.3f}  y={p['ty']:.3f}  z={p['tz']:.3f} m",
              font=font(18), fill=(245, 250, 255))
    call = active_tool(commands, step)
    tool = call["tool"] if call else "start"
    draw.text((754, 623), f"Tool: {tool}  |  grasped: {'yes' if p['grasped'] else 'no'}",
              font=font(17), fill=(245, 250, 255))
    note = (call or {}).get("note") or "No model note archived for this call."
    if len(note) > 90:
        note = note[:87] + "..."
    for index, line in enumerate(textwrap.wrap(note, width=58)[:2]):
        draw.text((754, 653 + 22 * index), line, font=font(15), fill=MUTED)
    draw.text((22, 685), "Faint path: full archived TCP trace   |   orange: executed so far   |   green: current TCP",
              font=font(15), fill=(245, 250, 255))
    return background


def run(args: argparse.Namespace) -> dict:
    import imageio.v2 as imageio
    import numpy as np
    if args.output.exists():
        raise FileExistsError(args.output)
    if args.expected_video_sha256 and sha256(args.video) != args.expected_video_sha256:
        raise ValueError("source video hash mismatch")
    if args.expected_result_sha256 and sha256(args.result) != args.expected_result_sha256:
        raise ValueError("source trajectory hash mismatch")
    result = json.loads(args.result.read_text(encoding="utf-8"))
    data = extract(result)
    points = data["points"]
    if len(points) != data["steps"] + 1:
        raise ValueError("trajectory lacks an initial or per-step point")
    title = f"Case {data['position']} | {data['mode']}"
    outcome = ("strict Pick success" if data["strict_pick_success"] else
               "censored" if data["status"] in ("api_censored", "infrastructure_censored")
               else "strict Pick failure")
    recording = args.output.with_name(args.output.stem + "-incomplete" + args.output.suffix)
    reader = imageio.get_reader(str(args.video))
    writer = imageio.get_writer(str(recording), fps=args.fps, codec="libx264", quality=8)
    count = 0
    try:
        meta = reader.get_meta_data()
        if abs(float(meta["fps"]) - args.fps) > 1e-3:
            raise ValueError("input video FPS differs from requested synchronized FPS")
        for index, frame in enumerate(reader):
            if index >= len(points):
                raise ValueError("video has more frames than trajectory points")
            if frame.ndim != 3 or not np.isfinite(frame).all():
                raise ValueError("invalid input video frame")
            canvas = draw_frame(frame, points, data["commands"], index,
                                title, args.kind, outcome)
            writer.append_data(np.asarray(canvas))
            count += 1
        if count != len(points):
            raise ValueError(f"video/trajectory mismatch: {count} vs {len(points)} frames")
    finally:
        writer.close()
        reader.close()
    recording.rename(args.output)
    receipt = {"kind": "eef_tcp_trajectory_synchronized_demo",
               "source_video": str(args.video), "source_video_sha256": sha256(args.video),
               "source_result": str(args.result), "source_result_sha256": sha256(args.result),
               "output": str(args.output), "output_sha256": sha256(args.output),
               "frames": count, "fps": args.fps, "resolution": [WIDTH, HEIGHT],
               "position": data["position"], "source_status": data["status"],
               "source_strict_pick_success": data["strict_pick_success"],
               "source_mode": data["mode"], "kind_label": args.kind,
               "api_requests_for_visualization": 0,
               "plot_frame": "attempt-start base_link from archived robot qpos and FK",
               "evaluation_only": True}
    args.receipt.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return receipt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("video", "result", "output", "receipt"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--expected-video-sha256")
    parser.add_argument("--expected-result-sha256")
    parser.add_argument("--fps", type=float, default=20.0)
    parser.add_argument("--kind", choices=("recorded-action replay", "online Astra attempt", "online interface check"), required=True)
    args = parser.parse_args()
    print(json.dumps(run(args), ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
