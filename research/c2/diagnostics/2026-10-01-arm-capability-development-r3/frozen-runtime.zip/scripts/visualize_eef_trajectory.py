"""Render an archived EEF tool-loop trajectory without simulation or model calls.

Outputs a shareable SVG and an interactive HTML viewer. Plot coordinates are
evaluation-side reconstructions from recorded qpos and FK, never model inputs.
"""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import math
from pathlib import Path


COLORS = {
    "move_base": "#147d89", "move_to": "#df8a19",
    "move_eef_chunk": "#df8a19", "set_gripper": "#9957ae",
    "check_path": "#648744", "return_to_rest": "#4467ae",
    "done": "#738091", "give_up": "#738091",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def scalar(value, default=0.0):
    if isinstance(value, list):
        value = value[0] if value else default
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def extract(result: dict) -> dict:
    frames = result.get("frames", [])
    if not frames:
        raise ValueError("result has no per-step frames")
    records = result.get("base_call_records_eval_only") or []
    initial = result.get('initial_robot_state', {}).get('qpos') or (records[0].get("entry", {}).get("qpos") if records else None) or frames[0]["qpos"]
    x0, y0, yaw0 = map(float, initial[:3])
    c0, s0 = math.cos(yaw0), math.sin(yaw0)
    points = [{"step": 0, "bx": 0.0, "by": 0.0, "yaw": 0.0,
               "tx": None, "ty": None, "tz": None, "gripper": None,
               "force": 0.0, "grasped": False}]
    for expected, frame in enumerate(frames, 1):
        if int(frame["step"]) != expected:
            raise ValueError(f"missing or out-of-order frame {expected}")
        x, y, yaw = map(float, frame["qpos"][:3])
        dx, dy = x - x0, y - y0
        bx, by = c0 * dx + s0 * dy, -s0 * dx + c0 * dy
        angle = math.atan2(math.sin(yaw - yaw0), math.cos(yaw - yaw0))
        tcp = frame["tcp_base"]
        txb, tyb, tz = (float(tcp[i][3]) for i in range(3))
        ca, sa = math.cos(angle), math.sin(angle)
        info = frame.get("official_info_eval_only") or {}
        points.append({"step": expected, "bx": bx, "by": by, "yaw": angle,
                       "tx": bx + ca * txb - sa * tyb,
                       "ty": by + sa * txb + ca * tyb, "tz": tz,
                       "gripper": float(frame.get("finger_distance_m", 0.0)),
                       "force": scalar(info.get("robot_cumulative_force")),
                       "grasped": bool(scalar(info.get("is_grasped")))})
    initial_state = result.get('initial_robot_state', {})
    if initial_state.get('tcp_base') is not None:
        for axis, key in enumerate(('tx','ty','tz')):
            points[0][key] = float(initial_state['tcp_base'][axis][3])
        points[0]['gripper'] = initial_state.get('finger_distance_m')
    if points[0]["tx"] is None:
        # The first available TCP pose is after step one. The base start is exact
        # when the archived base-call record includes its entry qpos.
        for key in ("tx", "ty", "tz", "gripper"):
            points[0][key] = points[1][key]
    commands = []
    cursor = 0
    for command in result.get("commands", []):
        call = command.get("call") or {}
        outcome = command.get("result") or {}
        count = int(outcome.get("steps_used") or 0)
        commands.append({"turn": command.get("turn"), "tool": call.get("tool") or "invalid",
                         "start": cursor, "end": min(cursor + count, len(frames)),
                         "steps": count, "note": call.get("note") or "",
                         "reason": outcome.get("reason") or ""})
        cursor += count
    if cursor > len(frames):
        raise ValueError("tool step counts exceed recorded frames")
    return {"position": result.get("position"), "mode": result.get("mode", "unknown"),
            "status": result.get("status", "unknown"),
            "strict_pick_success": bool(result.get("strict_pick_success")),
            "termination": result.get("termination_category") or "unknown",
            "steps": len(frames), "points": points, "commands": commands,
            "source_sha256": None,
            "force_limit": float(result.get("official_force_limit") or 5000),
            "frame_note": "XY is relative to the attempt-start base when its entry qpos is archived; otherwise relative to first recorded frame. TCP is transformed from each current base_link into that same frame. No scene mesh or object ground truth is plotted.",
            "initial_pose_source": "initial_robot_state" if result.get("initial_robot_state") else "base_call_entry" if records else "first_recorded_frame"}


def polyline(values: list[tuple[float, float]], project) -> str:
    return " ".join(f"{project(x, y)[0]:.1f},{project(x, y)[1]:.1f}" for x, y in values)


def make_svg(data: dict) -> tuple[str, dict]:
    points = data["points"]
    n = data["steps"]
    width, height = 1440, 1120
    base_xy = [(p["bx"], p["by"]) for p in points]
    tip_xy = [(p["tx"], p["ty"]) for p in points]
    tip_xz = [(p["tx"], p["tz"]) for p in points]
    elements = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" role="img" aria-label="Robot base and tool trajectory">',
                '<rect width="1440" height="1120" fill="#f7f9fc"/>']
    def add(value):
        elements.append(value)
    def text(x, y, value, size=18, color="#203047", anchor="start", weight="normal"):
        add(f'<text x="{x}" y="{y}" fill="{color}" font-family="Arial, sans-serif" font-size="{size}" font-weight="{weight}" text-anchor="{anchor}">{html.escape(str(value))}</text>')
    def line(x1, y1, x2, y2, color="#d7dfe9", stroke=1, dash=""):
        add(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{color}" stroke-width="{stroke}"' + (f' stroke-dasharray="{dash}"' if dash else "") + '/>')
    def panel(x, y, w, h):
        add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="14" fill="white" stroke="#dce4ed"/>')
    def scale(values, rect, equal=False):
        x, y, w, h = rect
        xs, ys = zip(*values)
        lo_x, hi_x = min(xs), max(xs)
        lo_y, hi_y = min(ys), max(ys)
        cx, cy = (lo_x + hi_x) / 2, (lo_y + hi_y) / 2
        span_x = max(hi_x - lo_x, 0.25)
        span_y = max(hi_y - lo_y, 0.25)
        if equal:
            units = max(span_x / w, span_y / h) * 1.18
            span_x, span_y = w * units, h * units
        else:
            span_x *= 1.18
            span_y *= 1.18
        def project(px, py):
            return (x + w * (0.5 + (px - cx) / span_x),
                    y + h * (0.5 - (py - cy) / span_y))
        return project, (cx, cy, span_x, span_y)

    censored = data["status"] in ("api_censored", "infrastructure_censored", "censored")
    verdict = ("STRICT PICK SUCCESS" if data["strict_pick_success"] else
               "CENSORED — PICK NOT SCORED" if censored else "STRICT PICK FAILURE")
    verdict_color = ("#147f60" if data["strict_pick_success"] else
                     "#a76b20" if censored else "#b64b45")
    text(48, 48, f'Case {data["position"]} | {data["mode"]}', 26, weight="bold")
    net_base = math.hypot(points[-1]["bx"], points[-1]["by"])
    text(48, 83, f'{verdict}   •   {n} recorded steps   •   {len(data["commands"])} tool calls   •   base net {net_base:.3f} m   •   termination: {data["termination"]}', 18, color=verdict_color, weight="bold")
    text(48, 111, "Evaluation-side trajectory; no scene geometry or third-person image entered the model request.", 15, color="#59697c")

    panel(40, 135, 660, 480)
    panel(740, 135, 660, 480)
    text(66, 172, "Top view: base + tool tip (x/y meters)", 21, weight="bold")
    text(766, 172, "Side view: tool tip (x/z meters)", 21, weight="bold")
    map_xy, xy_domain = scale(base_xy + tip_xy + [(0.0, 0.0)], (92, 210, 560, 356), True)
    map_xz, xz_domain = scale(tip_xz, (790, 210, 560, 356), True)
    def nice_step(span):
        target = max(span / 5, 1e-6)
        decade = 10 ** math.floor(math.log10(target))
        return next(multiplier * decade for multiplier in (1, 2, 5, 10) if multiplier * decade >= target)
    def grid(project, domain, rect):
        cx, cy, sx, sy = domain
        rx, ry, rw, rh = rect
        step = nice_step(max(sx, sy))
        x = math.ceil((cx - sx / 2) / step) * step
        while x <= cx + sx / 2 + 1e-9:
            px, _ = project(x, cy)
            line(px, ry, px, ry + rh, "#e8edf2", 1)
            text(px, ry + rh + 17, f"{x:.2f}", 12, "#718197", anchor="middle")
            x += step
        y = math.ceil((cy - sy / 2) / step) * step
        while y <= cy + sy / 2 + 1e-9:
            _, py = project(cx, y)
            line(rx, py, rx + rw, py, "#e8edf2", 1)
            text(rx - 8, py + 4, f"{y:.2f}", 12, "#718197", anchor="end")
            y += step
    grid(map_xy, xy_domain, (92, 210, 560, 356))
    grid(map_xz, xz_domain, (790, 210, 560, 356))
    ox, oy = map_xy(0, 0)
    line(ox, 210, ox, 566, dash="5 5")
    line(92, oy, 652, oy, dash="5 5")
    text(ox + 6, 222, "start base", 13, color="#64788f")
    add(f'<polyline points="{polyline(base_xy, map_xy)}" fill="none" stroke="#147d89" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>')
    add(f'<polyline points="{polyline(tip_xy, map_xy)}" fill="none" stroke="#df8a19" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>')
    add(f'<polyline points="{polyline(tip_xz, map_xz)}" fill="none" stroke="#df8a19" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>')
    for name, coords, project, color in (("base", base_xy, map_xy, "#147d89"),
                                          ("tip", tip_xy, map_xy, "#df8a19"),
                                          ("tip-side", tip_xz, map_xz, "#df8a19")):
        sx, sy = project(*coords[0]); ex, ey = project(*coords[-1])
        add(f'<circle cx="{sx:.1f}" cy="{sy:.1f}" r="7" fill="white" stroke="{color}" stroke-width="3"/>')
        add(f'<circle cx="{ex:.1f}" cy="{ey:.1f}" r="7" fill="{color}"/>')
    for p in points[1:]:
        if p["grasped"] and not points[p["step"] - 1]["grasped"]:
            for coords, project in (((p["tx"], p["ty"]), map_xy), ((p["tx"], p["tz"]), map_xz)):
                cx, cy = project(*coords)
                add(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="9" fill="#147f60" stroke="white" stroke-width="2"/>')
    text(95, 593, "teal: base   orange: TCP tip   green: first grasp   ○ start   ● end", 15, color="#526278")
    text(790, 593, "horizontal x / vertical z in start-base coordinates (meters)", 15, color="#526278")

    panel(40, 640, 1360, 160)
    text(64, 675, "Tool calls on the official step clock", 21, weight="bold")
    timeline = (70, 704, 1300, 62)
    for cmd in data["commands"]:
        color = COLORS.get(cmd["tool"], "#8d99a6")
        x = timeline[0] + timeline[2] * cmd["start"] / n
        w = timeline[2] * max(cmd["end"] - cmd["start"], 0) / n
        if w > 0:
            add(f'<rect x="{x:.1f}" y="{timeline[1]}" width="{w:.1f}" height="42" fill="{color}" stroke="white"/>')
            label = cmd["tool"] if w > 105 else (str(cmd["turn"]) if w > 23 else "")
            if label:
                text(x + w / 2, timeline[1] + 27, label, 13, color="white", anchor="middle", weight="bold")
        else:
            line(x, timeline[1], x, timeline[1] + 42, color, 3)
    for step in (0, n // 4, n // 2, 3 * n // 4, n):
        x = timeline[0] + timeline[2] * step / n
        text(x, 783, str(step), 13, anchor="middle", color="#5c6b7d")

    panel(40, 825, 660, 245)
    panel(740, 825, 660, 245)
    text(65, 861, "Finger opening (meters)", 20, weight="bold")
    text(765, 861, "Official cumulative force", 20, weight="bold")
    grip = [float(p["gripper"] or 0.0) for p in points]
    force = [float(p["force"]) for p in points]
    grip_max = max(max(grip) * 1.1, 0.08)
    force_max = max(max(force) * 1.06, data["force_limit"] * 1.1, 1)
    def series(values, x, y, w, h, maximum):
        return " ".join(f'{x + w * i / n:.1f},{y + h * (1 - max(0, value) / maximum):.1f}'
                        for i, value in enumerate(values))
    add(f'<polyline points="{series(grip, 65, 900, 610, 125, grip_max)}" fill="none" stroke="#9957ae" stroke-width="3"/>')
    add(f'<polyline points="{series(force, 765, 900, 610, 125, force_max)}" fill="none" stroke="#b64b45" stroke-width="3"/>')
    force_y = 900 + 125 * (1 - data["force_limit"] / force_max)
    line(765, force_y, 1375, force_y, "#b64b45", 1, "5 5")
    text(1375, force_y - 5, f'limit {data["force_limit"]:.0f}', 13, "#b64b45", anchor="end")
    text(65, 1051, "Green dots mark the first official is_grasped=true transition in the path panels.", 14, color="#617185")
    for name, coords, project in (("base", base_xy, map_xy), ("tip", tip_xy, map_xy), ("side", tip_xz, map_xz)):
        add(f'<circle id="cursor-{name}" cx="{project(*coords[-1])[0]:.1f}" cy="{project(*coords[-1])[1]:.1f}" r="11" fill="none" stroke="#111827" stroke-width="2"/>')
    add(f'<line id="cursor-time" x1="{timeline[0] + timeline[2]}" y1="704" x2="{timeline[0] + timeline[2]}" y2="1025" stroke="#111827" stroke-width="2" opacity="0.6"/>')
    text(40, 1102, data["frame_note"], 13, color="#617185")
    add('</svg>')
    screen = {"base": [map_xy(*v) for v in base_xy],
              "tip": [map_xy(*v) for v in tip_xy],
              "side": [map_xz(*v) for v in tip_xz],
              "timeline": [timeline[0], timeline[2]], "step_count": n}
    return "\n".join(elements) + "\n", screen


def make_html(svg: str, screen: dict, data: dict, video: str | None) -> str:
    payload = json.dumps({"screen": screen, "points": data["points"],
                          "commands": data["commands"]}, ensure_ascii=False,
                         separators=(",", ":")).replace("</", "<\\/")
    video_block = (f'<video id="demo" controls preload="metadata" src="{html.escape(video, quote=True)}"></video>'
                   if video else '<p class="notice">No video was archived for this case; the trajectory remains viewable step by step.</p>')
    return f'''<!doctype html>
<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EEF trajectory case {html.escape(str(data["position"]))}</title>
<style>body{{font:16px/1.5 system-ui,sans-serif;background:#eef3f8;color:#203047;margin:0;padding:24px}}
main{{max-width:1440px;margin:auto;background:white;padding:22px;border-radius:16px;box-shadow:0 8px 30px #2233}}
svg{{width:100%;height:auto}}video{{width:min(100%,900px);display:block;margin:12px auto 18px;border-radius:8px}}
.controls{{display:flex;align-items:center;gap:14px;margin:12px 0}}input[type=range]{{flex:1}}.notice{{background:#fff4db;padding:12px}}
.readout{{font-size:17px;background:#f2f6fa;padding:12px;border-radius:8px;min-height:44px}}
.small{{color:#617185;font-size:14px}}</style><main>
<h1>Trajectory viewer — case {html.escape(str(data["position"]))}</h1>
<p class="small">{html.escape(data["mode"])} · {html.escape(data["status"])} · {html.escape(data["termination"])} · Source SHA-256 {data["source_sha256"]}</p>
{video_block}
<div class="controls"><label for="step">Step</label><input id="step" type="range" min="0" max="{data["steps"]}" value="{data["steps"]}"><strong id="stepLabel">{data["steps"]}/{data["steps"]}</strong></div>
<div class="readout" id="readout"></div>{svg}
<p class="small">The display is an evaluation artifact. Base XY and TCP are reconstructed from recorded robot qpos and FK; the video is evaluation-only. Notes are model self-reports and are shown only when archived.</p>
</main><script>const D={payload};const slider=document.getElementById('step');const label=document.getElementById('stepLabel');
const video=document.getElementById('demo');const readout=document.getElementById('readout');
function setStep(value,fromVideo=false){{let s=Math.max(0,Math.min(D.screen.step_count,Math.round(value)));slider.value=s;label.textContent=s+'/'+D.screen.step_count;
for(const key of ['base','tip','side']){{const node=document.getElementById('cursor-'+key);const xy=D.screen[key][s];node.setAttribute('cx',xy[0]);node.setAttribute('cy',xy[1]);}}
const x=D.screen.timeline[0]+D.screen.timeline[1]*s/D.screen.step_count;const marker=document.getElementById('cursor-time');marker.setAttribute('x1',x);marker.setAttribute('x2',x);
const p=D.points[s];const c=D.commands.find(q=>s>q.start&&s<=q.end)||D.commands.find(q=>s===q.start)||null;
readout.textContent=`Step ${{s}} · base (${{p.bx.toFixed(3)}}, ${{p.by.toFixed(3)}}) m · tip (${{p.tx.toFixed(3)}}, ${{p.ty.toFixed(3)}}, ${{p.tz.toFixed(3)}}) m · gripper ${{p.gripper.toFixed(3)}} m · cumulative force ${{p.force.toFixed(1)}} · tool ${{c?c.tool:'start'}}${{c&&c.note?' · note: '+c.note:''}}`;
if(video&&!fromVideo&&Number.isFinite(video.duration))video.currentTime=Math.min(video.duration,s/20);}}
slider.addEventListener('input',()=>setStep(+slider.value));if(video)video.addEventListener('timeupdate',()=>setStep(video.currentTime*20,true));setStep(+slider.value);
</script></html>'''


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True, help="New directory for SVG and HTML")
    parser.add_argument("--video-relative", type=str, default=None,
                        help="Video path relative to the HTML output directory, if present")
    parser.add_argument("--replace", action="store_true",
                        help="Regenerate only an existing output with the same source SHA-256")
    args = parser.parse_args()
    source_hash = sha256(args.result)
    if args.output.exists():
        manifest_path = args.output / "trajectory-manifest.json"
        if not args.replace or not manifest_path.is_file():
            raise FileExistsError(args.output)
        existing = json.loads(manifest_path.read_text(encoding="utf-8"))
        if existing.get("source_sha256") != source_hash:
            raise ValueError("cannot replace visualization for a different source trajectory")
    if args.video_relative and not (args.output / args.video_relative).resolve().is_file():
        raise FileNotFoundError(args.video_relative)
    result = json.loads(args.result.read_text(encoding="utf-8"))
    data = extract(result)
    data["source_sha256"] = source_hash
    svg, screen = make_svg(data)
    page = make_html(svg, screen, data, args.video_relative)
    args.output.mkdir(parents=True, exist_ok=args.replace)
    (args.output / "trajectory.svg").write_text(svg, encoding="utf-8")
    (args.output / "trajectory.html").write_text(page, encoding="utf-8")
    (args.output / "trajectory-manifest.json").write_text(
        json.dumps({"position": data["position"], "mode": data["mode"],
                    "status": data["status"], "strict_pick_success": data["strict_pick_success"],
                    "steps": data["steps"], "commands": len(data["commands"]),
                    "source_sha256": data["source_sha256"],
                    "initial_pose_source": data["initial_pose_source"],
                    "video_relative": args.video_relative,
                    "svg_sha256": sha256(args.output / "trajectory.svg"),
                    "html_sha256": sha256(args.output / "trajectory.html")},
                   indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "steps": data["steps"],
                      "strict_pick_success": data["strict_pick_success"]}))


if __name__ == "__main__":
    main()
