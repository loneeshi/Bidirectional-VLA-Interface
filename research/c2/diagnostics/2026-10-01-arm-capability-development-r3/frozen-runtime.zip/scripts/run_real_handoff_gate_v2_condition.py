"""One V2 development Pick gate condition from a real PPO handoff snapshot.

The caller enforces cumulative process time. This runner enforces its own 300 s
limit and never calls a provider or advances the navigation policy.
"""
from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import math
import os
from pathlib import Path
import subprocess
import time

from run_real_handoff_pick_case import (GPU1, MSHAB_COMMIT, SEQUENTIAL_SHA256,
                                        digest, tensor_digest)

EXPERIMENT = "real-handoff-pick-gate-v2-development"
CONDITIONS = ("control_replay", "forward_10")
DEV_MANIFEST_SHA256 = "617a6390764cdf662f7c398ff5cd8e509a6c5cbefe11364f9ff6fbe138a2da17"
SNAPSHOT_BINDING_SHA256 = "142503ddbcb1fe60b566e42aa6402fbc84db169d40b68485c2613e5e65cc9e5a"
XY_TOLERANCE_M = .02
YAW_TOLERANCE_RAD = .03
MOTION_STEPS_LIMIT = 80
LINEAR_LIMIT = .25
ANGULAR_LIMIT = .6


def wrap(angle):
    return math.atan2(math.sin(angle), math.cos(angle))


def rebase_init_config_index(snapshot, current_index):
    """Translate a process-local selector without touching physical snapshot data."""
    original = int(snapshot["simulator"]["init_config_idxs"][0])
    snapshot["simulator"]["init_config_idxs"] = [int(current_index)]
    for values in snapshot["attributes"].values():
        if "init_config_idxs" in values:
            values["init_config_idxs"] = [int(current_index)]
    return original


def cpu_rng_states_after_deserialization(snapshot):
    """torch.load(map_location=GPU) also maps RNG ByteTensors; reset APIs need CPU."""
    import torch

    def cpu_nested(value):
        if torch.is_tensor(value):
            return value.cpu()
        if isinstance(value, tuple):
            return tuple(cpu_nested(row) for row in value)
        if isinstance(value, list):
            return [cpu_nested(row) for row in value]
        if isinstance(value, dict):
            return {key: cpu_nested(row) for key, row in value.items()}
        return value

    snapshot["torch_rng"] = cpu_nested(snapshot["torch_rng"])
    snapshot["cuda_rng"] = cpu_nested(snapshot["cuda_rng"])
    for name, states in snapshot["batched_rng_states"].items():
        snapshot["batched_rng_states"][name] = cpu_nested(states)


def check_authorization(args):
    auth = json.loads(args.authorization.read_text(encoding="utf-8"))
    if (auth.get("experiment_id") != EXPERIMENT or auth.get("status") != "user_approved" or
        not auth.get("user_approval_evidence") or auth.get("gpu_uuid") != GPU1 or
        auth.get("single_process_seconds_max") != 300 or
        auth.get("lab_gpu1_process_seconds_max") != 6000 or
        auth.get("provider_requests_max") != 60 or
        auth.get("lab_project_charge_max") != 0 or
        auth.get("dev_manifest_sha256") != DEV_MANIFEST_SHA256 or
        auth.get("snapshot_binding_sha256") != SNAPSHOT_BINDING_SHA256 or
        args.condition not in CONDITIONS or args.repeat_index != 0):
        raise ValueError("This run is outside an approved V2 development scope")
    if digest(args.manifest) != DEV_MANIFEST_SHA256:
        raise ValueError("Frozen development manifest changed")
    if digest(args.binding) != SNAPSHOT_BINDING_SHA256:
        raise ValueError("Frozen snapshot semantic binding changed")
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    binding_rows = json.loads(args.binding.read_text(encoding="utf-8"))["rows"]
    if len(manifest.get("requests", [])) != 60:
        raise ValueError("Incomplete development manifest")
    binding = next((row for row in manifest["requests"] if row["position"] == args.position), None)
    if binding is None:
        raise ValueError("Position missing from frozen development roster")
    if os.environ.get("CUDA_VISIBLE_DEVICES") != GPU1:
        raise ValueError("CUDA_VISIBLE_DEVICES must pin GPU1 UUID")
    if digest(args.roster) != auth["roster_sha256"]:
        raise ValueError("Frozen roster hash mismatch")
    if digest(args.checkpoint_hashes) != auth["checkpoint_hashes_sha256"]:
        raise ValueError("Checkpoint list hash mismatch")
    if digest(args.episode_configs) != auth["episode_configs_sha256"]:
        raise ValueError("Episode-config list hash mismatch")
    census = json.loads(args.census_result.read_text(encoding="utf-8"))
    semantic = next((row for row in binding_rows if row["position"] == args.position), None)
    canonical = hashlib.sha256(json.dumps(census, sort_keys=True, separators=(",", ":"),
                                          ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()
    if (semantic is None or semantic["local_result_sha256"] != binding["source_result_sha256"] or
        canonical != semantic["canonical_result_sha256"]):
        raise ValueError("Census result semantic hash mismatch")
    snapshot_sha = census["handoff"]["snapshot_sha256"]
    if (digest(args.snapshot) != snapshot_sha or snapshot_sha != semantic["snapshot_sha256"] or
        census["row"]["plan_uid"] != binding["plan_uid"]):
        raise ValueError("Handoff snapshot or UID mismatch")
    return auth, snapshot_sha


def destination(origin, kind, amount):
    x, y, yaw = origin
    if kind == "turn":
        return (x, y, wrap(yaw + amount))
    return (x + amount * math.cos(yaw), y + amount * math.sin(yaw), yaw)


def motion_control(origin, end, kind, amount, pose):
    xy_error = math.hypot(end[0] - pose[0], end[1] - pose[1])
    yaw_error = wrap(end[2] - pose[2])
    arrived = xy_error < XY_TOLERANCE_M and abs(yaw_error) < YAW_TOLERANCE_RAD
    if kind == "turn":
        return 0., max(-ANGULAR_LIMIT, min(ANGULAR_LIMIT, 2 * yaw_error)), arrived
    heading_error = wrap(origin[2] - pose[2])
    progress = ((pose[0] - origin[0]) * math.cos(origin[2]) +
                (pose[1] - origin[1]) * math.sin(origin[2]))
    remaining = amount - progress
    linear = max(-LINEAR_LIMIT, min(LINEAR_LIMIT, 2 * remaining))
    angular = max(-ANGULAR_LIMIT, min(ANGULAR_LIMIT, 2 * heading_error))
    return linear, angular, arrived


def sample(ports, meter, phase):
    from bvi.mshab_adapter import jsonable, scalar
    u = ports.adapter.uenv
    row = ports.current()
    base = jsonable(u.agent.base_link.pose.raw_pose)[0]
    w, x, y, z = base[3:]
    yaw = math.atan2(2 * (w*z+x*y), 1 - 2 * (y*y+z*z))
    contacts = meter.read()
    return {"phase": phase, "pick_step": row.pick_step,
            "base_pose_xy_yaw": [float(base[0]), float(base[1]), yaw],
            "tcp_target_distance_m": row.tcp_target_distance_m,
            "is_grasped": row.grasped,
            "robot_cumulative_force_n": row.robot_cumulative_force,
            "force_limit_n": row.force_limit, "steps_left": row.steps_left,
            "official_success": row.official_success,
            "official_fail": row.official_fail,
            "official_robot_force_n": float(scalar(ports.adapter.last_info["robot_force"])),
            "target_contact_force_n": contacts["target_contact_force_n"],
            "robot_total_contact_impulse_ns": contacts["robot_total_contact_impulse_ns"],
            "non_target_contacts": contacts["non_target_contacts"],
            "contact_measurement_scope": contacts["measurement_scope"]}


def is_terminal(row):
    return row.official_success or row.official_fail or row.steps_left <= 0 or row.robot_cumulative_force >= row.force_limit


def run(args, auth, snapshot_sha):
    import torch
    from mani_skill import ASSET_DIR
    from mani_skill.envs.sapien_env import BaseEnv
    from mshab.envs.make import EnvConfig
    import mshab.envs.sequential_task as sequential
    import bvi.nav_camera_env
    from bvi.census_contact import CensusContactMeter
    from bvi.logging import JsonlLogger
    from bvi.mshab_adapter import OfficialRLSkill, jsonable, make_mshab_adapter, scalar
    from bvi.near_pick_route import NearPickFloorRoute
    from bvi.seed8_feedback_ports import FeedbackPickPorts
    from bvi.protocol import Requirement, SkillRequest
    from check_c2_snapshot_restore import max_error, restore

    started = time.monotonic()
    deadline = started + 295
    args.output.mkdir(parents=True, exist_ok=False)
    report = {"schema": "bvi.real-handoff-gate-v2-condition/1",
              "experiment_id": EXPERIMENT, "position": args.position,
              "condition": args.condition, "repeat_index": args.repeat_index,
              "status": "started", "api_requests": 0,
              "training_updates": 0, "snapshot_sha256": snapshot_sha,
              "authorization_sha256": digest(args.authorization), "steps": []}
    logger = JsonlLogger(args.output / "events.jsonl", args.output.name)
    adapter = None
    try:
        if digest(sequential.__file__) != SEQUENTIAL_SHA256:
            raise ValueError("Official sequential_task hash changed")
        commit = subprocess.check_output(["git", "-C", str(Path(sequential.__file__).resolve().parents[2]),
                                          "rev-parse", "HEAD"], text=True).strip()
        if commit != MSHAB_COMMIT:
            raise ValueError("MS-HAB commit changed")
        roster = json.loads(args.roster.read_text(encoding="utf-8"))
        row = roster["plans"][args.position]
        census = json.loads(args.census_result.read_text(encoding="utf-8"))
        if census["status"] != "completed" or census["row"] != row:
            raise ValueError("Census handoff identity changed")
        known = {}
        for line in args.checkpoint_hashes.read_text(encoding="utf-8").splitlines():
            value, relative = line.split(maxsplit=1)
            known[relative] = value
        category = row["first_pick_obj_id"].split("-")[0]
        selected = [f"pick/{category}/{name}" for name in ("config.yml", "policy.pt")]
        for relative in selected:
            if digest(args.checkpoint_root / "rl/tidy_house" / relative) != known[relative]:
                raise ValueError("SAC checkpoint/config hash changed: " + relative)
        plan_path = ASSET_DIR / "scene_datasets/replica_cad_dataset/rearrange/task_plans/tidy_house/sequential/val/all.json"
        if digest(plan_path) != roster["source_task_plans_sha256"]:
            raise ValueError("Official task plan asset changed")
        episodes = json.loads(args.episode_configs.read_text(encoding="utf-8"))
        episode = episodes["rows"][args.position]
        ep_path = ASSET_DIR / "scene_datasets/replica_cad_dataset/rearrange" / row["init_config_name"]
        if digest(ep_path) != episode["episode_config_sha256"]:
            raise ValueError("Official episode asset changed")
        kwargs = {"require_build_configs_repeated_equally_across_envs": False,
                  "add_event_tracker_info": True,
                  "human_render_camera_configs": {"width": 512, "height": 512},
                  "task_cfgs": {"navigate": {"ignore_arm_checkers": True}}}
        if "invisible_goals_in_human_render" in inspect.signature(BaseEnv.__init__).parameters:
            kwargs["invisible_goals_in_human_render"] = True
        cfg = EnvConfig(env_id="BVISequentialWorkspaceCamera-v0", num_envs=1,
                        max_episode_steps=7000, task_plan_fp=str(plan_path), obs_mode="rgbd",
                        render_mode="rgb_array", record_video=False, info_on_video=False,
                        continuous_task=True, frame_stack=3, stationary_base=False,
                        stationary_torso=False, stationary_head=True, env_kwargs=kwargs)
        adapter = make_mshab_adapter(cfg, logger, args.output, seed=row["asset_plan_index"])
        bci = adapter.uenv.scene_builder.build_config_names_to_idxs[row["build_config_name"]]
        tpi = row["task_plan_index_within_build_config"]
        adapter.reset(row["asset_plan_index"], options={"reconfigure": True, "build_config_idxs": [bci],
                      "task_plan_idxs": torch.tensor([tpi], device=adapter.uenv.device)})
        if adapter.original_plan.subtasks[0].uid != row["plan_uid"]:
            raise ValueError("Reset plan UID changed")
        snapshot = torch.load(args.snapshot, map_location=adapter.uenv.device, weights_only=False)
        cpu_rng_states_after_deserialization(snapshot)
        current_init_index = int(adapter.uenv.init_config_idxs[0])
        if (snapshot["simulator"]["build_config_idxs"] != [bci] or
            int(snapshot["simulator"]["task_plan_idxs"][0]) != tpi or
            adapter.original_plan.init_config_name != row["init_config_name"]):
            raise ValueError("Snapshot plan or episode identity differs")
        # SceneBuilder assigns init-config indices from an order that can vary
        # across processes. The frozen plan names the same episode asset, but
        # set_state_dict asserts numeric index equality. Translate only this
        # process-local selector, preserving every physical tensor and clock.
        original_init_index = rebase_init_config_index(snapshot, current_init_index)
        restore(adapter, snapshot, mode="public")
        state_error = max_error(snapshot["simulator"], adapter.uenv.get_state_dict())
        normalized_state = jsonable(adapter.uenv.get_state_dict())
        normalized_state["init_config_idxs"] = [original_init_index]
        state_sha = hashlib.sha256(json.dumps(normalized_state,
                                            sort_keys=True, separators=(",", ":"),
                                            allow_nan=False).encode()).hexdigest()
        input_sha = tensor_digest(adapter.observe().policy)
        report["restore"] = {"state_max_error": state_error,
                             "normalized_state_sha256": state_sha,
                             "original_census_state_sha256": census["handoff"]["state_sha256"],
                             "pick_input_sha256": input_sha,
                             "init_config_index_at_capture": original_init_index,
                             "init_config_index_in_current_process": current_init_index,
                             "index_translation_scope": "process_local_episode_selector_only"}
        if (state_error > 1e-5 or input_sha != census["handoff"]["pick_input_sha256"] or
            int(scalar(adapter.uenv.subtask_pointer)) != 1 or
            list(adapter.observe().policy["state"].shape) != [1, 42]):
            raise ValueError("Restored handoff identity/official SAC input changed")
        route = NearPickFloorRoute(adapter, ASSET_DIR)
        ports = FeedbackPickPorts(adapter, None, lambda *_: None, route,
                                  target_index=1, target_id=row["first_pick_obj_id"],
                                  deadline_monotonic=deadline)
        meter = CensusContactMeter(adapter.uenv, adapter.uenv.subtask_objs[1]._objs[0])
        meter.read()
        start = ports.control.pose()
        report["start_control_pose"] = start
        if args.condition == "forward_10":
            kind, amount = "move", .10
            end = destination(start, kind, amount)
            validator = route.validate_turn if kind == "turn" else route
            path = validator(start, end, adapter)
            report["requested_control_pose"] = end
            route_accepted = path is not None and bool(path) and tuple(path[-1]) == end
            if not route_accepted:
                diagnose = route.diagnose_turn if kind == "turn" else route.diagnose
                report["route_rejection"] = diagnose(start, end, adapter)
                report["route_rejected"] = True
                report["motion_actions"] = 0
                report["arrived"] = None
                report["status"] = "route_rejected_reuse_G0"
                return report
            else:
                report["route_rejected"] = False
                ports.control.capture_hold()
                settled = 0
                for _ in range(MOTION_STEPS_LIMIT):
                    if time.monotonic() >= deadline:
                        raise TimeoutError("Single-process limit during movement")
                    prior = ports.current()
                    if is_terminal(prior):
                        break
                    live = validator(ports.control.pose(), end, adapter)
                    if live is None:
                        report["movement_stop"] = "route_no_longer_valid"
                        break
                    linear, angular, reached = motion_control(start, end, kind, amount,
                                                                ports.control.pose())
                    settled = settled + 1 if reached else 0
                    nxt = ports._step(ports.control.action(0., 0.) if reached else
                                      ports.control.action(linear, angular))
                    report["steps"].append(sample(ports, meter, "motion"))
                    if nxt.pick_step != prior.pick_step + 1 or (not nxt.official_success and
                        (nxt.steps_left != prior.steps_left - 1 or
                         nxt.robot_cumulative_force + 1e-5 < prior.robot_cumulative_force)):
                        raise RuntimeError("Official Pick clock/force continuity failed")
                    if is_terminal(nxt):
                        report["movement_stop"] = "official_terminal_during_move"
                        break
                    if settled >= 3:
                        report["movement_stop"] = "measured_arrival"
                        break
                actual = ports.control.pose()
                report["actual_control_pose"] = actual
                report["xy_error_m"] = math.hypot(end[0]-actual[0], end[1]-actual[1])
                report["yaw_error_rad"] = abs(wrap(end[2]-actual[2]))
                report["motion_actions"] = len(report["steps"])
                report["arrived"] = (report.get("movement_stop") == "measured_arrival" and
                                     report["xy_error_m"] < XY_TOLERANCE_M and
                                     report["yaw_error_rad"] < YAW_TOLERANCE_RAD)
        else:
            report["motion_actions"] = 0
            report["arrived"] = None
        sac_actions = 0
        if not is_terminal(ports.current()):
            observation = adapter.observe()
            allowed = observation.allowed_calls
            if len(allowed) != 1 or allowed[0].skill != "pick":
                raise ValueError("Official Pick call not available after movement")
            request = SkillRequest("gate-v2-frozen-sac", "pick", allowed[0].target_id,
                                   observation.frame_id,
                                   (Requirement("completion", "benchmark_success"),),
                                   int(scalar(adapter.uenv.task_cfgs["pick"].horizon)),
                                   300)
            skill = OfficialRLSkill("pick", adapter, args.checkpoint_root, "rl_per_obj")
            skill.start(request, observation)
            while not is_terminal(ports.current()):
                if time.monotonic() >= deadline:
                    raise TimeoutError("Single-process limit during SAC")
                prior = ports.current()
                action = skill.act(observation)
                nxt = ports._step(action)
                observation = ports._last_transition.observation
                feedback = skill.feedback(request, ports._last_transition)
                sac_actions += 1
                report["steps"].append(sample(ports, meter, "sac"))
                if nxt.pick_step != prior.pick_step + 1 or (not nxt.official_success and
                    (nxt.steps_left != prior.steps_left - 1 or
                     nxt.robot_cumulative_force + 1e-5 < prior.robot_cumulative_force)):
                    raise RuntimeError("Official Pick clock/force continuity failed")
                if feedback.status.value != "executing" and not is_terminal(nxt):
                    raise RuntimeError("Official SAC feedback stopped before native terminal")
        final = ports.current()
        report["sac_actions"] = sac_actions
        report["strict_pick_success"] = bool(final.official_success and not final.official_fail and
                                              final.robot_cumulative_force < final.force_limit)
        report["official_final_info"] = jsonable(adapter.last_info)
        report["status"] = "official_complete"
    except Exception as exc:
        report["status"] = "infrastructure_censored"
        report["error_type"] = type(exc).__name__
        report["error_message"] = str(exc)[:500]
    finally:
        report["wall_seconds"] = time.monotonic() - started
        (args.output / "result.json").write_text(json.dumps(report, indent=2, ensure_ascii=False),
                                                  encoding="utf-8")
        if adapter is not None:
            adapter.close()
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--authorization", type=Path, required=True)
    p.add_argument("--manifest", type=Path, required=True)
    p.add_argument("--binding", type=Path, required=True)
    p.add_argument("--repeat-index", type=int, default=0)
    p.add_argument("--position", type=int, required=True)
    p.add_argument("--condition", required=True)
    p.add_argument("--roster", type=Path, required=True)
    p.add_argument("--episode-configs", type=Path, required=True)
    p.add_argument("--checkpoint-hashes", type=Path, required=True)
    p.add_argument("--checkpoint-root", type=Path, required=True)
    p.add_argument("--census-result", type=Path, required=True)
    p.add_argument("--snapshot", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--execute", action="store_true")
    args = p.parse_args()
    binding = check_authorization(args) if args.execute else None
    if args.execute:
        auth, snapshot_sha = binding
        print(json.dumps({k: v for k, v in run(args, auth, snapshot_sha).items() if k != "steps"}))
    else:
        print(json.dumps({"status": "dry_run", "position": args.position,
                          "condition": args.condition, "valid_conditions": CONDITIONS}))


if __name__ == "__main__":
    main()
