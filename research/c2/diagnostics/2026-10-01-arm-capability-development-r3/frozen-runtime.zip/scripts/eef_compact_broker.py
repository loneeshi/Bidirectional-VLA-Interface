"""Durable local visual request broker. No provider credentials on the robot host."""
import hashlib
import ssl
import re
from urllib.error import URLError
import json
from pathlib import Path
from datetime import datetime, timezone
from bvi.eef_compact_api import build_request, parse_response, BudgetLimitError


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)


def transport_error_details(exc):
    """Credential-free diagnostics: class and OS/HTTP codes, never request headers."""
    details = {'exception_type': type(exc).__name__}
    for field in ('errno', 'winerror', 'code'):
        value = getattr(exc, field, None)
        if isinstance(value, int): details[field] = value
    tls = exc.reason if isinstance(exc, URLError) else exc
    if isinstance(tls, ssl.SSLError):
        for field in ('library', 'reason'):
            value = getattr(tls, field, None)
            if isinstance(value, str) and re.fullmatch(r'[A-Z0-9_]+', value):
                details['ssl_'+field] = value
        details['certificate_verification_error'] = isinstance(tls, ssl.SSLCertVerificationError)
    reason = getattr(exc, 'reason', None)
    if reason is not None:
        details['reason_type'] = type(reason).__name__
        for field in ('errno', 'winerror'):
            value = getattr(reason, field, None)
            if isinstance(value, int): details['reason_'+field] = value
        if isinstance(reason, TimeoutError): details['category'] = 'timeout'
        elif type(reason).__name__ == 'gaierror': details['category'] = 'dns'
        elif type(reason).__module__ == 'ssl': details['category'] = 'tls'
        elif isinstance(reason, ConnectionError): details['category'] = 'connection'
        else: details['category'] = 'unclassified_transport'
    return details


def process(bundle_raw, folder, ledger_path, authorization, authorization_hash, send, archive):
    """Caller holds the exclusive batch lock. send is invoked at most once per slot."""
    folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
    delivery = folder/'delivery.json'; bh = digest(bundle_raw)
    if delivery.exists():
        prior = json.loads(delivery.read_text(encoding='utf-8'))
        if prior['request_bundle_sha256'] != bh:
            raise ValueError('request changed after durable delivery')
        return prior
    bundle = json.loads(bundle_raw)
    account = json.loads(Path(ledger_path).read_text(encoding='utf-8'))
    if (authorization.get('context_version')!='eef-compact-640-v1' or authorization.get('resolution')!=640 or authorization.get('image_groups')!=2
        or authorization.get('status') != 'authorized' or not authorization.get('authorization_evidence')
        or account.get('status') != 'running'
        or account.get('authorization_sha256') != authorization_hash
        or account.get('scope') != {'gpu_seconds':5400,'requests':78,'usd':authorization['usd_cap'],'old_balance_transferred':0}):
        raise ValueError('authorization or financial scope mismatch')
    key = f"{bundle['position']:03d}-{bundle['kind']}-{bundle['turn']:03d}"
    answer = {'status':'censored','call':None,'api_attempted':False,'request_bundle_sha256':bh}
    entries = account['entries']
    if any(e['request_id'] == key for e in entries):
        answer.update(reason='prior_request_without_durable_delivery', api_attempted=True)
        account['status'] = 'stopped_unknown_outcome'
        save(ledger_path, account); save(delivery, answer)
        return answer
    (folder/'request-bundle.json').write_bytes(bundle_raw)
    try:
        wire, amount, estimate = build_request(bundle, archive, entries, authorization['usd_cap'], authorization_hash)
        save(folder/'input-estimate.json', estimate)
    except BudgetLimitError:
        answer['reason']='budget_exhausted'
        account['status']='stopped_budget'
        save(ledger_path,account);save(delivery,answer)
        return answer
    except Exception:
        answer['reason'] = 'audit_or_budget_rejected'
        account['status'] = 'stopped_pre_network'
        save(ledger_path, account); save(delivery, answer)
        return answer
    (folder/'request-wire.json').write_bytes(wire)
    entry = {'request_id':key,'position':bundle['position'],'turn':bundle['turn'],'kind':bundle['kind'],
             'status':'reserved_before_network','reserve_usd':str(amount),'estimated_usd':None,
             'request_sha256':digest(wire),'request_bundle_sha256':bh,
             'reserved_at_utc':datetime.now(timezone.utc).isoformat()}
    entries.append(entry); save(ledger_path, account)  # Durable BEFORE possible billing.
    try:
        raw = send(wire, key)
        (folder/'response-raw.json').write_bytes(raw)
        parsed = parse_response(raw, estimate, reflection=bundle['kind']=='reflection')
        entry.update(parsed, response_sha256=digest(raw))
        answer.update(parsed, api_attempted=True)
        if parsed['status'] == 'censored': account['status'] = 'stopped_provider_contract'
    except Exception as exc:
        details = transport_error_details(exc)
        save(folder/'transport-error.json', details)
        entry.update(status='unknown_provider_outcome', error_type=type(exc).__name__, transport_error=details)
        account['status'] = 'stopped_unknown_outcome'
        answer.update(reason='transport_or_provider_parse_error', api_attempted=True)
    save(ledger_path, account); save(delivery, answer)
    return answer
