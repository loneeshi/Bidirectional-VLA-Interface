"""Project an archived TCP space curve into each frame of a C2 replay demo.

The overlay is evaluation-only. It uses the frozen MS-HAB human-render camera,
robot proprioception, and archived TCP poses; it is never supplied to Astra.
Historical 3D points are reprojected through the camera at the *current* frame.
The archived video has no depth buffer, so the curve is an X-ray overlay rather
than a depth-occluded simulator geometry.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np


# Frozen MS-HAB SequentialTaskEnv human camera, mounted on torso_lift_link.
# In torso coordinates: look_at([-0.2, 0.5, 1], [0.2, -0.2, 0]).
# Fetch URDF torso_lift_joint origin: [-0.086875, 0, 0.37743], axis +z.
CAMERA_EYE_IN_TORSO = np.array([-0.2, 0.5, 1.0], dtype=float)
CAMERA_TARGET_IN_TORSO = np.array([0.2, -0.2, 0.0], dtype=float)
TORSO_JOINT_ORIGIN = np.array([-0.086875, 0.0, 0.37743], dtype=float)
FOV_Y_RAD = 1.75
IMAGE_SIZE = 512
FPS = 20.0


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rotation_z(yaw: float) -> np.ndarray:
    c, s = math.cos(yaw), math.sin(yaw)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]], dtype=float)


def tcp_world(qpos: list[float], tcp_base: list[list[float]]) -> np.ndarray:
    """Evaluation-side root coordinates; only relative points reach the image."""
    base = np.array([qpos[0], qpos[1], 0.0], dtype=float)
    tcp = np.asarray(tcp_base, dtype=float)[:3, 3]
    return base + rotation_z(float(qpos[2])) @ tcp


def camera_pose(qpos: list[float]) -> tuple[np.ndarray, np.ndarray]:
    """Return camera eye and camera-to-world rotation in SAPIEN x/left/up axes."""
    torso = TORSO_JOINT_ORIGIN + np.array([0.0, 0.0, qpos[3]])
    eye_base = torso + CAMERA_EYE_IN_TORSO
    forward = CAMERA_TARGET_IN_TORSO - CAMERA_EYE_IN_TORSO
    forward /= np.linalg.norm(forward)
    left = np.cross(np.array([0.0, 0.0, 1.0]), forward)
    left /= np.linalg.norm(left)
    up = np.cross(forward, left)
    axes_base = np.column_stack((forward, left, up))
    root_rotation = rotation_z(float(qpos[2]))
    eye = np.array([qpos[0], qpos[1], 0.0]) + root_rotation @ eye_base
    return eye, root_rotation @ axes_base


def project(point_world: np.ndarray, qpos: list[float], width: int = IMAGE_SIZE,
            height: int = IMAGE_SIZE) -> tuple[float, float] | None:
    eye, axes = camera_pose(qpos)
    forward, left, up = axes.T @ (point_world - eye)
    if forward <= 0.01:
        return None
    focal = height / (2 * math.tan(FOV_Y_RAD / 2))
    # SAPIEN camera +y is left and +z is up; raster y increases downward.
    u = width / 2 - focal * left / forward
    v = height / 2 - focal * up / forward
    return float(u), float(v)


def draw_overlay(frame: np.ndarray, points_world: list[np.ndarray],
                 camera_qpos: list[float], step: int, kind: str = "replay"):
    from PIL import Image, ImageDraw, ImageFont

    image = Image.fromarray(frame).convert("RGBA")
    if image.size != (IMAGE_SIZE, IMAGE_SIZE):
        raise ValueError(f"unexpected human camera resolution: {image.size}")
    layer = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    pixels = [project(p, camera_qpos) for p in points_world[:step]]
    current_segment = []
    for point in pixels:
        visible = point is not None and -20 <= point[0] <= IMAGE_SIZE + 20 and -20 <= point[1] <= IMAGE_SIZE + 20
        if visible:
            current_segment.append(point)
        else:
            if len(current_segment) > 1:
                draw.line(current_segment, fill=(8, 22, 30, 220), width=9, joint="curve")
                draw.line(current_segment, fill=(0, 244, 239, 230), width=5, joint="curve")
            current_segment = []
    if len(current_segment) > 1:
        draw.line(current_segment, fill=(8, 22, 30, 220), width=9, joint="curve")
        draw.line(current_segment, fill=(0, 244, 239, 230), width=5, joint="curve")
    if pixels and pixels[-1] is not None:
        u, v = pixels[-1]
        if 0 <= u < IMAGE_SIZE and 0 <= v < IMAGE_SIZE:
            draw.ellipse((u - 8, v - 8, u + 8, v + 8), fill=(255, 183, 48, 245),
                         outline=(9, 24, 32, 255), width=3)
    try:
        font = ImageFont.truetype("DejaVuSans.ttf", 17)
    except OSError:
        font = ImageFont.load_default()
    draw.rounded_rectangle((10, 10, 326, 50), radius=7, fill=(7, 20, 28, 205))
    draw.text((19, 19), f"TCP 3D trace   |   step {step}/{len(points_world)}",
              fill=(255, 255, 255, 255), font=font)
    draw.rounded_rectangle((10, 481, 502, 505), radius=5, fill=(7, 20, 28, 205))
    draw.text((16, 484), f"Evaluator overlay (X-ray; no depth occlusion)   |   {kind}",
              fill=(230, 246, 247, 255), font=font)
    return Image.alpha_composite(image, layer).convert("RGB")


def run(args: argparse.Namespace) -> dict:
    import imageio.v2 as imageio

    if args.output.exists():
        raise FileExistsError(args.output)
    if args.expected_video_sha256 and sha256(args.video) != args.expected_video_sha256:
        raise ValueError("source video SHA-256 mismatch")
    if args.expected_result_sha256 and sha256(args.result) != args.expected_result_sha256:
        raise ValueError("source result SHA-256 mismatch")
    result = json.loads(args.result.read_text(encoding="utf-8"))
    frames = result["frames"]
    from eef_commanded_trajectory import segments, draw_command_comparison
    plans = segments(result) if getattr(args, "command_overlay", False) else []
    if any(row["step"] != i for i, row in enumerate(frames, 1)):
        raise ValueError("source trajectory is not contiguous")
    if not frames:
        raise ValueError("source has no physical-step trajectory")
    initial_state = result.get("initial_robot_state") or {}
    call_records = result.get("base_call_records_eval_only") or []
    initial_qpos = initial_state.get("qpos")
    initial_source = "initial_robot_state"
    if initial_qpos is None and call_records:
        initial_qpos = (call_records[0].get("entry") or {}).get("qpos")
        initial_source = "first_base_call_entry"
    if initial_qpos is None:
        initial_qpos = frames[0]["qpos"]
        initial_source = "first_step_approximation"
    poses = [initial_qpos] + [row["qpos"] for row in frames]
    if any(len(q) < 4 for q in poses):
        raise ValueError("camera projection requires root x/y/yaw and torso qpos")
    points_world = [tcp_world(row["qpos"], row["tcp_base"]) for row in frames]
    reader = imageio.get_reader(str(args.video))
    incomplete = args.output.with_name(args.output.stem + "-incomplete.mp4")
    writer = imageio.get_writer(str(incomplete), fps=FPS, codec="libx264", quality=8)
    count = 0
    try:
        fps = float(reader.get_meta_data()["fps"])
        if abs(fps - FPS) > 1e-3:
            raise ValueError(f"input FPS is {fps}, expected {FPS}")
        for step, frame in enumerate(reader):
            if step >= len(poses):
                raise ValueError("video has more frames than qpos records")
            image = draw_overlay(frame, points_world, poses[step], step, args.kind)
            if getattr(args, "command_overlay", False): image = draw_command_comparison(image, plans, poses[step], step)
            writer.append_data(np.asarray(image))
            count += 1
        if count != len(poses):
            raise ValueError(f"video/trajectory frame mismatch: {count} vs {len(poses)}")
    finally:
        writer.close()
        reader.close()
    incomplete.rename(args.output)
    receipt = {
        "kind": "eef_tcp_3d_scene_projection", "video": str(args.output),
        "video_sha256": sha256(args.output), "source_video_sha256": sha256(args.video),
        "source_result_sha256": sha256(args.result), "frames": count, "fps": FPS,
        "resolution": [IMAGE_SIZE, IMAGE_SIZE], "position": result["position"],
        "original_strict_pick_success": result["strict_pick_success"],
        "kind_label": args.kind, "initial_qpos_source": initial_source,
        "camera": "frozen MS-HAB human render camera on torso_lift_link; fovy=1.75",
        "trajectory": "recorded TCP transformed by robot root qpos and projected into each current camera pose",
        "occlusion": "X-ray overlay; original RGB video has no depth buffer",
        "evaluation_only": True, "model_calls": 0, "simulator_steps": 0,
        "command_overlay": bool(getattr(args, "command_overlay", False)),
        "command_semantics": "issued waypoint connectors/base commands, not model physical predictions; no future commands displayed",
    }
    args.receipt.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return receipt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("video", "result", "output", "receipt"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--command-overlay", action="store_true")
    parser.add_argument("--expected-video-sha256")
    parser.add_argument("--expected-result-sha256")
    parser.add_argument("--kind", choices=("replay", "online"), required=True)
    args = parser.parse_args()
    print(json.dumps(run(args)), flush=True)


if __name__ == "__main__":
    main()
