"""One native PPO Navigate -> SAC Pick census case, with no interventions.

Execution is deliberately guarded by a separate experiment authorization file.
The dry run checks the frozen roster without importing the simulator or using a
GPU. The batch controller must impose the per-process and cumulative wall caps.
"""

from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import math
import os
from pathlib import Path
import random
import subprocess
import time

from classify_real_handoff_pick import classify


GPU1 = "GPU-b7ebba23-7824-7601-df32-be55628936c3"
MSHAB_COMMIT = "e9ff3d23496d38e4431c8d913e147ffa007f7f72"
SEQUENTIAL_SHA256 = "47fd4999f7326568a550890caa48eac070901525373fac667ff56384eeb2a6be"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def tensor_digest(policy):
    h = hashlib.sha256()
    for key in sorted(policy):
        value = policy[key]
        if isinstance(value, dict):
            h.update(key.encode())
            h.update(tensor_digest(value).encode())
        else:
            array = value.detach().cpu().contiguous().numpy()
            h.update(key.encode())
            h.update(str(array.shape).encode())
            h.update(array.tobytes())
    return h.hexdigest()


def yaw_from_quaternion(q):
    w, x, y, z = (float(v) for v in q)
    return math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))


def preflight(args):
    roster = json.loads(args.roster.read_text(encoding="utf-8"))
    if roster.get("schema") != "bvi.real-handoff-pick-census-roster/1":
        raise ValueError("Wrong roster schema")
    if not 0 <= args.plan_position < len(roster["plans"]):
        raise ValueError("Plan position outside frozen roster")
    row = roster["plans"][args.plan_position]
    if args.expected_roster_sha256 != digest(args.roster):
        raise ValueError("Frozen roster hash mismatch")
    if args.source_task_plans_sha256 != roster["source_task_plans_sha256"]:
        raise ValueError("Task-plan asset hash differs from frozen roster")
    if args.checkpoint_hashes is not None:
        if args.expected_checkpoint_hashes_sha256 != digest(args.checkpoint_hashes):
            raise ValueError("Frozen checkpoint list hash mismatch")
    if args.episode_configs is not None:
        if args.expected_episode_configs_sha256 != digest(args.episode_configs):
            raise ValueError("Frozen episode-config list hash mismatch")
    if args.execute:
        if args.authorization is None:
            raise ValueError("Execution requires this experiment's authorization file")
        authorization = json.loads(args.authorization.read_text(encoding="utf-8"))
        common = (authorization.get("experiment_id") == "real-handoff-pick-census-20260924"
                  and authorization.get("gpu_uuid") == GPU1
                  and authorization.get("provider_requests") == 0
                  and 0 < authorization.get("single_process_seconds", 0) <= 600
                  and 5 < args.single_process_seconds <= authorization["single_process_seconds"])
        first_stage = (authorization.get("status") == "authorized_preflight"
                       and 0 < authorization.get("preflight_gpu1_process_seconds", 0) <= 3600
                       and args.plan_position < 12)
        full_stage = (authorization.get("status") == "authorized_full_batch"
                      and authorization.get("protocol_amendment") == "stochastic_replay_v1"
                      and 0 < authorization.get("full_batch_gpu1_process_seconds", 0) <= 7200
                      and authorization.get("target_valid_handoffs") == 60
                      and 12 <= args.plan_position < 120)
        if not common or not (first_stage or full_stage):
            raise ValueError("No matching bounded census authorization")
        if os.environ.get("CUDA_VISIBLE_DEVICES") != GPU1:
            raise ValueError("CUDA_VISIBLE_DEVICES must pin laboratory GPU1 UUID")
    return row


def run(args, row):
    import numpy as np
    import torch
    from mani_skill import ASSET_DIR
    from mani_skill.envs.sapien_env import BaseEnv
    from mshab.envs.make import EnvConfig
    import mshab.envs.sequential_task as sequential
    import bvi.nav_camera_env  # register official-camera-compatible environment
    from bvi.census_contact import CensusContactMeter
    from bvi.logging import JsonlLogger
    from bvi.mshab_adapter import OfficialRLSkill, jsonable, make_mshab_adapter, scalar
    from bvi.protocol import Requirement, SkillRequest, SkillStatus
    from check_c2_snapshot_restore import capture, clone, restore, max_error

    if digest(sequential.__file__) != SEQUENTIAL_SHA256:
        raise ValueError("Official sequential runtime SHA-256 changed")
    actual_commit = subprocess.check_output(
        ["git", "-C", str(Path(sequential.__file__).resolve().parents[2]),
         "rev-parse", "HEAD"], text=True).strip()
    if actual_commit != MSHAB_COMMIT:
        raise ValueError("Official MS-HAB commit changed")
    if not args.checkpoint_root.is_dir():
        raise FileNotFoundError(args.checkpoint_root)
    if args.checkpoint_hashes is None:
        raise ValueError("Execution requires frozen checkpoint hashes")
    known = {}
    for line in args.checkpoint_hashes.read_text(encoding="utf-8").splitlines():
        value, relative = line.split(maxsplit=1)
        known[relative] = value
    category = row["first_pick_obj_id"].split("-")[0]
    selected = [f"navigate/all/{name}" for name in ("config.yml", "policy.pt")]
    selected += [f"pick/{category}/{name}" for name in ("config.yml", "policy.pt")]
    for relative in selected:
        if relative not in known or digest(args.checkpoint_root / "rl/tidy_house" / relative) != known[relative]:
            raise ValueError(f"Official checkpoint/config SHA-256 mismatch: {relative}")
    if args.output.exists():
        raise FileExistsError(args.output)
    args.output.mkdir(parents=True)
    started = time.monotonic()
    deadline = started + args.single_process_seconds - 5
    seed = row["asset_plan_index"]
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    logger = JsonlLogger(args.output / "events.jsonl", args.output.name)
    plan_path = ASSET_DIR / "scene_datasets/replica_cad_dataset/rearrange/task_plans/tidy_house/sequential/val/all.json"
    if digest(plan_path) != args.source_task_plans_sha256:
        raise ValueError("Runtime task plan asset differs from frozen roster")
    episode_record = None
    if args.episode_configs is not None:
        episode_manifest = json.loads(args.episode_configs.read_text(encoding="utf-8"))
        if (episode_manifest.get("schema") != "bvi.real-handoff-episode-configs/1"
                or episode_manifest.get("roster_sha256") != args.expected_roster_sha256
                or len(episode_manifest.get("rows", [])) <= args.plan_position):
            raise ValueError("Episode-config manifest differs from census roster")
        episode_record = episode_manifest["rows"][args.plan_position]
        if (episode_record["plan_uid"] != row["plan_uid"]
                or episode_record["init_config_name"] != row["init_config_name"]):
            raise ValueError("Episode-config row identity mismatch")
        episode_path = ASSET_DIR / "scene_datasets/replica_cad_dataset/rearrange" / row["init_config_name"]
        if digest(episode_path) != episode_record["episode_config_sha256"]:
            raise ValueError("Runtime episode config differs from frozen source")
    env_kwargs = {"require_build_configs_repeated_equally_across_envs": False,
                  "add_event_tracker_info": True,
                  "human_render_camera_configs": {"width": 512, "height": 512},
                  "task_cfgs": {"navigate": {"ignore_arm_checkers": True}}}
    if "invisible_goals_in_human_render" in inspect.signature(BaseEnv.__init__).parameters:
        env_kwargs["invisible_goals_in_human_render"] = True
    cfg = EnvConfig(env_id="BVISequentialWorkspaceCamera-v0", num_envs=1,
                    max_episode_steps=7000, task_plan_fp=str(plan_path), obs_mode="rgbd",
                    render_mode="rgb_array", record_video=False, info_on_video=False,
                    continuous_task=True, frame_stack=3, stationary_base=False,
                    stationary_torso=False, stationary_head=True, env_kwargs=env_kwargs)
    adapter = None
    contact_meter = None
    report = {"schema": "bvi.real-handoff-pick-case/1", "plan_position": args.plan_position,
              "row": row, "seed": seed, "status": "running", "api_requests": 0,
              "training_updates": 0, "simulator_actions": 0, "policy_inferences": 0,
              "official_mshab_commit": MSHAB_COMMIT,
              "sequential_task_sha256": SEQUENTIAL_SHA256,
              "roster_sha256": args.expected_roster_sha256}

    def ensure_time():
        if time.monotonic() >= deadline:
            raise TimeoutError("Census single-process wall limit")

    def save_report():
        report["wall_seconds"] = time.monotonic() - started
        (args.output / "result.json").write_text(json.dumps(report, indent=2,
                                                        ensure_ascii=False), encoding="utf-8")

    def handoff_visibility():
        u = adapter.uenv
        target_actor = u.subtask_objs[1]._objs[0]
        target_id = int(target_actor.per_scene_id)
        head = u._sensors["fetch_head"]
        before = tensor_digest(adapter.observe().policy)
        head.capture()
        image = head.get_obs(rgb=False, depth=False, position=False,
                             segmentation=True).get("segmentation")
        if image is None or image.ndim != 4 or image.shape[0] != 1:
            raise ValueError("Head camera segmentation unavailable")
        pixels = int((image[0, :, :, 0] == target_id).sum().detach().cpu().item())
        after = tensor_digest(adapter.observe().policy)
        if before != after:
            raise ValueError("Diagnostic segmentation changed cached SAC input")
        return {"target_segmentation_id": target_id,
                "head_target_segmentation_pixels": pixels,
                "head_target_visible": pixels > 0,
                "head_segmentation_shape": list(image.shape),
                "policy_input_unchanged_after_segmentation": True}

    def handoff_geometry():
        u = adapter.uenv
        target = [float(x) for x in u.subtask_objs[1].pose.p[0].detach().cpu().tolist()]
        tcp = [float(x) for x in u.agent.tcp.pose.p[0].detach().cpu().tolist()]
        raw_base = jsonable(u.agent.base_link.pose.raw_pose)[0]
        base = [float(x) for x in raw_base[:3]]
        yaw = yaw_from_quaternion(raw_base[3:])
        bearing = math.atan2(target[1] - base[1], target[0] - base[0]) - yaw
        bearing = math.atan2(math.sin(bearing), math.cos(bearing))
        return {"base_pose_xyz_yaw": [*base, yaw], "target_pose_xyz": target,
                "tcp_pose_xyz": tcp,
                "base_target_horizontal_distance_m": math.dist(base[:2], target[:2]),
                "target_bearing_left_rad": bearing,
                "tcp_target_distance_m": math.dist(tcp, target),
                "target_height_m": target[2],
                "source_furniture_type": (episode_record["source_furniture_type"]
                                          if episode_record else None),
                "source_furniture_instance": (episode_record["source_furniture_instance"]
                                              if episode_record else None),
                "source_furniture_link_number": (episode_record["source_furniture_link_number"]
                                                 if episode_record else None),
                "episode_config_sha256": (episode_record["episode_config_sha256"]
                                          if episode_record else None),
                "source_furniture_status": ("frozen_official_episode_receptacle"
                                            if episode_record else "not_yet_resolved_from_scene_geometry")}

    try:
        ensure_time()
        adapter = make_mshab_adapter(cfg, logger, args.output, seed=seed)
        bci = adapter.uenv.scene_builder.build_config_names_to_idxs[row["build_config_name"]]
        tpi = row["task_plan_index_within_build_config"]
        actual = adapter.uenv.build_config_idx_to_task_plans[bci][tpi].subtasks[0].uid
        if actual != row["plan_uid"]:
            raise ValueError("Asset binding disagrees with frozen plan UID")
        adapter.reset(seed, options={"reconfigure": True, "build_config_idxs": [bci],
                                     "task_plan_idxs": torch.tensor([tpi], device=adapter.uenv.device)})
        if adapter.original_plan.subtasks[0].uid != row["plan_uid"]:
            raise ValueError("Explicit reset selected a different plan")
        report["binding"] = {"build_config_index": bci, "task_plan_index": tpi,
                             "first_uid": adapter.original_plan.subtasks[0].uid,
                             "policy_state_shape": list(adapter.observe().policy["state"].shape),
                             "native_horizons": {name: int(adapter.uenv.task_cfgs[name].horizon)
                                                 for name in ("navigate", "pick", "place")}}
        if report["binding"]["policy_state_shape"] != [1, 42]:
            raise ValueError("Official 42D policy state mismatch")
        if report["binding"]["native_horizons"] != {"navigate": 500, "pick": 200, "place": 200}:
            raise ValueError("Native horizon mismatch")
        initial_pointer = int(scalar(adapter.uenv.subtask_pointer))
        report["binding"]["initial_subtask_pointer"] = initial_pointer
        if initial_pointer == 1:
            report["status"] = "navigation_already_satisfied_at_reset"
            report["navigation"] = {"status": "zero_step_reset_transition",
                                    "steps": 0,
                                    "reason": "Official reset selected first Pick without a Navigate action"}
            save_report()
            return report
        if initial_pointer != 0:
            raise ValueError(f"Unexpected initial subtask pointer: {initial_pointer}")
        skills = {name: OfficialRLSkill(name, adapter, args.checkpoint_root, "rl_per_obj")
                  for name in ("navigate", "pick")}

        def run_skill(name, call_id, *, collect_trace=False, record_actions=False):
            ensure_time()
            observation = adapter.observe()
            allowed = observation.allowed_calls
            if len(allowed) != 1 or allowed[0].skill != name:
                raise ValueError(f"Expected native {name} subtask")
            request = SkillRequest(call_id, name, allowed[0].target_id, observation.frame_id,
                                   (Requirement("completion", "benchmark_success"),),
                                   report["binding"]["native_horizons"][name],
                                   args.single_process_seconds)
            skill = skills[name]
            skill.start(request, observation)
            rows = []
            action_hashes = []
            status = "native_horizon_exhausted"
            for step_index in range(request.max_steps):
                ensure_time()
                action = skill.act(observation)
                if record_actions:
                    action_hashes.append(hashlib.sha256(json.dumps(action).encode()).hexdigest())
                report["policy_inferences"] += 1
                transition = adapter.step(action)
                report["simulator_actions"] += 1
                observation = transition.observation
                feedback = skill.feedback(request, transition)
                if collect_trace:
                    sample = sample_pick_step(step_index, transition.info)
                    if step_index in (0, 9, 19) or feedback.status is not SkillStatus.EXECUTING:
                        sample["review_frame_paths"] = adapter.save_observation_images()
                    rows.append(sample)
                if feedback.status is not SkillStatus.EXECUTING:
                    status = feedback.status.value
                    break
                if transition.terminated or transition.truncated:
                    status = "environment_terminal"
                    break
            return {"status": status, "steps": len(rows) if collect_trace else step_index + 1,
                    "feedback": jsonable(feedback), "final_info": jsonable(transition.info),
                    "action_sha256": action_hashes if record_actions else None}, rows

        def official_pick_reason(result, rows):
            if result["status"] == SkillStatus.SUCCEEDED.value:
                return "strict_success"
            if (any(not s["cumulative_force_within_limit"] for s in rows)
                    or not bool(scalar(result["final_info"]["cumulative_force_within_limit"]))):
                return "cumulative_force_limit"
            if result["steps"] == 200:
                return "pick_horizon_exhausted"
            return "other_official_failure"

        def sample_pick_step(step_index, info):
            u = adapter.uenv
            index = int(scalar(u.subtask_pointer))
            # After a successful Pick, the pointer has advanced; the target is
            # still the original subtask-1 object, not the new Navigate target.
            target_obj = u.subtask_objs[1]
            target = target_obj.pose.p[0].detach().cpu().tolist()
            tcp = u.agent.tcp.pose.p[0].detach().cpu().tolist()
            base = jsonable(u.agent.base_link.pose.raw_pose)[0]
            force_n = float(scalar(info["robot_force"]))
            # The official robot_force sums net link forces. Use complete
            # robot-to-scene pairwise impulses for collision attribution.
            contacts = contact_meter.read()
            row = {"step_index": step_index,
                   "base_pose_xy_yaw": [float(base[0]), float(base[1]), yaw_from_quaternion(base[3:])],
                   "tcp_pose_xyz": [float(x) for x in tcp],
                   "target_pose_xyz": [float(x) for x in target],
                   "tcp_target_distance_m": math.dist(tcp, target),
                   "target_pair_force_n": contacts["target_contact_force_n"],
                   "official_finger_target_pairwise_force_n": float(
                       scalar(info["robot_target_pairwise_force"])),
                   "robot_force_n": force_n,
                   "robot_total_contact_impulse_ns": contacts["robot_total_contact_impulse_ns"],
                   "contact_physics_timestep_seconds": contacts["physics_timestep_seconds"],
                   "robot_cumulative_force_n": float(scalar(info["robot_cumulative_force"])),
                   "is_grasped": bool(scalar(info["is_grasped"])),
                   "official_success": bool(scalar(info["success"])),
                   "official_fail": bool(scalar(info["fail"])),
                   "cumulative_force_within_limit": bool(scalar(info["cumulative_force_within_limit"])),
                   "non_target_contacts": contacts["non_target_contacts"],
                   "contact_measurement_scope": contacts["measurement_scope"]}
            logger.emit("census_pick_step", **row)
            return row

        navigation, _ = run_skill("navigate", "census-navigate")
        report["navigation"] = navigation
        if navigation["status"] != SkillStatus.SUCCEEDED.value:
            report["status"] = "navigation_failed"
            save_report()
            return report
        if int(scalar(adapter.uenv.subtask_pointer)) != 1:
            raise ValueError("Navigation completed without entering first Pick")
        report["handoff"] = {"state_sha256": hashlib.sha256(json.dumps(
            jsonable(adapter.uenv.get_state_dict()), sort_keys=True,
            separators=(",", ":"), allow_nan=False).encode()).hexdigest(),
            "pick_input_sha256": tensor_digest(adapter.observe().policy),
            "image_paths": adapter.save_observation_images(),
            **handoff_geometry(),
            **handoff_visibility()}
        if not args.parity_control:
            state_before_query = clone(adapter.uenv.get_state_dict())
            input_before_query = tensor_digest(adapter.observe().policy)
            contact_meter = CensusContactMeter(adapter.uenv, adapter.uenv.subtask_objs[1]._objs[0])
            contact_meter.read()
            report["contact_query_read_only_control"] = {
                "state_max_error": max_error(state_before_query, adapter.uenv.get_state_dict()),
                "policy_input_equal": input_before_query == tensor_digest(adapter.observe().policy),
            }
            if (report["contact_query_read_only_control"]["state_max_error"] != 0
                    or not report["contact_query_read_only_control"]["policy_input_equal"]):
                raise ValueError("Contact query changed handoff state or SAC input")
        snapshot = capture(adapter)
        torch.save(snapshot, args.output / "full-handoff-capture.pt")
        report["handoff"]["snapshot_sha256"] = digest(args.output / "full-handoff-capture.pt")
        reference = None
        if args.parity_control:
            reference, _ = run_skill("pick", "census-pick-uninstrumented",
                                     record_actions=True)
            restore(adapter, snapshot, mode=args.restore_mode)
            report["parity_restore_state_max_error"] = max_error(
                snapshot["simulator"], adapter.uenv.get_state_dict())
            report["parity_restore_pick_input_sha256"] = tensor_digest(adapter.observe().policy)
            if args.no_meter_restore_diagnostic:
                control, _ = run_skill("pick", "census-pick-uninstrumented-repeat",
                                       record_actions=True)
                report["no_meter_restore_diagnostic"] = {
                    "first_status": reference["status"],
                    "repeat_status": control["status"],
                    "first_steps": reference["steps"],
                    "repeat_steps": control["steps"],
                    "action_sha256_equal": reference["action_sha256"] == control["action_sha256"],
                    "first_action_equal": reference["action_sha256"][0] == control["action_sha256"][0],
                    "restore_state_max_error": report["parity_restore_state_max_error"],
                    "restore_input_equal": report["parity_restore_pick_input_sha256"]
                                           == report["handoff"]["pick_input_sha256"],
                }
                report["status"] = "diagnostic_only_no_baseline"
                return report
            contact_meter = CensusContactMeter(adapter.uenv, adapter.uenv.subtask_objs[1]._objs[0])
        if args.restore_before_baseline_diagnostic:
            restore(adapter, snapshot, mode=args.restore_mode)
            report["diagnostic_baseline_restore"] = {
                "state_max_error": max_error(snapshot["simulator"], adapter.uenv.get_state_dict()),
                "policy_input_equal": (tensor_digest(adapter.observe().policy)
                                       == report["handoff"]["pick_input_sha256"]),
            }
            if (report["diagnostic_baseline_restore"]["state_max_error"] > 1e-5
                    or not report["diagnostic_baseline_restore"]["policy_input_equal"]):
                raise ValueError("Diagnostic baseline restore changed handoff identity")
        report["contact_inventory"] = {"pair_count": contact_meter.pair_count,
                                       "target_name": contact_meter.target_name,
                                       "physics_timestep_seconds": contact_meter.physics_timestep_seconds,
                                       "scope": "sampled_last_physics_step_pairwise_impulses"}
        pick, pick_rows = run_skill("pick", "census-pick-baseline", collect_trace=True,
                                    record_actions=args.parity_control)
        report["pick"] = pick
        official_reason = official_pick_reason(pick, pick_rows)
        if reference is not None:
            report["instrumentation_parity"] = {
                "uninstrumented_reason": official_pick_reason(reference, []),
                "instrumented_reason": official_reason,
                "uninstrumented_steps": reference["steps"],
                "instrumented_steps": pick["steps"],
                "action_sha256_equal": reference["action_sha256"] == pick["action_sha256"],
                "restore_state_max_error": report["parity_restore_state_max_error"],
                "restore_input_equal": (report["parity_restore_pick_input_sha256"]
                                        == report["handoff"]["pick_input_sha256"])}
            parity = report["instrumentation_parity"]
            parity["passed"] = bool(
                parity["uninstrumented_reason"] == parity["instrumented_reason"]
                and parity["uninstrumented_steps"] == parity["instrumented_steps"]
                and parity["action_sha256_equal"]
                and parity["restore_state_max_error"] <= 1e-5
                and parity["restore_input_equal"])
            if not parity["passed"]:
                report["status"] = "infrastructure_censored"
                report["error_type"] = "instrumentation_parity_failed"
                return report
        trace = {"schema": "bvi.real-handoff-pick-trace/1",
                 "strict_pick_success": official_reason == "strict_success",
                 "official_termination_reason": official_reason,
                 "force_limit_step": next((i for i, s in enumerate(pick_rows)
                                          if not s["cumulative_force_within_limit"]), None),
                 "steps": pick_rows}
        (args.output / "baseline-trace.json").write_text(json.dumps(trace), encoding="utf-8")
        report["mechanism"] = classify(trace)
        report["official_termination_reason"] = official_reason
        if not trace["strict_pick_success"] or args.restore_before_baseline_diagnostic:
            restore(adapter, snapshot, mode=args.restore_mode)
            report["restore_state_max_error"] = max_error(snapshot["simulator"],
                                                           adapter.uenv.get_state_dict())
            report["restore_pick_input_sha256"] = tensor_digest(adapter.observe().policy)
            repeat, repeat_rows = run_skill("pick", "census-pick-repeat", collect_trace=True)
            repeat_reason = official_pick_reason(repeat, repeat_rows)
            repeat_trace = {"schema": "bvi.real-handoff-pick-trace/1",
                            "strict_pick_success": repeat_reason == "strict_success",
                            "official_termination_reason": repeat_reason,
                            "force_limit_step": next((i for i, s in enumerate(repeat_rows)
                                                     if not s["cumulative_force_within_limit"]), None),
                            "steps": repeat_rows}
            (args.output / "repeat-trace.json").write_text(json.dumps(repeat_trace), encoding="utf-8")
            report["repeat"] = repeat
            report["repeat_reason"] = repeat_reason
            report["repeat_mechanism"] = classify(repeat_trace)
            report["reproducible_failure"] = bool(
                not trace["strict_pick_success"]
                and not repeat_trace["strict_pick_success"]
                and report["restore_state_max_error"] <= 1e-5
                and report["restore_pick_input_sha256"] == report["handoff"]["pick_input_sha256"]
                and repeat_reason == official_reason and len(repeat_rows) == len(pick_rows)
                and report["repeat_mechanism"] == report["mechanism"])
            if args.restore_before_baseline_diagnostic:
                report["diagnostic_pair_agrees"] = bool(
                    report["restore_state_max_error"] <= 1e-5
                    and report["restore_pick_input_sha256"] == report["handoff"]["pick_input_sha256"]
                    and repeat_reason == official_reason and len(repeat_rows) == len(pick_rows)
                    and report["repeat_mechanism"] == report["mechanism"])
        report["status"] = ("completed" if args.restore_mode == "public"
                            else "diagnostic_only_restore_mode")
        if args.restore_before_baseline_diagnostic:
            report["status"] = "diagnostic_only_restored_pair"
        if args.restore_mode != "public":
            report["diagnostic_restore_mode"] = args.restore_mode
    except Exception as exc:
        report["status"] = "infrastructure_censored"
        report["error_type"] = type(exc).__name__
        report["error_message"] = str(exc)[:500]
    finally:
        report["wall_seconds"] = time.monotonic() - started
        save_report()
        if adapter is not None:
            adapter.close()
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--roster", type=Path, required=True)
    parser.add_argument("--expected-roster-sha256", required=True)
    parser.add_argument("--plan-position", type=int, required=True)
    parser.add_argument("--source-task-plans-sha256", required=True)
    parser.add_argument("--checkpoint-root", type=Path)
    parser.add_argument("--checkpoint-hashes", type=Path)
    parser.add_argument("--expected-checkpoint-hashes-sha256")
    parser.add_argument("--episode-configs", type=Path)
    parser.add_argument("--expected-episode-configs-sha256")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--authorization", type=Path)
    parser.add_argument("--single-process-seconds", type=float, default=600)
    parser.add_argument("--parity-control", action="store_true")
    parser.add_argument("--no-meter-restore-diagnostic", action="store_true")
    parser.add_argument("--restore-mode", choices=("public", "buffers"), default="public")
    parser.add_argument("--restore-before-baseline-diagnostic", action="store_true")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    if args.no_meter_restore_diagnostic and not args.parity_control:
        parser.error("No-meter restore diagnostic requires parity control")
    row = preflight(args)
    if not args.execute:
        print(json.dumps({"status": "dry_run_no_simulator", "plan_position": args.plan_position,
                          "row": row, "roster_sha256": digest(args.roster)}))
        return
    if args.checkpoint_root is None or args.output is None:
        parser.error("Execution requires checkpoint root and output")
    print(json.dumps(run(args, row), ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
