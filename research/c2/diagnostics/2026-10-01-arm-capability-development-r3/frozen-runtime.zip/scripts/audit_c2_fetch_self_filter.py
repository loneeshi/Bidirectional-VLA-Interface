"""Audit the pinned Fetch articulation self-collision filter on a raw C2 bundle.

This is an offline source-and-observation audit.  It never changes the bundle,
starts a simulator, or calls a policy.  The audit is deliberately tied to the
exact lab runtime source snapshots in ``runs/.../self-filter-source``.  An
unknown runtime or missing physics shape inventory fails closed.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


SCHEMA = "c2-fetch-self-filter-audit/1"
SAPIEN_TAG = "3.0.0b1"
SAPIEN_COMMIT = "d9031a351c39986e51bd0716bc3b51f9a05070d8"
SOURCE_SHA = {
    "fetch.urdf": "7503ea2dc96eb3d1130c81f7ff1e397f30df46459b3dbf10cf5d0d247c5b1256",
    "fetch.srdf": "bf78fc034a135f809be3ee96d967b1a79bcfafa1776a117322e9f9f2a3525546",
    "base_agent.py": "34d94e75baed67c73f6e462311cbcf003dc51ffa716271de3d9d129db9657c2e",
    "scene.py": "fa6da421e15aae4763861236862c52bf98da8456d4644befbcc941d60a824a9f",
    "maniskill_urdf_loader.py": "9656288910d4e604e2eec822f05bfe663c1da3b4a82e99ad1b8809244a67f398",
    "maniskill_articulation_builder.py": "babf944eb468cbd99502426769e786c1349031335c8ae993566ade78406d2c43",
    "maniskill_fetch.py": "cfa07e1dac21bd75f9f63f31742f4d06dd374ab46eb439b5ab367700100a4b39",
    "sapien_urdf_loader.py": "eabba86fe7d244ce8d469010f96914010a8883ea5835c86a8bc58be310510683",
    "sapien_actor_builder.py": "a27abad75c6e82d723122370eae6bdc011a624a93b351f88d9d083e14f8612b1",
    "sapien_filter_shader.hpp": "f5a8ccbcba296b76b2732243b2b86a48a09c6f2e44d2311ec925cbef2d2d4e0d",
    "sapien_collision_shape.cpp": "82740b12390d443eb5bc2d7992497d99ab6746c329f2465f2221c9bb2c22ab45",
    "sapien_articulation.cpp": "2ac52167b5b065a266365984d53fc1facb0c46112eb902a91ed538bb15b655f6",
    "sapien_physx_system.cpp": "27f63fa9cd0b4dd8817898395e909503c2c4b53c9220610fa15cb1710e0acc6e",
}
SAPIEN_URL = (
    f"https://github.com/haosulab/SAPIEN/blob/{SAPIEN_COMMIT}/"
)
PHYSX_PARENT_CHILD_URL = (
    "https://nvidia-omniverse.github.io/PhysX/ovphysx/latest/guides/"
    "articulation_stability.html#articulation-link-self-collision"
)


def digest(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def canonical(left: str, right: str) -> tuple[str, str]:
    return tuple(sorted((left, right)))


def class_assignment_is_false(source: str, class_name: str, attr: str) -> bool:
    tree = ast.parse(source)
    classes = [node for node in tree.body
               if isinstance(node, ast.ClassDef) and node.name == class_name]
    if len(classes) != 1:
        return False
    assignments = []
    for node in classes[0].body:
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            if any(isinstance(target, ast.Name) and target.id == attr for target in targets):
                assignments.append(node.value)
    return (len(assignments) == 1 and isinstance(assignments[0], ast.Constant)
            and assignments[0].value is False)


def class_has_assignment(source: str, class_name: str, attr: str) -> bool:
    tree = ast.parse(source)
    classes = [node for node in tree.body
               if isinstance(node, ast.ClassDef) and node.name == class_name]
    if len(classes) != 1:
        return True  # Unknown class is unsafe.
    for node in ast.walk(classes[0]):
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            if any(isinstance(target, ast.Name) and target.id == attr for target in targets):
                return True
    return False


def source_audit(directory: Path) -> tuple[dict, list[str]]:
    result = {}
    errors = []
    for name, expected in SOURCE_SHA.items():
        path = directory / name
        present = path.is_file()
        actual = digest(path) if present else None
        result[name] = {"path": str(path.resolve()), "sha256": actual,
                        "expected_sha256": expected, "matches_pinned_runtime": actual == expected}
        if actual != expected:
            errors.append(f"source_sha_mismatch:{name}")
    if errors:
        return result, errors
    base_agent = (directory / "base_agent.py").read_text(encoding="utf-8")
    fetch = (directory / "maniskill_fetch.py").read_text(encoding="utf-8")
    scene = (directory / "scene.py").read_text(encoding="utf-8")
    mani_loader = (directory / "maniskill_urdf_loader.py").read_text(encoding="utf-8")
    sapien_loader = (directory / "sapien_urdf_loader.py").read_text(encoding="utf-8")
    actor_builder = (directory / "sapien_actor_builder.py").read_text(encoding="utf-8")
    cpp_filter = (directory / "sapien_filter_shader.hpp").read_text(encoding="utf-8")
    cpp_shape = (directory / "sapien_collision_shape.cpp").read_text(encoding="utf-8")
    cpp_art = (directory / "sapien_articulation.cpp").read_text(encoding="utf-8")
    cpp_scene = (directory / "sapien_physx_system.cpp").read_text(encoding="utf-8")
    assertions = {
        "base_agent_default_self_collision_enabled":
            class_assignment_is_false(base_agent, "BaseAgent", "disable_self_collisions"),
        "fetch_does_not_override_default":
            not class_has_assignment(fetch, "Fetch", "disable_self_collisions"),
        "base_agent_forwards_flag_to_loader":
            "loader.disable_self_collisions = self.disable_self_collisions" in base_agent,
        "scene_creates_maniskill_urdf_loader":
            "from ..utils.building.urdf_loader import URDFLoader" in scene,
        "maniskill_loader_delegates_srdf_parse":
            "super().parse(" in mani_loader,
        "sapien_loader_reads_same_stem_srdf":
            'srdf_file = urdf_file[:-4] + "srdf"' in sapien_loader,
        "sapien_loader_only_reads_default_pairs":
            'elem.attrib["reason"].lower() == "default"' in sapien_loader,
        "sapien_loader_skips_direct_parent_child":
            "if p1 == l2 or p2 == l1:" in sapien_loader,
        "sapien_loader_sets_pair_ignore_bits":
            "link2builder[l1].collision_groups[2] |= 1 << (group_count - 1)" in sapien_loader
            and "link2builder[l2].collision_groups[2] |= 1 << (group_count - 1)" in sapien_loader,
        "urdf_collision_builder_never_requests_triggers":
            "is_trigger" not in sapien_loader,
        "actor_builder_does_not_convert_robot_shapes_to_triggers":
            "shape.set_is_trigger" not in actor_builder
            and "shape.is_trigger" not in actor_builder
            and "component.attach(shape)" in actor_builder,
        "sapien_shape_constructor_uses_normal_simulation_shape":
            "mPxShape = mEngine->getPxPhysics()->createShape(" in cpp_shape
            and "void PhysxCollisionShape::setIsTrigger(bool trigger)" in cpp_shape
            and "setIsTrigger(true)" not in cpp_shape,
        "gpu_filter_shader_uses_shape_groups":
            "TypeAffinityIgnoreFilterShaderGpu" in cpp_filter
            and "filterData0.word2 & filterData1.word2" in cpp_filter
            and "filterData0.word0 & filterData1.word1" in cpp_filter,
        "gpu_scene_uses_this_filter_shader":
            "sceneDesc.filterShader = TypeAffinityIgnoreFilterShaderGpu;" in cpp_scene,
        "sapien_articulation_does_not_disable_all_self_collision":
            "eDISABLE_SELF_COLLISION" not in cpp_art,
    }
    result["semantic_assertions"] = assertions
    errors.extend(f"source_semantics_unverified:{key}" for key, value in assertions.items() if not value)
    return result, errors


def group_pair_enabled(a: list[int], b: list[int]) -> bool:
    a0, a1, a2, a3 = (x & 0xffffffff for x in a)
    b0, b1, b2, b3 = (x & 0xffffffff for x in b)
    if (a3 & 0xffff0000) != (b3 & 0xffff0000):
        return False
    return bool(((a0 & b1) or (a1 & b0)) and
                not ((a2 & b2) and ((a3 & 0xffff) == (b3 & 0xffff))))


def audit(bundle_path: Path, source_dir: Path, sapien_version: str) -> dict:
    bundle_path = bundle_path.resolve(strict=True)
    source_dir = source_dir.resolve(strict=True)
    raw = json.loads(bundle_path.read_text(encoding="utf-8"))
    sources, errors = source_audit(source_dir)
    if sapien_version != SAPIEN_TAG:
        errors.append("sapien_runtime_version_mismatch")
    robot = raw.get("robot", {})
    cover = raw.get("coverage", {})
    urdf_spec = robot.get("urdf", {})
    urdf_path = bundle_path.parent / urdf_spec.get("path", "missing")
    urdf_hash = digest(urdf_path) if urdf_path.is_file() else None
    if (urdf_hash != urdf_spec.get("sha256") or
            urdf_hash != SOURCE_SHA["fetch.urdf"]):
        errors.append("bundle_urdf_not_exact_pinned_fetch")
    result = {
        "schema": SCHEMA, "status": "incomplete", "errors": errors,
        "raw_bundle": {"path": str(bundle_path), "sha256": digest(bundle_path)},
        "sapien_runtime_version": sapien_version,
        "sapien_source_tag": SAPIEN_TAG,
        "sapien_source_commit": SAPIEN_COMMIT,
        "sapien_filter_shader_source": SAPIEN_URL + "src/physx/filter_shader.hpp",
        "physx_parent_child_rule_source": PHYSX_PARENT_CHILD_URL,
        "source_evidence": sources,
        "bundle_urdf": {"path": str(urdf_path.resolve()), "sha256": urdf_hash},
        "shape_group_rule": "sapien-3.0.0b1-gpu-TypeAffinityIgnoreFilterShaderGpu",
        "parent_child_rule": "PhysX-articulation-direct-joint-pair-disabled",
        "fetch_disable_self_collisions": False,
        "direct_parent_child_pairs": [],
        "srdf_default_disabled_pairs": [],
        "group_filtered_pairs": [],
        "ignored_self_pairs": [],
        "coverage": {},
    }
    if not urdf_path.is_file():
        return result
    urdf = ET.parse(urdf_path).getroot()
    links = {node.get("name") for node in urdf.findall("link")}
    parents = set()
    for joint in urdf.findall("joint"):
        left, right = joint.find("parent").get("link"), joint.find("child").get("link")
        if left not in links or right not in links or left == right:
            errors.append("invalid_urdf_joint_link")
        parents.add(canonical(left, right))
    srdf_path = source_dir / "fetch.srdf"
    srdf = ET.parse(srdf_path).getroot() if srdf_path.is_file() else None
    srdf_pairs = set()
    if srdf is not None:
        for node in srdf.findall("disable_collisions"):
            left, right = node.get("link1"), node.get("link2")
            if node.get("reason", "").lower() == "default":
                if left not in links or right not in links or left == right:
                    errors.append("invalid_srdf_pair_link")
                else:
                    srdf_pairs.add(canonical(left, right))
    if len(srdf_pairs) != 10:
        errors.append("unexpected_srdf_default_pair_count")
    shape_inventory = cover.get("shape_inventory", {})
    robot_shapes = {name: shape_inventory.get(name) for name in links}
    if any(value is None for value in robot_shapes.values()):
        errors.append("robot_shape_inventory_missing_links")
    for name, shapes in robot_shapes.items():
        if shapes is None:
            continue
        for expected_index, shape in enumerate(shapes):
            groups = shape.get("collision_groups")
            if (shape.get("index") != expected_index or not isinstance(groups, list)
                    or len(groups) != 4 or not all(isinstance(x, int) and
                    -(1 << 31) <= x < (1 << 32) for x in groups)):
                errors.append(f"bad_robot_shape_groups:{name}:{expected_index}")
    nonempty = {name for name, shapes in robot_shapes.items() if shapes}
    no_shape = set(cover.get("robot_no_shape", []))
    mesh_links = [row.get("link") for row in robot.get("meshes", [])]
    if (nonempty != set(mesh_links) or len(mesh_links) != len(set(mesh_links)) or
            no_shape != links - nonempty or
            cover.get("robot_links_expected") != len(links) or
            set(robot.get("anchor_link_world", {})) != links):
        errors.append("robot_collision_mesh_or_link_coverage_mismatch")
    if any(row.get("body") in links for row in cover.get("mesh_errors", [])) or any(
            row.get("body") in links for row in cover.get("unexported_collision_shapes", [])):
        errors.append("robot_collision_shape_export_incomplete")
    result["coverage"] = {
        "urdf_link_count": len(links), "robot_shape_inventory_link_count":
            sum(value is not None for value in robot_shapes.values()),
        "robot_collision_bearing_link_count": len(nonempty),
        "robot_mesh_link_count": len(mesh_links),
        "srdf_default_disabled_pair_count": len(srdf_pairs),
        "urdf_parent_child_pair_count": len(parents),
        "raw_export_group_filtered_pair_count": len(robot.get("ignored_self_pairs", [])),
        "robot_trigger_shape_status": "source_verified_default_nontrigger",
        "mixed_shape_filter_link_pair_count": 0,
    }
    result["direct_parent_child_pairs"] = [list(pair) for pair in sorted(parents)]
    result["srdf_default_disabled_pairs"] = [list(pair) for pair in sorted(srdf_pairs)]
    if not errors:
        group_ignored = set()
        mixed_pairs = set()
        names = sorted(nonempty)
        for index, left in enumerate(names):
            for right in names[index + 1:]:
                pair_statuses = {group_pair_enabled(a["collision_groups"], b["collision_groups"])
                                 for a in robot_shapes[left] for b in robot_shapes[right]}
                if len(pair_statuses) > 1:
                    mixed_pairs.add(canonical(left, right))
                if pair_statuses == {False}:
                    group_ignored.add(canonical(left, right))
        ignored = parents | group_ignored
        result["group_filtered_pairs"] = [list(pair) for pair in sorted(group_ignored)]
        result["ignored_self_pairs"] = [list(pair) for pair in sorted(ignored)]
        result["coverage"]["mixed_shape_filter_link_pair_count"] = len(mixed_pairs)
        if mixed_pairs:
            errors.append("mixed_shape_filter_pairs_require_per_shape_fcl_meshes")
        # Every non-adjacent SRDF pair with two collision-bearing links should
        # appear in the observed shape groups.  This catches loader drift.
        unexplained = (srdf_pairs - parents) & {pair for pair in srdf_pairs
                                                if pair[0] in nonempty and pair[1] in nonempty}
        unexplained -= group_ignored
        if unexplained:
            errors.append("srdf_disabled_pairs_missing_from_observed_shape_groups")
        raw_pairs = {canonical(*pair) for pair in robot.get("ignored_self_pairs", [])}
        if raw_pairs != group_ignored:
            errors.append("raw_export_group_pairs_do_not_match_independent_recompute")
        result["missing_from_raw_group_only_export"] = [list(pair)
            for pair in sorted(ignored - raw_pairs)]
    # SAPIEN 3.0.0b1 does not expose trigger flags through its Python shape API.
    # The exact pinned URDF-loader, actor-builder and C++ shape-constructor
    # sources establish normal simulation shapes; any source drift fails above.
    reported_triggers = [shape.get("is_trigger") for shapes in robot_shapes.values()
                         if shapes for shape in shapes if "is_trigger" in shape]
    if reported_triggers:
        if len(reported_triggers) != sum(len(shapes or []) for shapes in robot_shapes.values()):
            errors.append("partially_reported_robot_trigger_flags")
        elif any(flag is not False for flag in reported_triggers):
            errors.append("robot_trigger_shape_present")
        else:
            result["coverage"]["robot_trigger_shape_status"] = "all_observed_false"
    result["errors"] = sorted(set(errors))
    result["status"] = "simulator_verified_complete" if not errors else "incomplete"
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("raw_bundle", type=Path)
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--sapien-version", default=SAPIEN_TAG)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = audit(args.raw_bundle, args.sources, args.sapien_version)
    encoded = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded, encoding="utf-8")
    print(encoded, end="")
    return 0 if result["status"] == "simulator_verified_complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
