"""Server-side HTTPS transport. Never log headers, credentials or exception text."""
from contextlib import contextmanager
import hashlib
import http.client
import os
from pathlib import Path
import socket
import ssl
import stat
import time
from urllib.error import HTTPError


class LeaseExpired(RuntimeError):
    pass


def credential_metadata(path):
    path = Path(path)
    info = path.lstat()
    parent = path.parent.lstat()
    return {"path": str(path), "regular_file": stat.S_ISREG(info.st_mode),
            "not_symlink": not stat.S_ISLNK(info.st_mode),
            "mode": stat.S_IMODE(info.st_mode), "parent_mode": stat.S_IMODE(parent.st_mode),
            "owner_matches": info.st_uid == os.getuid(),
            "parent_owner_matches": parent.st_uid == os.getuid(), "content_read": False}


def validate_metadata(meta):
    if not (meta['regular_file'] and meta['not_symlink'] and meta['owner_matches']
            and meta['parent_owner_matches'] and meta['mode'] == 0o600
            and meta['parent_mode'] == 0o700):
        raise PermissionError('credential file must be owned regular 600 file in owned 700 directory')


def load_runtime_key(path):
    """Only the approved broker runtime calls this; never shell-source an env file."""
    meta = credential_metadata(path)
    validate_metadata(meta)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'r', encoding='utf-8') as stream:
        info = os.fstat(stream.fileno())
        if info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o600:
            raise PermissionError('credential changed during open')
        lines = stream.read(16384).splitlines()
    values = [line.split('=', 1)[1].strip() for line in lines
              if line.startswith('OPENAI_API_KEY=')]
    if len(values) != 1 or not values[0] or any(c.isspace() for c in values[0]):
        raise ValueError('one nonempty OPENAI_API_KEY assignment required')
    return values[0]


@contextmanager
def exclusive_lock(path):
    import fcntl
    with Path(path).open('a+b') as stream:
        os.chmod(path, 0o600)
        fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            fcntl.flock(stream, fcntl.LOCK_UN)


class PhaseTransport:
    """One verified TLS connection per send; same wire and policy as local broker.

    A single absolute deadline covers all phases. A phase receipt deliberately
    contains only an enum, duration, byte count and status. TLS errors propagate
    to the existing bounded-transport-v2 classifier.
    """
    def __init__(self, key, emit, lease_remaining, timeout=180.,
                 connect=socket.create_connection, context_factory=ssl.create_default_context,
                 clock=time.monotonic):
        self.key, self.emit, self.remaining = key, emit, lease_remaining
        self.timeout, self.connect, self.context_factory, self.clock = timeout, connect, context_factory, clock

    def __call__(self, wire, request_id):
        deadline = self.clock() + min(self.timeout, self.remaining())
        def timeout():
            left = min(deadline-self.clock(), self.remaining())
            if left <= 0:
                raise LeaseExpired('request lease expired')
            return left
        def phase(name, operation, size=None):
            start = self.clock()
            row = {'phase': name, 'status': 'started'}
            self.emit(row)
            try:
                value = operation()
            except BaseException:
                self.emit({'phase': name, 'status': 'failed', 'seconds': self.clock()-start})
                raise
            row = {'phase': name, 'status': 'completed', 'seconds': self.clock()-start}
            if size is not None:
                row['bytes'] = size(value) if callable(size) else size
            self.emit(row)
            return value
        sock = None
        conn = None
        try:
            sock = phase('tcp', lambda: self.connect(('api.openai.com', 443), timeout()))
            sock.settimeout(timeout())
            sock = phase('tls', lambda: self.context_factory().wrap_socket(sock, server_hostname='api.openai.com'))
            conn = http.client.HTTPConnection('api.openai.com', timeout=timeout())
            conn.sock = sock
            def send():
                sock.settimeout(timeout())
                conn.request('POST', '/v1/responses', body=wire, headers={
                    'Authorization': 'Bearer '+self.key, 'Content-Type': 'application/json',
                    'X-Client-Request-Id': request_id, 'Connection': 'close'})
            phase('send', send, len(wire))
            sock.settimeout(timeout())
            response = phase('response_headers', conn.getresponse)
            self.emit({'phase': 'http_status', 'status_code': response.status})
            chunks = []
            def read():
                total = 0
                while not response.isclosed():
                    sock.settimeout(timeout())
                    chunk = response.read1(65536)
                    if not chunk:
                        break
                    chunks.append(chunk)
                    total += len(chunk)
                    if total > 32*1024*1024:
                        raise ValueError('response body exceeds transport bound')
                return b''.join(chunks)
            raw = phase('response_body', read, len)
            if response.status != 200:
                raise HTTPError('https://api.openai.com/v1/responses', response.status, 'provider status', {}, None)
            return raw
        finally:
            if conn is not None:
                conn.close()
            elif sock is not None:
                sock.close()
