"""Independent visual mobile condition; historical arm request bytes stay frozen."""
import copy
import json
import re
from . import eef_arm_visual_contract as compact
from .eef_guidance_v4 import PROMPT as BASE_PROMPT
from .eef_arm_contract import dispatch as arm_dispatch

VERSION = 'guidance-v4-mobile'
CONDITION = 'V-mobile'
SCHEMA = copy.deepcopy(compact.SCHEMA)
ROBOT_SPEC = dict(source='fixed Fetch robot model and frozen controller; no scene geometry',
    frame='current base_link; x forward, y left, z up',
    chassis_radius_m=.288, chassis_diameter_m=.576, chassis_forward_extent_m=.287,
    footprint_scope='rigid chassis only; excludes projecting arm',
    max_linear_speed_m_s=.5, max_angular_speed_rad_s=1., control_frequency_hz=20,
    base_call_step_cap=80, arm_call_step_cap=150, rest_step_cap=150,
    look_step_cap=40, gripper_step_cap=15, episode_step_cap=600, tool_call_cap=25,
    base_position_tolerance_m=.02, base_yaw_tolerance_rad=.03,
    max_turn_rad=3.141592653589793, max_forward_m=1.5,
    motion='turn then straight drive; negative distance reverses; no lateral drive')
PROMPT = BASE_PROMPT.replace('200 official control steps', '600 control steps (nonofficial extended horizon)').replace('60 steps per call', '150 steps per arm call').replace('at most 60 steps', 'at most 150 steps').replace('Reserve up to 60', 'Reserve up to 150') + '''
GUIDANCE OVERRIDE guidance-v4-mobile: you start at the same official Pick spawn,
and move_base is enabled. Robot specifications below are fixed robot information,
never target or furniture geometry. Base calls remain capped at 80 steps including
all turning, driving and settling; arm calls are capped at 150, total 600. Legal
parameters do not guarantee arrival within one call. Split substantial turns and
translations; near furniture use short measured segments and inspect fresh RGB-D.
Each base call's metric goal is relative to its entry pose. Read actual movement,
residuals and remaining steps, especially when arrived=false. The chassis footprint
does not bound the extended arm. No scene collision pre-check is performed.
After base motion query fresh sensor depth before setting new grasp goals; old
pixels and base-frame points are tied to the source observation. return_to_rest
returns upper-body joints, not the base to its starting location. Parameter errors
cost a call and zero physical steps; correct the named parameter on your next call.
Never interpret check_path acceptance or arrived as official grasp success.
'''

validate_call = compact.validate_call


def _clean(bundle):
    value = copy.deepcopy(bundle)
    for entry in value['observation']['history']:
        if entry['call'] is not None: validate_call(entry['call'])
    value['position'] = 5  # Legacy audit slot; identity is separately checked.
    compact.audit_observation(value['observation'], value['sensor_manifest'], value['turn'])
    return value


def build_wire(bundle, archive, condition=CONDITION):
    case = bundle['position']
    if condition != CONDITION or not isinstance(case, str) or not re.fullmatch(r'arm-dev-00[0-4]', case):
        raise ValueError('mobile development identity required')
    history = []
    for item in archive:
        if set(item) != {'bundle','call'} or item['bundle']['position'] != case:
            raise ValueError('cross-case archive')
        if item['call'] is not None: validate_call(item['call'])
        history.append(dict(bundle=_clean(item['bundle']), call=item['call']))
    body = json.loads(compact.build_wire(_clean(bundle), history))
    body['instructions'] = PROMPT
    body['text']['format'].update(name='mobile_capability_tool_call', schema=SCHEMA)
    content = body['input'][0]['content']
    meta = json.loads(content[0]['text'])
    meta.update(context_version=VERSION, condition=CONDITION, robot_specifications=copy.deepcopy(ROBOT_SPEC))
    content[0]['text'] = compact.canonical(meta).decode()
    wire = compact.canonical(body)
    if compact.non_image_bytes(wire) > 262144: raise ValueError('mobile text history cap')
    return wire


def audit_wire(wire, bundle, archive, condition=CONDITION):
    if wire != build_wire(bundle, archive, condition): raise ValueError('mobile request changed')


def dispatch(executor, call, depth, observation_ids=()):
    validate_call(call)
    if call['tool'] == 'move_base':
        from .eef_compact_dispatch import dispatch as shared
        return shared(executor, call, depth, observation_ids)
    return arm_dispatch(executor, call, depth, observation_ids)
