"""Provider parsing with parameter-only error feedback; no silent pose correction."""
import json
from .eef_mobile_contract import validate_call
from .eef_compact_api import MODEL, OUTPUT_CAP, reasoning_summaries, cost


def parameter_feedback(error):
    text = str(error)
    if 'quaternion must be unit xyzw' in text:
        return 'quaternion_xyzw must be unit norm; normalize your proposed quaternion and resubmit'
    if 'finite vector' in text: return 'pose coordinates must be finite vectors: position[3], quaternion_xyzw[4]'
    if 'turn_rad' in text: return 'turn_rad must be finite within +/-pi for move_base; otherwise null'
    if 'forward_m' in text: return 'forward_m must be finite within +/-1.5 m for move_base; otherwise null'
    if 'pixel' in text: return 'pixel must be two integers [x,y], each within 0..639'
    if 'gripper' in text: return 'gripper must be 0..1 only for set_gripper; otherwise null'
    return 'tool schema invalid; check required fields, tool-specific parameters and null unused fields'


def parse_response(raw, receipt, reflection=False):
    if reflection: raise ValueError('mobile condition uses terminal hindsight, no reflection send')
    body = json.loads(raw); usage = body.get('usage') or {}
    inp, out = usage.get('input_tokens'), usage.get('output_tokens')
    result = dict(status='censored',reason='provider_contract',call=None,reflection=None,
        provider_id=body.get('id'),usage=usage,reasoning_summaries=reasoning_summaries(body),estimated_usd=None)
    if type(inp) is int and inp >= 0 and type(out) is int and out >= 0:
        result['estimated_usd'] = str(cost(inp,out,reserve_write=True))
    if (body.get('status') != 'completed' or body.get('model') != MODEL
        or body.get('service_tier') not in (None,'default')
        or not isinstance(body.get('id'),str) or not body['id'].startswith('resp_')
        or result['estimated_usd'] is None or inp > receipt['input_bound'] or out > OUTPUT_CAP): return result
    texts = [c['text'] for item in body.get('output',[]) if item.get('type') == 'message'
        for c in item.get('content',[]) if c.get('type') == 'output_text']
    if len(texts) != 1: return result
    try: value = json.loads(texts[0])
    except (TypeError,ValueError):
        return dict(result,status='invalid_call',reason='invalid_tool_call',parameter_error='response must be one JSON tool call')
    try: validate_call(value)
    except (TypeError,ValueError,KeyError) as error:
        return dict(result,status='invalid_call',reason='invalid_tool_call',parameter_error=parameter_feedback(error))
    return dict(result,status='valid',reason=None,call=value)
